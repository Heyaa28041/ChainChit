'use client';

import { Fragment, useCallback, useEffect, useState } from 'react';
import { ChevronRight, Download, Lock, RefreshCw, ShieldAlert, ShieldCheck } from 'lucide-react';
import { Badge, type Tone } from '@/components/ui/badge';
import { Button, buttonStyles } from '@/components/ui/button';
import { EmptyState, Notice, PageHeader, PageLoader } from '@/components/ui/misc';
import { useSession } from '@/components/providers/session-provider';
import { api, errorMessage } from '@/lib/api';
import { cn } from '@/lib/cn';
import { formatDateTime, roleLabel, shortHash } from '@/lib/format';
import type { AuditEntry, AuditIntegrity } from '@/lib/types';

function describe(action: string): { label: string; tone: Tone } {
  const label = action.replace(/_/g, ' ').toLowerCase().replace(/^\w/, (c) => c.toUpperCase());
  if (action.includes('FRAUD') || action.includes('DISPUTED')) return { label, tone: 'flag' };
  if (action.includes('RELEASED') || action.includes('SETTLED')) return { label, tone: 'ok' };
  if (action.includes('BID')) return { label, tone: 'brass' };
  return { label, tone: 'neutral' };
}

function prettyPayload(json: string): string {
  try {
    return JSON.stringify(JSON.parse(json), null, 2);
  } catch {
    return json;
  }
}

export default function AuditPage() {
  const { user, ready } = useSession();
  const allowed = user?.role === 'FOREMAN' || user?.role === 'OVERSIGHT_VIEWER';

  const [logs, setLogs] = useState<AuditEntry[]>([]);
  const [integrity, setIntegrity] = useState<AuditIntegrity | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [open, setOpen] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api<{ logs: AuditEntry[]; integrity: AuditIntegrity }>('/api/audit');
      setLogs(data.logs ?? []);
      setIntegrity(data.integrity ?? null);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (allowed) void load();
  }, [allowed, load]);

  if (!ready) return <PageLoader />;

  if (!allowed) {
    return (
      <EmptyState icon={<Lock className="size-8" />} title="The audit ledger is for foremen and oversight accounts">
        Members can’t see the system-wide record. Sign in with an oversight or foreman account to read it.
      </EmptyState>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Audit ledger"
        description="Every bid, ruling and payout is written here and chained to the entry before it. If anyone edits an old entry, the chain breaks and the check below says so."
        actions={
          <>
            <Button variant="secondary" onClick={load} loading={loading}>
              <RefreshCw className="size-4" aria-hidden /> Check chain
            </Button>
            <a href="/api/audit/export?format=pdf" className={buttonStyles({ variant: 'secondary' })}>
              <Download className="size-4" aria-hidden /> Export signed PDF
            </a>
            <a href="/api/audit/export?format=csv" className={buttonStyles({})}>
              <Download className="size-4" aria-hidden /> Download CSV
            </a>
          </>
        }
      />

      {error && <Notice tone="flag" title="Couldn’t load the ledger">{error}</Notice>}

      {integrity && (
        <Notice
          tone={integrity.valid ? 'ok' : 'flag'}
          icon={integrity.valid ? <ShieldCheck className="size-5 text-ok" /> : <ShieldAlert className="size-5 text-flag" />}
          title={integrity.valid ? 'Chain intact' : 'Chain broken'}
        >
          {integrity.message} <span className="num">({integrity.totalEntries} entries checked)</span>
        </Notice>
      )}

      {loading && logs.length === 0 ? (
        <PageLoader label="Reading the ledger" />
      ) : logs.length === 0 ? (
        <EmptyState title="Nothing recorded yet">Entries appear as soon as someone bids, a ruling is made or a prize is paid out.</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-rule bg-sheet">
          <table className="w-full min-w-[46rem] text-left text-sm">
            <caption className="sr-only">Latest 100 audit entries, newest first</caption>
            <thead className="border-b border-rule text-ink-3">
              <tr>
                <th scope="col" className="w-10 py-3 pl-4"><span className="sr-only">Details</span></th>
                <th scope="col" className="px-3 py-3 font-medium">When</th>
                <th scope="col" className="px-3 py-3 font-medium">Who</th>
                <th scope="col" className="px-3 py-3 font-medium">What happened</th>
                <th scope="col" className="px-3 py-3 font-medium">On</th>
                <th scope="col" className="px-5 py-3 font-medium">Fingerprint</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log) => {
                const meta = describe(log.action);
                const expanded = open === log.id;
                return (
                  <Fragment key={log.id}>
                    <tr className="border-t border-rule first:border-t-0 hover:bg-paper/60">
                      <td className="py-3 pl-4">
                        <button
                          type="button"
                          onClick={() => setOpen(expanded ? null : log.id)}
                          aria-expanded={expanded}
                          aria-label={`${expanded ? 'Hide' : 'Show'} details for ${meta.label}`}
                          className="rounded p-1 text-ink-3 hover:bg-wash hover:text-ink"
                        >
                          <ChevronRight className={cn('size-4 transition-transform', expanded && 'rotate-90')} aria-hidden />
                        </button>
                      </td>
                      <td className="num whitespace-nowrap px-3 py-3 text-ink-2">{formatDateTime(log.timestamp)}</td>
                      <td className="whitespace-nowrap px-3 py-3">
                        <span className="font-medium">{log.actorName ?? 'System'}</span>{' '}
                        <span className="text-[13px] text-ink-3">{roleLabel(log.actorRole)}</span>
                      </td>
                      <td className="px-3 py-3">
                        <Badge tone={meta.tone}>{meta.label}</Badge>
                      </td>
                      <td className="whitespace-nowrap px-3 py-3 text-ink-2">{log.entityType.replace(/_/g, ' ').toLowerCase()}</td>
                      <td className="whitespace-nowrap px-5 py-3 font-mono text-[13px] text-ink-2" title={log.entryHash}>
                        {shortHash(log.entryHash, 10)}
                      </td>
                    </tr>
                    {expanded && (
                      <tr className="bg-paper/60">
                        <td />
                        <td colSpan={5} className="px-3 pb-5 pt-1">
                          <dl className="grid gap-x-8 gap-y-3 text-[13px] sm:grid-cols-2">
                            <div>
                              <dt className="text-ink-3">This entry’s hash</dt>
                              <dd className="mt-0.5 break-all font-mono text-ink">{log.entryHash}</dd>
                            </div>
                            <div>
                              <dt className="text-ink-3">Hash of the entry before it</dt>
                              <dd className="mt-0.5 break-all font-mono text-ink">{log.previousHash ?? 'First entry in the chain'}</dd>
                            </div>
                          </dl>
                          <p className="mt-4 text-[13px] text-ink-3">Recorded details</p>
                          <pre className="scroll-thin mt-1 max-h-60 overflow-auto rounded-lg border border-rule bg-sheet p-3 font-mono text-[12.5px] leading-relaxed text-ink">
                            {prettyPayload(log.payloadJson)}
                          </pre>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
