'use client';

import { use, useCallback } from 'react';
import Link from 'next/link';
import { ArrowLeft, DoorClosed } from 'lucide-react';
import { LotBoard } from '@/components/room/lot-board';
import { BidSlip } from '@/components/room/bid-slip';
import { Ledger } from '@/components/room/ledger';
import { ForemanPanel } from '@/components/room/foreman-panel';
import { EmptyState, PageLoader } from '@/components/ui/misc';
import { buttonStyles } from '@/components/ui/button';
import { useSession } from '@/components/providers/session-provider';
import { useLiveCycles } from '@/components/providers/live-cycles-provider';
import { useToast } from '@/components/providers/toast-provider';
import { useCycleRoom, type RoomEvent } from '@/lib/hooks/use-cycle-room';
import { api } from '@/lib/api';
import { formatINR } from '@/lib/format';

export default function CycleRoomPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { user } = useSession();
  const { refresh: refreshCycles } = useLiveCycles();
  const toast = useToast();

  const onEvent = useCallback(
    (event: RoomEvent) => {
      switch (event.kind) {
        case 'bid':
          toast.push({ tone: 'bid', title: `${formatINR(event.bid.bidAmount)} from ${event.bid.memberName}` });
          break;
        case 'flag':
          toast.push({ tone: 'flag', title: `${formatINR(event.bid.bidAmount)} is held for review`, body: `${event.bid.memberName}’s bid was far below the group’s usual range.` });
          break;
        case 'winner':
          toast.push({ tone: 'success', title: event.winnerName ? `${event.winnerName} wins this cycle` : 'A winner has been named' });
          break;
        case 'settled':
          toast.push({ tone: 'success', title: 'Prize paid out' });
          break;
        case 'disputed':
          toast.push({ tone: 'flag', title: 'Every bid was held, so the outcome is disputed' });
          break;
        case 'reset':
          toast.push({ tone: 'info', title: 'The foreman reset this cycle' });
          break;
        case 'alert-resolved':
          toast.push({ tone: 'info', title: event.winnerChanged ? 'A ruling changed the winner' : 'A held bid was ruled on' });
          break;
      }
      if (event.kind !== 'bid' && event.kind !== 'flag') void refreshCycles();
    },
    [toast, refreshCycles]
  );

  const { detail, loading, notFound, connected, freshBidIds, skewMs, reload, applyBid } = useCycleRoom(id, onEvent);

  /** Every client hits close at zero; the server only lets the first one do the work. */
  const handleExpire = useCallback(async () => {
    try {
      await api(`/api/cycles/${id}/close`, { method: 'POST' });
    } catch {
      // the stream or the next reload will bring the real state
    }
    void reload();
    void refreshCycles();
  }, [id, reload, refreshCycles]);

  const handleChanged = useCallback(() => {
    void reload();
    void refreshCycles();
  }, [reload, refreshCycles]);

  if (loading && !detail) return <PageLoader label="Opening the room" />;

  if (notFound || !detail) {
    return (
      <EmptyState
        icon={<DoorClosed className="size-8" />}
        title="This room doesn’t exist"
        action={
          <Link href="/" className={buttonStyles({ variant: 'secondary' })}>
            Back to bidding rooms
          </Link>
        }
      >
        The link may be old, or the cycle was removed.
      </EmptyState>
    );
  }

  const isForeman = user?.role === 'FOREMAN';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-ink-2 hover:text-ink">
          <ArrowLeft className="size-4" aria-hidden /> All bidding rooms
        </Link>
        <span className="flex items-center gap-2 text-[13px] text-ink-3" role="status">
          <span className={`size-2 rounded-full ${connected ? 'bg-ok' : 'bg-brass'}`} aria-hidden />
          {connected ? 'Live' : 'Reconnecting'}
        </span>
      </div>

      <LotBoard detail={detail} meId={user?.id} skewMs={skewMs} onExpire={handleExpire} />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,26rem)] lg:items-start">
        <div className="space-y-6">
          <Ledger bids={detail.bids} meId={user?.id} freshBidIds={freshBidIds} winningBidId={detail.cycle.winningBidId} />
          {isForeman && <ForemanPanel detail={detail} onChanged={handleChanged} />}
        </div>
        <div className="lg:sticky lg:top-24">
          <BidSlip detail={detail} user={user} onBidPlaced={applyBid} onStale={reload} />
        </div>
      </div>
    </div>
  );
}
