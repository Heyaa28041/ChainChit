'use client';

import { Notice, PageHeader, PageLoader } from '@/components/ui/misc';
import { useSession } from '@/components/providers/session-provider';
import { MemberDashboard, type MemberDash } from '@/components/dashboard/member-dashboard';
import { ForemanDashboard, type ForemanDash } from '@/components/dashboard/foreman-dashboard';
import { OversightDashboard, type OversightDash } from '@/components/dashboard/oversight-dashboard';
import { useFetch } from '@/lib/use-fetch';
import { roleLabel } from '@/lib/format';

type Dash = ({ role: 'MEMBER' } & MemberDash) | ({ role: 'FOREMAN' } & ForemanDash) | ({ role: 'OVERSIGHT_VIEWER' } & OversightDash);

/** FR35: one URL, three role-specific dashboards. The server decides what each role may see. */
export default function DashboardPage() {
  const { user, ready } = useSession();
  const { data, error, loading, reload } = useFetch<Dash>(user ? '/api/dashboard' : null);

  if (!ready || loading) return <PageLoader label="Loading your dashboard" />;
  if (!user) return null;

  return (
    <div className="space-y-8">
      <PageHeader
        title={`Hello, ${user.name.split(' ')[0]}`}
        description={
          user.role === 'MEMBER' ? 'Your contributions, bids and payouts in one place.'
          : user.role === 'FOREMAN' ? 'How your groups are collecting, bidding and settling.'
          : 'Read-only view of every group, flag, dispute and ledger entry.'
        }
      />
      {error && <Notice tone="flag" title="Couldn’t load the dashboard">{error}</Notice>}
      {data?.role === 'MEMBER' && <MemberDashboard data={data} reload={reload} />}
      {data?.role === 'FOREMAN' && <ForemanDashboard data={data} />}
      {data?.role === 'OVERSIGHT_VIEWER' && <OversightDashboard data={data} />}
      <p className="sr-only">Signed in as {roleLabel(user.role)}</p>
    </div>
  );
}
