'use client';

import Link from 'next/link';
import { use, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Field, Select, Textarea } from '@/components/ui/field';
import { Notice, PageHeader, PageLoader } from '@/components/ui/misc';
import { DataTable } from '@/components/ui/tabs';
import { DISPUTE_TONE } from '@/components/dashboard/member-dashboard';
import { useSession } from '@/components/providers/session-provider';
import { useToast } from '@/components/providers/toast-provider';
import { api, errorMessage } from '@/lib/api';
import { formatDateTime, formatINR } from '@/lib/format';
import { ruleLabel } from '@/lib/room';
import { useFetch } from '@/lib/use-fetch';

interface Detail {
  dispute: {
    id: string; code: string; status: string; description: string; comments: string | null; groupCode: string | null; createdAt: string; bidId: string | null; payoutId: string | null;
    evidence: {
      capturedAt: string;
      cycle: { id: string; number: number; status: string; payoutAmount: number | null; escrowStatus: string };
      transactionHistory: { bids: { id: string; memberName: string; bidAmount: number; status: string; zScore: number; timestamp: string }[]; disputantContributions: { id: string; amount: number; status: string; paidAt: string }[]; payout: { receiptId: string; amount: number } | null };
      fraudCheckLogs: { alerts: { id: string; ruleViolated: string; details: string; resolved: boolean; resolutionAction: string | null }[] };
      ledgerEntries: { sequence: number; timestamp: string; action: string; entryHash: string }[];
    };
  };
}

export default function DisputePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { user } = useSession();
  const toast = useToast();
  const { data, loading, error, reload } = useFetch<Detail>(`/api/disputes/${id}`);
  const [status, setStatus] = useState('RESOLVED');
  const [comments, setComments] = useState('');
  const [busy, setBusy] = useState(false);

  if (loading) return <PageLoader />;
  if (error || !data) return <Notice tone="flag" title="Couldn’t load this dispute">{error}</Notice>;
  const d = data.dispute;
  const ev = d.evidence;
  const canRule = (user?.role === 'FOREMAN' || user?.role === 'OVERSIGHT_VIEWER') && (d.status === 'OPEN' || d.status === 'ESCALATED');

  async function decide(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await api(`/api/disputes/${id}`, { method: 'PATCH', body: { status, comments } });
      toast.push({ tone: 'success', title: `Dispute marked ${status.toLowerCase()}` });
      setComments('');
      await reload();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Couldn’t update the dispute', body: errorMessage(err) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-8">
      <PageHeader title={`Dispute ${d.code}`} description={`${d.groupCode} · cycle ${ev.cycle.number} · against a ${d.bidId ? 'bid' : 'payout'} · raised ${formatDateTime(d.createdAt)}`} actions={<Badge tone={DISPUTE_TONE[d.status]} dot>{d.status.charAt(0) + d.status.slice(1).toLowerCase()}</Badge>} />

      <section className="rounded-2xl border border-rule bg-sheet p-5">
        <h2 className="text-lg">The complaint</h2>
        <p className="mt-2 whitespace-pre-wrap text-[15px]">{d.description}</p>
        {d.comments && (<><h3 className="mt-5 text-base">Comments</h3><p className="mt-1 whitespace-pre-wrap text-sm text-ink-2">{d.comments}</p></>)}
      </section>

      {canRule && (
        <form onSubmit={decide} className="space-y-4 rounded-2xl border border-rule bg-sheet p-5">
          <h2 className="text-lg">Update status</h2>
          <Field label="New status">{(fid) => <Select id={fid} value={status} onChange={(e) => setStatus(e.target.value)}><option value="RESOLVED">Resolved</option><option value="REJECTED">Rejected</option>{d.status !== 'ESCALATED' && <option value="ESCALATED">Escalated</option>}</Select>}</Field>
          <Field label="Comments" hint="Required. The member sees this and it’s recorded in the ledger.">{(fid, h) => <Textarea id={fid} aria-describedby={h} value={comments} onChange={(e) => setComments(e.target.value)} maxLength={600} />}</Field>
          <Button type="submit" loading={busy} disabled={comments.trim().length < 3}>Save</Button>
        </form>
      )}

      <section className="space-y-4">
        <div>
          <h2 className="text-xl">Evidence attached automatically</h2>
          <p className="mt-1 text-sm text-ink-3">Captured {formatDateTime(ev.capturedAt)} when the dispute was raised.</p>
        </div>
        <h3 className="text-base">Bids in this cycle</h3>
        <DataTable head={['Member', 'Bid', 'Deviation', 'Status']} empty="No bids.">
          {ev.transactionHistory.bids.map((b) => (
            <tr key={b.id}><td className="px-4 py-2.5">{b.memberName}</td><td className="num px-4 py-2.5">{formatINR(b.bidAmount)}</td><td className="num px-4 py-2.5">{b.zScore}σ</td><td className="px-4 py-2.5"><Badge tone={b.status === 'FLAGGED_SUSPICIOUS' ? 'flag' : 'ok'}>{b.status.replace(/_/g, ' ').toLowerCase()}</Badge></td></tr>
          ))}
        </DataTable>
        <h3 className="text-base">Fraud-check logs</h3>
        <DataTable head={['Rule', 'Details', 'Outcome']} empty="No fraud alerts in this cycle.">
          {ev.fraudCheckLogs.alerts.map((a) => (
            <tr key={a.id}><td className="px-4 py-2.5">{ruleLabel(a.ruleViolated)}</td><td className="px-4 py-2.5 text-ink-2">{a.details}</td><td className="px-4 py-2.5">{a.resolved ? (a.resolutionAction === 'OVERRIDDEN' ? 'Cleared' : 'Disqualified') : 'Open'}</td></tr>
          ))}
        </DataTable>
        {ev.transactionHistory.payout && <p className="text-sm">Payout {formatINR(ev.transactionHistory.payout.amount)} · <Link className="text-pine underline" href={`/receipts/${ev.transactionHistory.payout.receiptId}`}>{ev.transactionHistory.payout.receiptId}</Link></p>}
        <h3 className="text-base">Ledger entries</h3>
        <DataTable head={['#', 'Time', 'Action', 'Hash']} empty="No ledger entries.">
          {ev.ledgerEntries.map((l) => (
            <tr key={l.sequence}><td className="num px-4 py-2">{l.sequence}</td><td className="px-4 py-2">{formatDateTime(l.timestamp)}</td><td className="px-4 py-2">{l.action.replace(/_/g, ' ').toLowerCase()}</td><td className="num px-4 py-2 text-ink-3">{l.entryHash.slice(0, 12)}…</td></tr>
          ))}
        </DataTable>
      </section>
    </div>
  );
}
