'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Scale } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { EmptyState, Notice, PageHeader, PageLoader } from '@/components/ui/misc';
import { Tabs } from '@/components/ui/tabs';
import { DISPUTE_TONE } from '@/components/dashboard/member-dashboard';
import { useSession } from '@/components/providers/session-provider';
import { formatDateTime } from '@/lib/format';
import { useFetch } from '@/lib/use-fetch';
import type { DisputeRow } from '@/lib/types';

type Filter = 'ALL' | 'OPEN' | 'ESCALATED' | 'CLOSED';

export default function DisputesPage() {
  const { user } = useSession();
  const { data, loading, error } = useFetch<{ disputes: DisputeRow[] }>('/api/disputes');
  const [f, setF] = useState<Filter>('ALL');
  if (loading) return <PageLoader />;
  const all = data?.disputes ?? [];
  const shown = all.filter((d) => f === 'ALL' || (f === 'CLOSED' ? d.status === 'RESOLVED' || d.status === 'REJECTED' : d.status === f));

  return (
    <div className="space-y-6">
      <PageHeader
        title="Disputes"
        description={user?.role === 'MEMBER' ? 'Disputes you raised about a bid or payout. Raise a new one from your dashboard.' : 'Disputes raised against bids and payouts, with their evidence.'}
      />
      {error && <Notice tone="flag" title="Couldn’t load disputes">{error}</Notice>}
      <Tabs label="Dispute status" value={f} onChange={setF} tabs={[
        { id: 'ALL', label: 'All', count: all.length },
        { id: 'OPEN', label: 'Open', count: all.filter((d) => d.status === 'OPEN').length },
        { id: 'ESCALATED', label: 'Escalated', count: all.filter((d) => d.status === 'ESCALATED').length },
        { id: 'CLOSED', label: 'Closed' },
      ]} />
      {shown.length === 0 ? (
        <EmptyState icon={<Scale className="size-8" />} title="No disputes here">Nothing matches this view.</EmptyState>
      ) : (
        <ul className="divide-y divide-rule overflow-hidden rounded-2xl border border-rule bg-sheet">
          {shown.map((d) => (
            <li key={d.id}>
              <Link href={`/disputes/${d.id}`} className="flex flex-col gap-2 p-4 hover:bg-paper sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="flex flex-wrap items-center gap-2"><span className="num font-medium">{d.code}</span><span className="text-sm text-ink-3">{d.groupCode} · cycle {d.cycleNumber} · {d.bidId ? 'bid' : 'payout'}</span></p>
                  <p className="mt-0.5 truncate text-sm text-ink-2">{d.description}</p>
                  <p className="mt-0.5 text-[13px] text-ink-3">{d.raisedByName} · {formatDateTime(d.createdAt)}</p>
                </div>
                <Badge tone={DISPUTE_TONE[d.status]} dot>{d.status.charAt(0) + d.status.slice(1).toLowerCase()}</Badge>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
