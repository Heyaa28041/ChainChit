'use client';

import Link from 'next/link';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Lock, Play, Plus, Timer, XCircle } from 'lucide-react';
import { Badge, cycleStatusMeta, kycLabel, kycTone } from '@/components/ui/badge';
import { Button, buttonStyles } from '@/components/ui/button';
import { ConfirmDialog, ReasonDialog } from '@/components/ui/dialog';
import { Field, Input, Select } from '@/components/ui/field';
import { EmptyState, Notice, PageHeader, PageLoader } from '@/components/ui/misc';
import { useSession } from '@/components/providers/session-provider';
import { useLiveCycles } from '@/components/providers/live-cycles-provider';
import { useToast } from '@/components/providers/toast-provider';
import { api, errorMessage } from '@/lib/api';
import { cn } from '@/lib/cn';
import { formatDateTime, formatINR } from '@/lib/format';
import type { ChitGroup, MemberRecord } from '@/lib/types';

type Tab = 'members' | 'groups' | 'cycles';

export default function ForemanDeskPage() {
  const { user, ready } = useSession();
  const toast = useToast();
  const { cycles, live, refresh: refreshCycles } = useLiveCycles();

  const [tab, setTab] = useState<Tab>('members');
  const [members, setMembers] = useState<MemberRecord[]>([]);
  const [groups, setGroups] = useState<ChitGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const isForeman = user?.role === 'FOREMAN';

  const load = useCallback(async () => {
    try {
      const [k, g] = await Promise.all([
        api<{ members: MemberRecord[] }>('/api/foreman/kyc'),
        api<{ groups: ChitGroup[] }>('/api/foreman/groups'),
      ]);
      setMembers(k.members ?? []);
      setGroups(g.groups ?? []);
      setLoadError(null);
    } catch (err) {
      setLoadError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (isForeman) void load();
  }, [isForeman, load]);

  const pending = members.filter((m) => m.kycStatus === 'PENDING' || m.kycStatus === 'UNDER_REVIEW').length;

  if (!ready) return <PageLoader />;
  if (!isForeman) {
    return (
      <EmptyState icon={<Lock className="size-8" />} title="The foreman desk is for foremen">
        Sign in with a foreman account to approve members, create groups and run cycles.
      </EmptyState>
    );
  }

  const tabs: { id: Tab; label: string; count?: number }[] = [
    { id: 'members', label: 'Members', count: pending },
    { id: 'groups', label: 'Groups', count: groups.length },
    { id: 'cycles', label: 'Cycles', count: live.length },
  ];

  return (
    <div className="space-y-8">
      <PageHeader title="Foreman desk" description="Approve members, set up chit groups and run each month’s auction." />

      <div role="tablist" aria-label="Foreman desk sections" className="flex gap-1 border-b border-rule">
        {tabs.map((t) => (
          <button
            key={t.id}
            role="tab"
            id={`tab-${t.id}`}
            aria-selected={tab === t.id}
            aria-controls={`panel-${t.id}`}
            onClick={() => setTab(t.id)}
            className={cn(
              '-mb-px flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium transition-colors',
              tab === t.id ? 'border-pine text-ink' : 'border-transparent text-ink-3 hover:text-ink'
            )}
          >
            {t.label}
            {!!t.count && (
              <span className={cn('num rounded-full px-2 text-xs', t.id === 'members' ? 'bg-brass-wash text-brass-ink' : 'bg-wash text-ink-2')}>
                {t.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {loadError && <Notice tone="flag" title="Couldn’t load the desk">{loadError}</Notice>}

      <div role="tabpanel" id={`panel-${tab}`} aria-labelledby={`tab-${tab}`}>
        {loading ? (
          <PageLoader />
        ) : tab === 'members' ? (
          <MembersTab members={members} onChanged={load} />
        ) : tab === 'groups' ? (
          <GroupsTab groups={groups} members={members} onChanged={() => { void load(); }} goCycles={() => setTab('cycles')} />
        ) : (
          <CyclesTab groups={groups} cycles={cycles} live={live} onChanged={() => { void load(); void refreshCycles(); }} toast={toast} />
        )}
      </div>
    </div>
  );
}

/* ----------------------------- Members ----------------------------- */

function MembersTab({ members, onChanged }: { members: MemberRecord[]; onChanged: () => void }) {
  const toast = useToast();
  const [rejecting, setRejecting] = useState<MemberRecord | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function decide(member: MemberRecord, action: 'APPROVE' | 'REJECT', rejectionReason = '') {
    setBusyId(member.id);
    try {
      await api('/api/foreman/kyc', { method: 'POST', body: { memberId: member.id, action, rejectionReason } });
      toast.push({ tone: 'success', title: action === 'APPROVE' ? `${member.name} can now bid` : `${member.name}’s KYC was rejected` });
      onChanged();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Couldn’t save the decision', body: errorMessage(err) });
    } finally {
      setBusyId(null);
    }
  }

  if (members.length === 0) {
    return (
      <EmptyState title="No members yet">People who register as members show up here for ID review.</EmptyState>
    );
  }

  const waiting = (m: MemberRecord) => m.kycStatus === 'UNDER_REVIEW';
  const sorted = [...members].sort((a, b) => Number(waiting(b)) - Number(waiting(a)));

  return (
    <>
      <ul className="divide-y divide-rule overflow-hidden rounded-2xl border border-rule bg-sheet">
        {sorted.map((m) => (
          <li key={m.id} className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
            <div className="min-w-0">
              <p className="flex flex-wrap items-center gap-2">
                <span className="font-medium">{m.name}</span>
                <Badge tone={kycTone(m.kycStatus)} dot>{kycLabel(m.kycStatus)}</Badge>
              </p>
              <p className="mt-1 text-sm text-ink-2">
                {m.email} · <span className="num">{m.mobile}</span>
              </p>
              <p className="mt-0.5 text-sm text-ink-3">
                {m.memberCode && <span className="num">{m.memberCode} · </span>}Government ID <span className="num font-medium text-ink-2">{m.govtId}</span>
              </p>
              {m.kycRejectionReason && m.kycStatus === 'REJECTED' && <p className="mt-0.5 text-sm text-flag">Rejected: {m.kycRejectionReason}</p>}
              {!!m.documents?.length && (
                <p className="mt-1.5 flex flex-wrap gap-2 text-sm">
                  {m.documents.map((d) => (
                    <a key={d.id} href={`/api/foreman/kyc/${m.id}/documents/${d.id}`} target="_blank" rel="noreferrer" className="rounded-md bg-wash px-2 py-0.5 text-pine underline">{d.docType === 'AADHAAR' ? 'Aadhaar' : 'PAN'} · {d.fileName}</a>
                  ))}
                </p>
              )}
            </div>
            {(m.kycStatus === 'UNDER_REVIEW' || m.kycStatus === 'REJECTED' || m.kycStatus === 'PENDING') && (
              <div className="flex gap-2">
                <Button loading={busyId === m.id} disabled={!m.documents?.length} title={m.documents?.length ? undefined : 'No documents uploaded yet'} onClick={() => decide(m, 'APPROVE')}>
                  <CheckCircle2 className="size-4" aria-hidden /> Approve
                </Button>
                <Button variant="secondary" disabled={busyId === m.id} onClick={() => setRejecting(m)}>
                  <XCircle className="size-4" aria-hidden /> Reject
                </Button>
              </div>
            )}
          </li>
        ))}
      </ul>

      <ReasonDialog
        open={!!rejecting}
        title={`Reject ${rejecting?.name ?? 'this member'}’s KYC?`}
        description="They won’t be able to bid until they resubmit. The reason is kept in the audit ledger."
        label="Reason"
        required
        confirmLabel="Reject KYC"
        tone="danger"
        onSubmit={async (reason) => {
          if (rejecting) await decide(rejecting, 'REJECT', reason);
          setRejecting(null);
        }}
        onClose={() => setRejecting(null)}
      />
    </>
  );
}

/* ------------------------------ Groups ------------------------------ */

function GroupsTab({
  groups,
  members,
  onChanged,
  goCycles,
}: {
  groups: ChitGroup[];
  members: MemberRecord[];
  onChanged: () => void;
  goCycles: () => void;
}) {
  const toast = useToast();
  const verified = useMemo(() => members.filter((m) => m.kycStatus === 'VERIFIED'), [members]);
  const [name, setName] = useState('');
  const [chitValue, setChitValue] = useState('100000');
  const [size, setSize] = useState('5');
  const [days, setDays] = useState('30');
  const [z, setZ] = useState('2.5');
  const [minMembers, setMinMembers] = useState('');
  const [totalCycles, setTotalCycles] = useState('');
  const [picked, setPicked] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const capacity = Number(size) || 0;
  const over = picked.length > capacity;

  function toggle(id: string) {
    setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  }

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    try {
      await api('/api/foreman/groups', {
        method: 'POST',
        body: { name, chitValue, numberOfMembers: size, cycleDurationDays: days, fraudThresholdZ: z, memberIds: picked, ...(minMembers ? { minMembers } : {}), ...(totalCycles ? { totalCycles } : {}) },
      });
      toast.push({ tone: 'success', title: `${name} created`, body: `${picked.length} ${picked.length === 1 ? 'member' : 'members'} enrolled.` });
      setName('');
      setPicked([]);
      onChanged();
      goCycles();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,24rem)] lg:items-start">
      <section aria-labelledby="new-group">
        <h2 id="new-group" className="text-xl">New chit group</h2>
        <form onSubmit={create} className="mt-4 space-y-5 rounded-2xl border border-rule bg-sheet p-6">
          <Field label="Group name">
            {(id) => <Input id={id} value={name} onChange={(e) => setName(e.target.value)} required placeholder="Gold Wealth Chit 2026" />}
          </Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Pool value (₹)" hint="The prize the winner’s bid is measured against.">
              {(id, d) => <Input id={id} aria-describedby={d} type="number" min={1000} inputMode="numeric" value={chitValue} onChange={(e) => setChitValue(e.target.value)} required />}
            </Field>
            <Field label="Members in the group">
              {(id) => <Input id={id} type="number" min={2} inputMode="numeric" value={size} onChange={(e) => setSize(e.target.value)} required />}
            </Field>
            <Field label="Days between cycles">
              {(id) => <Input id={id} type="number" min={1} inputMode="numeric" value={days} onChange={(e) => setDays(e.target.value)} required />}
            </Field>
            <Field label="Minimum members to start" hint="Blank = the full group. The first cycle can’t open below this.">
              {(id, d) => <Input id={id} aria-describedby={d} type="number" min={2} inputMode="numeric" value={minMembers} onChange={(e) => setMinMembers(e.target.value)} />}
            </Field>
            <Field label="Number of cycles" hint="Blank = one per member. The whole schedule is generated for you.">
              {(id, d) => <Input id={id} aria-describedby={d} type="number" min={1} inputMode="numeric" value={totalCycles} onChange={(e) => setTotalCycles(e.target.value)} />}
            </Field>
            <Field label="Fraud flag at σ below average" hint="Lower flags more bids. 2.5 is a good start.">
              {(id, d) => <Input id={id} aria-describedby={d} type="number" step="0.1" min={1} value={z} onChange={(e) => setZ(e.target.value)} required />}
            </Field>
          </div>

          <fieldset>
            <legend className="text-sm font-medium">Enroll verified members</legend>
            <p className="mt-0.5 text-sm text-ink-3">
              <span className={cn('num', over && 'text-flag')}>{picked.length} of {capacity || '–'}</span> chosen. Only members with approved KYC can join.
            </p>
            {verified.length === 0 ? (
              <p className="mt-3 text-sm text-ink-2">No verified members yet. Approve someone in the Members tab first.</p>
            ) : (
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {verified.map((m) => (
                  <label key={m.id} className={cn('flex items-center gap-3 rounded-lg border px-3 py-2.5 text-sm', picked.includes(m.id) ? 'border-pine bg-pine-wash' : 'border-rule-2 bg-sheet hover:bg-paper')}>
                    <input type="checkbox" className="size-4 accent-[var(--color-pine)]" checked={picked.includes(m.id)} onChange={() => toggle(m.id)} />
                    <span className="min-w-0 truncate">{m.name}</span>
                  </label>
                ))}
              </div>
            )}
          </fieldset>

          {error && <p role="alert" className="rounded-lg bg-flag-wash px-3 py-2.5 text-sm text-flag">{error}</p>}
          <Button type="submit" size="lg" loading={saving} disabled={over || !name.trim()}>
            <Plus className="size-4" aria-hidden /> Create group
          </Button>
        </form>
      </section>

      <section aria-labelledby="existing-groups">
        <h2 id="existing-groups" className="text-xl">Your groups</h2>
        {groups.length === 0 ? (
          <p className="mt-3 text-sm text-ink-2">No groups yet. The one you create appears here.</p>
        ) : (
          <ul className="mt-4 space-y-3">
            {groups.map((g) => (
              <li key={g.id} className="rounded-xl border border-rule bg-sheet p-4">
                <p className="font-medium">{g.name}</p>
                <p className="num mt-1 text-sm text-ink-2">
                  {formatINR(g.chitValue)} · {g.enrolledCount ?? 0} of {g.numberOfMembers} enrolled
                </p>
                <p className="mt-0.5 text-[13px] text-ink-3">Every {g.cycleDurationDays} days · flags at {g.fraudThresholdZ}σ</p>
                <Link href={`/groups/${g.id}`} className="mt-2 inline-block text-[13px] font-medium text-pine underline">Open group</Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

/* ------------------------------ Cycles ------------------------------ */

function CyclesTab({
  groups,
  cycles,
  live,
  onChanged,
  toast,
}: {
  groups: ChitGroup[];
  cycles: ReturnType<typeof useLiveCycles>['cycles'];
  live: ReturnType<typeof useLiveCycles>['live'];
  onChanged: () => void;
  toast: ReturnType<typeof useToast>;
}) {
  const [groupId, setGroupId] = useState('');
  const [seconds, setSeconds] = useState('180');
  const [starting, setStarting] = useState(false);
  const [stopping, setStopping] = useState<string | null>(null);
  const chosen = groupId || groups[0]?.id || '';

  async function start(e: React.FormEvent) {
    e.preventDefault();
    if (!chosen) return;
    setStarting(true);
    try {
      const res = await api<{ cycle: { id: string; cycleNumber: number } }>('/api/foreman/cycles', {
        method: 'POST',
        body: { groupId: chosen, durationSeconds: parseInt(seconds, 10) || 180 },
      });
      toast.push({ tone: 'success', title: `Cycle ${res.cycle.cycleNumber} is open`, body: `Bidding runs for ${seconds} seconds.` });
      onChanged();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Couldn’t open the cycle', body: errorMessage(err) });
    } finally {
      setStarting(false);
    }
  }

  async function extend(id: string, extraSeconds: number) {
    try {
      await api(`/api/foreman/cycles/${id}`, { method: 'PATCH', body: { action: 'extend_timer', extraSeconds } });
      toast.push({ tone: 'success', title: `Added ${extraSeconds} seconds` });
      onChanged();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Couldn’t extend the window', body: errorMessage(err) });
    }
  }

  async function stop(id: string) {
    try {
      await api(`/api/foreman/cycles/${id}`, { method: 'PATCH', body: { action: 'stop_cycle' } });
      toast.push({ tone: 'success', title: 'Bidding closed' });
      onChanged();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Couldn’t close bidding', body: errorMessage(err) });
    }
  }

  const stopTarget = live.find((c) => c.id === stopping);
  const rest = cycles.filter((c) => c.status !== 'BIDDING_OPEN');

  return (
    <div className="space-y-10">
      <section aria-labelledby="open-now">
        <h2 id="open-now" className="text-xl">Open now</h2>
        {live.length === 0 ? (
          <p className="mt-3 text-sm text-ink-2">No auction is running. Open one below.</p>
        ) : (
          <ul className="mt-4 grid gap-3 md:grid-cols-2">
            {live.map((c) => (
              <li key={c.id} className="rounded-2xl border border-rule bg-sheet p-5">
                <p className="flex items-center justify-between gap-3">
                  <span className="font-medium">{c.groupName}</span>
                  <span className="num text-sm text-ink-3">Cycle {c.cycleNumber}</span>
                </p>
                <p className="num mt-1 text-sm text-ink-2">{formatINR(c.chitValue)} pool</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Link href={`/cycle/${c.id}`} className={buttonStyles({ size: 'sm' })}>Open room</Link>
                  <Button size="sm" variant="secondary" onClick={() => extend(c.id, 60)}>
                    <Timer className="size-3.5" aria-hidden /> +1 min
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => extend(c.id, 180)}>+3 min</Button>
                  <Button size="sm" variant="ghost" onClick={() => setStopping(c.id)}>Close now</Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section aria-labelledby="start-cycle">
        <h2 id="start-cycle" className="text-xl">Open a new cycle</h2>
        {groups.length === 0 ? (
          <p className="mt-3 text-sm text-ink-2">Create a group first, then you can open its auction here.</p>
        ) : (
          <form onSubmit={start} className="mt-4 flex flex-col gap-4 rounded-2xl border border-rule bg-sheet p-5 sm:flex-row sm:items-end">
            <Field label="Group" className="sm:flex-1">
              {(id) => (
                <Select id={id} value={chosen} onChange={(e) => setGroupId(e.target.value)}>
                  {groups.map((g) => (
                    <option key={g.id} value={g.id}>{g.name} ({formatINR(g.chitValue)})</option>
                  ))}
                </Select>
              )}
            </Field>
            <Field label="Bidding window (seconds)" className="sm:w-52">
              {(id) => <Input id={id} type="number" min={30} inputMode="numeric" value={seconds} onChange={(e) => setSeconds(e.target.value)} />}
            </Field>
            <Button type="submit" size="lg" loading={starting}>
              <Play className="size-4" aria-hidden /> Open bidding
            </Button>
          </form>
        )}
      </section>

      {rest.length > 0 && (
        <section aria-labelledby="history">
          <h2 id="history" className="text-xl">History</h2>
          <ul className="mt-4 divide-y divide-rule overflow-hidden rounded-2xl border border-rule bg-sheet">
            {rest.map((c) => {
              const meta = cycleStatusMeta(c.status);
              return (
                <li key={c.id}>
                  <Link href={`/cycle/${c.id}`} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 hover:bg-paper/60">
                    <span className="min-w-0">
                      <span className="font-medium">{c.groupName}</span>{' '}
                      <span className="num text-sm text-ink-3">cycle {c.cycleNumber} · {formatDateTime(c.biddingStartTime ?? c.createdAt)}</span>
                    </span>
                    <span className="flex items-center gap-3 text-sm">
                      {c.winnerName && <span className="text-ink-2">{c.winnerName} · <span className="num">{formatINR(c.payoutAmount)}</span></span>}
                      <Badge tone={meta.tone} dot>{meta.label}</Badge>
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>
      )}

      <ConfirmDialog
        open={!!stopTarget}
        title="Close bidding now?"
        description={`No more bids will be taken in ${stopTarget?.groupName ?? 'this room'} and the winner is named immediately.`}
        confirmLabel="Close bidding"
        tone="danger"
        onConfirm={() => (stopping ? stop(stopping) : undefined)}
        onClose={() => setStopping(null)}
      />
    </div>
  );
}
