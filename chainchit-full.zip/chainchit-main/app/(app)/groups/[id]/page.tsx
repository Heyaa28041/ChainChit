'use client';

import Link from 'next/link';
import { use, useState } from 'react';
import { Download, Play, UserMinus, UserPlus } from 'lucide-react';
import { Badge, cycleStatusMeta, kycTone, kycLabel } from '@/components/ui/badge';
import { Button, buttonStyles } from '@/components/ui/button';
import { ConfirmDialog } from '@/components/ui/dialog';
import { Field, Input, Select } from '@/components/ui/field';
import { Notice, PageHeader, PageLoader } from '@/components/ui/misc';
import { DataTable, Stat, Tabs } from '@/components/ui/tabs';
import { useSession } from '@/components/providers/session-provider';
import { useToast } from '@/components/providers/toast-provider';
import { api, errorMessage } from '@/lib/api';
import { formatDateTime, formatINR } from '@/lib/format';
import { useFetch } from '@/lib/use-fetch';
import type { GroupRow, MemberRecord } from '@/lib/types';

interface Detail {
  group: GroupRow;
  roster: { id: string; memberCode: string | null; name: string; kycStatus: string; trustScore: number; delinquent: boolean }[];
  schedule: { id: string; cycleNumber: number; status: string; startDate: string; endDate: string; dueDate: string; settledAt: string | null }[];
}
interface LedgerRes {
  entries: { sequence: number; timestamp: string; actorRole: string; action: string; entityType: string; entryHash: string; signature: string; payloadJson: string }[];
  integrity: { valid: boolean; totalEntries: number; message: string };
}
type Tab = 'schedule' | 'members' | 'ledger' | 'settings';

const SETTINGS: { key: keyof GroupRow; label: string; hint: string; step?: string }[] = [
  { key: 'fraudThresholdZ', label: 'Fraud flag line (σ below average)', hint: 'Takes effect on the next bid.', step: '0.1' },
  { key: 'biddingWindowSeconds', label: 'Bidding window (seconds)', hint: 'Default length when a cycle opens.' },
  { key: 'gracePeriodDays', label: 'Grace period (days)', hint: 'After the due date, before a member is flagged.' },
  { key: 'reminderLeadDays', label: 'Reminder lead (days)', hint: 'How early the due-date reminder is sent.' },
  { key: 'disputeWindowDays', label: 'Dispute window (days)', hint: 'How long after an event a dispute may be raised.' },
  { key: 'minMembers', label: 'Minimum members to start', hint: 'The first cycle can’t open below this.' },
  { key: 'winFreqWindow', label: 'Win-frequency window (cycles)', hint: 'How many recent cycles are checked.' },
  { key: 'winFreqMinWins', label: 'Wins that trigger review', hint: 'Only used when repeat winners are allowed.' },
];

export default function GroupPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { user } = useSession();
  const toast = useToast();
  const isForeman = user?.role === 'FOREMAN';
  const canExport = isForeman || user?.role === 'OVERSIGHT_VIEWER';
  const detail = useFetch<Detail>(`/api/foreman/groups/${id}`);
  const ledger = useFetch<LedgerRes>(`/api/groups/${id}/ledger`);
  const kyc = useFetch<{ members: MemberRecord[] }>(isForeman ? '/api/foreman/kyc' : null);
  const [tab, setTab] = useState<Tab>('schedule');
  const [seconds, setSeconds] = useState('');
  const [busy, setBusy] = useState(false);
  const [addId, setAddId] = useState('');
  const [removing, setRemoving] = useState<Detail['roster'][number] | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});
  const [repeat, setRepeat] = useState<boolean | null>(null);

  if (detail.loading) return <PageLoader />;
  if (detail.error || !detail.data) return <Notice tone="flag" title="Couldn’t load this group">{detail.error}</Notice>;
  const { group, roster, schedule } = detail.data;
  const enrolmentOpen = schedule.every((c) => c.status === 'SCHEDULED');
  const addable = (kyc.data?.members ?? []).filter((m) => m.kycStatus === 'VERIFIED' && !roster.some((r) => r.id === m.id));
  const refresh = () => { void detail.reload(); void ledger.reload(); };

  async function run(label: string, fn: () => Promise<unknown>, ok: string) {
    setBusy(true);
    try { await fn(); toast.push({ tone: 'success', title: ok }); refresh(); }
    catch (err) { toast.push({ tone: 'error', title: label, body: errorMessage(err) }); }
    finally { setBusy(false); }
  }

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault();
    const body: Record<string, number | boolean> = {};
    for (const [k, v] of Object.entries(form)) if (v !== '') body[k] = Number(v);
    if (repeat !== null) body.allowRepeatWinners = repeat;
    await run('Couldn’t save settings', () => api(`/api/foreman/groups/${id}`, { method: 'PATCH', body }), 'Settings saved');
    setForm({});
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title={group.name}
        description={`${group.code} · ${formatINR(group.chitValue)} pool · ${formatINR(group.contributionAmount)} per member each ${group.cycleDurationDays} days`}
        actions={canExport ? (
          <>
            <a className={buttonStyles({ variant: 'secondary' })} href={`/api/groups/${id}/export?format=csv`}><Download className="size-4" aria-hidden /> CSV</a>
            <a className={buttonStyles({ variant: 'secondary' })} href={`/api/groups/${id}/export?format=pdf`}><Download className="size-4" aria-hidden /> PDF</a>
          </>
        ) : undefined}
      />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Status" value={<Badge tone={group.status === 'ACTIVE' ? 'ok' : 'info'}>{group.status === 'ACTIVE' ? 'Active' : 'Completed'}</Badge>} />
        <Stat label="Members" value={`${roster.length}/${group.numberOfMembers}`} hint={`Minimum ${group.minMembers}`} />
        <Stat label="Cycles settled" value={`${schedule.filter((c) => c.status === 'SETTLED').length}/${schedule.length}`} />
        <Stat label="Fraud flag line" value={`${group.fraudThresholdZ}σ`} hint="Below the group’s average bid" />
      </div>

      <Tabs label="Group" value={tab} onChange={setTab} tabs={[
        { id: 'schedule', label: 'Schedule', count: schedule.length }, { id: 'members', label: 'Members', count: roster.length }, { id: 'ledger', label: 'Ledger' },
        ...(isForeman ? [{ id: 'settings' as const, label: 'Settings' }] : []),
      ]} />

      {tab === 'schedule' && (
        <section className="space-y-4">
          {isForeman && group.status === 'ACTIVE' && (
            <div className="flex flex-wrap items-end gap-3 rounded-xl border border-rule bg-sheet p-4">
              <Field label="Bidding window (seconds)" hint={`Leave blank for the group default (${group.biddingWindowSeconds}s).`}>
                {(fid, d) => <Input id={fid} aria-describedby={d} className="w-44" type="number" min={10} value={seconds} onChange={(e) => setSeconds(e.target.value)} />}
              </Field>
              <Button loading={busy} onClick={() => run('Couldn’t open the next cycle', () => api('/api/foreman/cycles', { method: 'POST', body: { groupId: id, ...(seconds ? { durationSeconds: Number(seconds) } : {}) } }), 'Next cycle is open for bidding')}>
                <Play className="size-4" aria-hidden /> Open next cycle
              </Button>
            </div>
          )}
          <DataTable head={['Cycle', 'Starts', 'Ends', 'Contributions due', 'Status']}>
            {schedule.map((c) => {
              const m = cycleStatusMeta(c.status);
              return (
                <tr key={c.id}>
                  <td className="num px-4 py-3">{c.status === 'SCHEDULED' ? c.cycleNumber : <Link className="underline" href={`/cycle/${c.id}`}>{c.cycleNumber}</Link>}</td>
                  <td className="px-4 py-3">{formatDateTime(c.startDate)}</td>
                  <td className="px-4 py-3">{formatDateTime(c.endDate)}</td>
                  <td className="px-4 py-3">{formatDateTime(c.dueDate)}</td>
                  <td className="px-4 py-3"><Badge tone={m.tone}>{m.label}</Badge></td>
                </tr>
              );
            })}
          </DataTable>
        </section>
      )}

      {tab === 'members' && (
        <section className="space-y-4">
          {isForeman && (enrolmentOpen ? (
            <div className="flex flex-wrap items-end gap-3 rounded-xl border border-rule bg-sheet p-4">
              <Field label="Enrol a verified member" className="min-w-56 flex-1">
                {(fid) => <Select id={fid} value={addId} onChange={(e) => setAddId(e.target.value)}><option value="">Choose a member…</option>{addable.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</Select>}
              </Field>
              <Button disabled={!addId} loading={busy} onClick={() => run('Couldn’t enrol', () => api(`/api/foreman/groups/${id}/members`, { method: 'POST', body: { memberId: addId } }), 'Member enrolled').then(() => setAddId(''))}><UserPlus className="size-4" aria-hidden /> Enrol</Button>
            </div>
          ) : <Notice tone="info" title="Enrolment is closed">Members can only be added or removed before the first cycle begins.</Notice>)}
          <DataTable head={['Member', 'KYC', 'Trust', 'Payments', '']} empty="No members enrolled yet.">
            {roster.map((m) => (
              <tr key={m.id}>
                <td className="px-4 py-3"><span className="font-medium">{m.name}</span> <span className="num text-ink-3">{m.memberCode}</span></td>
                <td className="px-4 py-3"><Badge tone={kycTone(m.kycStatus)}>{kycLabel(m.kycStatus)}</Badge></td>
                <td className="num px-4 py-3">{Math.round(m.trustScore)}</td>
                <td className="px-4 py-3">{m.delinquent ? <Badge tone="flag" dot>Delinquent</Badge> : <Badge tone="ok">Up to date</Badge>}</td>
                <td className="px-4 py-3 text-right">{isForeman && enrolmentOpen && <Button size="sm" variant="ghost" aria-label={`Remove ${m.name}`} onClick={() => setRemoving(m)}><UserMinus className="size-4" aria-hidden /></Button>}</td>
              </tr>
            ))}
          </DataTable>
        </section>
      )}

      {tab === 'ledger' && (
        <section className="space-y-4">
          {ledger.data && <Notice tone={ledger.data.integrity.valid ? 'ok' : 'flag'} title={ledger.data.integrity.valid ? 'Ledger verified' : 'Ledger integrity failure'}>{ledger.data.integrity.message}</Notice>}
          {ledger.error && <Notice tone="flag" title="Couldn’t load the ledger">{ledger.error}</Notice>}
          <DataTable head={['#', 'Time', 'Action', 'Hash']} empty="No entries yet.">
            {(ledger.data?.entries ?? []).map((e) => (
              <tr key={e.sequence}>
                <td className="num px-4 py-2.5">{e.sequence}</td>
                <td className="px-4 py-2.5">{formatDateTime(e.timestamp)}</td>
                <td className="px-4 py-2.5">{e.action.replace(/_/g, ' ').toLowerCase()}</td>
                <td className="num px-4 py-2.5 text-ink-3" title={e.entryHash}>{e.entryHash.slice(0, 12)}…</td>
              </tr>
            ))}
          </DataTable>
        </section>
      )}

      {tab === 'settings' && isForeman && (
        <form onSubmit={saveSettings} className="space-y-5 rounded-2xl border border-rule bg-sheet p-6">
          <p className="text-sm text-ink-2">Changes apply immediately and are recorded in the ledger with your name and the time.</p>
          <div className="grid gap-5 sm:grid-cols-2">
            {SETTINGS.map((s) => (
              <Field key={s.key} label={s.label} hint={s.hint}>
                {(fid, d) => <Input id={fid} aria-describedby={d} type="number" step={s.step} placeholder={String(group[s.key] ?? '')} value={form[s.key] ?? ''} onChange={(e) => setForm((f) => ({ ...f, [s.key]: e.target.value }))} />}
              </Field>
            ))}
          </div>
          <label className="flex items-start gap-2.5 text-sm">
            <input type="checkbox" className="mt-0.5 size-4 accent-[var(--color-pine)]" checked={repeat ?? group.allowRepeatWinners} onChange={(e) => setRepeat(e.target.checked)} />
            <span><span className="font-medium">Allow repeat winners</span><br /><span className="text-ink-3">Off: one prize per member. On: repeat wins are allowed but checked for collusion by win frequency.</span></span>
          </label>
          <Button type="submit" loading={busy} disabled={!Object.values(form).some((v) => v !== '') && repeat === null}>Save settings</Button>
        </form>
      )}

      <ConfirmDialog
        open={!!removing} tone="danger" title={`Remove ${removing?.name ?? 'this member'}?`}
        description="They’re taken out of the group. This is recorded in the audit ledger." confirmLabel="Remove member"
        onConfirm={async () => { if (removing) await run('Couldn’t remove', () => api(`/api/foreman/groups/${id}/members?memberId=${removing.id}`, { method: 'DELETE' }), 'Member removed'); }}
        onClose={() => setRemoving(null)}
      />
    </div>
  );
}
