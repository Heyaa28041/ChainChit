'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Layers } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { buttonStyles } from '@/components/ui/button';
import { EmptyState, Notice, PageHeader, PageLoader } from '@/components/ui/misc';
import { Tabs } from '@/components/ui/tabs';
import { useSession } from '@/components/providers/session-provider';
import { formatINR } from '@/lib/format';
import { useFetch } from '@/lib/use-fetch';
import type { GroupRow } from '@/lib/types';

/** FR09: active and completed groups, visible to every role. */
export default function GroupsPage() {
  const { user } = useSession();
  const { data, loading, error } = useFetch<{ active: GroupRow[]; completed: GroupRow[] }>('/api/foreman/groups');
  const [tab, setTab] = useState<'active' | 'completed'>('active');

  if (loading) return <PageLoader />;
  const list = data?.[tab] ?? [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Chit groups"
        description="Every group, its schedule and its ledger."
        actions={user?.role === 'FOREMAN' ? <Link href="/foreman" className={buttonStyles({})}>New group</Link> : undefined}
      />
      {error && <Notice tone="flag" title="Couldn’t load groups">{error}</Notice>}
      <Tabs label="Group status" value={tab} onChange={setTab} tabs={[
        { id: 'active', label: 'Active', count: data?.active.length },
        { id: 'completed', label: 'Completed', count: data?.completed.length },
      ]} />
      {list.length === 0 ? (
        <EmptyState icon={<Layers className="size-8" />} title={`No ${tab} groups`}>{tab === 'active' ? 'Groups appear here once a foreman creates them.' : 'A group completes when every scheduled cycle has settled.'}</EmptyState>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((g) => (
            <li key={g.id}>
              <Link href={`/groups/${g.id}`} className="block h-full rounded-2xl border border-rule bg-sheet p-5 transition-colors hover:border-rule-2">
                <p className="flex items-center justify-between gap-2"><span className="num text-[13px] font-medium text-ink-3">{g.code}</span><Badge tone={g.status === 'ACTIVE' ? 'ok' : 'info'}>{g.status === 'ACTIVE' ? 'Active' : 'Completed'}</Badge></p>
                <h2 className="mt-2 text-xl">{g.name}</h2>
                <p className="num mt-1 text-sm text-ink-2">{formatINR(g.chitValue)} pool · {formatINR(g.contributionAmount)} each</p>
                <p className="num mt-3 text-[13px] text-ink-3">{g.enrolledCount ?? 0}/{g.numberOfMembers} members · {g.settledCycles}/{g.totalCycles} cycles settled</p>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-wash" aria-hidden><div className="h-full bg-pine" style={{ width: `${g.totalCycles ? (g.settledCycles / g.totalCycles) * 100 : 0}%` }} /></div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
