'use client';

import Link from 'next/link';
import { useRef, useState } from 'react';
import { FileText, Lock, ShieldCheck, Upload } from 'lucide-react';
import { Badge, kycLabel, kycTone } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Field, Select } from '@/components/ui/field';
import { EmptyState, Notice, PageHeader, PageLoader } from '@/components/ui/misc';
import { useSession } from '@/components/providers/session-provider';
import { useToast } from '@/components/providers/toast-provider';
import { errorMessage } from '@/lib/api';
import { formatDateTime } from '@/lib/format';
import { useFetch } from '@/lib/use-fetch';
import type { KycDoc } from '@/lib/types';

const ACCEPT = '.pdf,.png,.jpg,.jpeg,application/pdf,image/png,image/jpeg';
const kb = (n: number) => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

export default function KycPage() {
  const { user, ready, refresh } = useSession();
  const toast = useToast();
  const { data, loading, error, reload } = useFetch<{ kycStatus: string; rejectionReason: string | null; documents: KycDoc[]; maxBytes: number }>(user?.role === 'MEMBER' ? '/api/kyc' : null);
  const [docType, setDocType] = useState('AADHAAR');
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);

  if (!ready || (user?.role === 'MEMBER' && loading)) return <PageLoader />;
  if (user?.role !== 'MEMBER') {
    return <EmptyState icon={<Lock className="size-8" />} title="KYC is for members">Foremen review member documents from the Foreman desk.</EmptyState>;
  }

  const max = data?.maxBytes ?? 5 * 1024 * 1024;
  const status = data?.kycStatus ?? user.kycStatus;

  function pick(f: File | null) {
    setFileError(null);
    setFile(null);
    if (!f) return;
    const ext = f.name.split('.').pop()?.toLowerCase() ?? '';
    if (!['pdf', 'png', 'jpg', 'jpeg'].includes(ext)) return setFileError('Upload a PDF, JPG or PNG file.');
    if (f.size > max) return setFileError(`That file is ${kb(f.size)}. The limit is ${kb(max)}.`);
    setFile(f);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;
    setBusy(true);
    try {
      const form = new FormData();
      form.set('docType', docType);
      form.set('file', file);
      const res = await fetch('/api/kyc', { method: 'POST', body: form, credentials: 'same-origin' });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(body.error || `Upload failed (${res.status})`);
      toast.push({ tone: 'success', title: 'Document received', body: 'Your KYC is now under review by the foreman.' });
      setFile(null);
      if (input.current) input.current.value = '';
      await Promise.all([reload(), refresh()]);
    } catch (err) {
      toast.push({ tone: 'error', title: 'Upload failed', body: errorMessage(err) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <PageHeader title="Verify your identity" description="Upload your Aadhaar or PAN. The foreman reviews it before you can contribute to a group or bid." />

      <div className="flex flex-wrap items-center gap-3">
        <Badge tone={kycTone(status)} dot>{kycLabel(status)}</Badge>
        {user.memberCode && <span className="num text-sm text-ink-3">Member ID {user.memberCode}</span>}
      </div>

      {error && <Notice tone="flag" title="Couldn’t load your KYC">{error}</Notice>}
      {status === 'REJECTED' && (
        <Notice tone="flag" title="Your KYC was rejected">
          {data?.rejectionReason || 'The foreman did not give a reason.'} Upload a corrected document below to resubmit.
        </Notice>
      )}
      {status === 'VERIFIED' && (
        <Notice tone="ok" icon={<ShieldCheck className="size-4 text-ok" />} title="You’re verified">
          You can be enrolled in groups, contribute and bid. <Link href="/dashboard" className="font-medium text-pine underline">Go to dashboard</Link>
        </Notice>
      )}
      {status === 'UNDER_REVIEW' && <Notice tone="info" title="Under review">Your documents are with the foreman. You’ll get a notification when there’s a decision.</Notice>}

      {status !== 'VERIFIED' && (
        <form onSubmit={submit} className="space-y-5 rounded-2xl border border-rule bg-sheet p-6">
          <Field label="Document type">
            {(id) => (
              <Select id={id} value={docType} onChange={(e) => setDocType(e.target.value)}>
                <option value="AADHAAR">Aadhaar</option>
                <option value="PAN">PAN</option>
              </Select>
            )}
          </Field>
          <Field label="File" hint={`PDF, JPG or PNG, up to ${kb(max)}.`} error={fileError}>
            {(id, d) => (
              <input
                ref={input} id={id} aria-describedby={d} type="file" accept={ACCEPT}
                onChange={(e) => pick(e.target.files?.[0] ?? null)}
                className="block w-full rounded-lg border border-dashed border-rule-2 bg-paper p-3 text-sm file:mr-3 file:rounded-md file:border-0 file:bg-pine file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-board-ink"
              />
            )}
          </Field>
          <p className="flex items-center gap-2 text-[13px] text-ink-3"><Lock className="size-3.5" aria-hidden /> Files are encrypted before they’re stored and only a foreman can open them.</p>
          <Button type="submit" size="lg" loading={busy} disabled={!file}><Upload className="size-4" aria-hidden /> Upload document</Button>
        </form>
      )}

      <section aria-labelledby="uploaded">
        <h2 id="uploaded" className="text-xl">Your documents</h2>
        {(data?.documents ?? []).length === 0 ? (
          <p className="mt-3 text-sm text-ink-2">Nothing uploaded yet.</p>
        ) : (
          <ul className="mt-4 divide-y divide-rule overflow-hidden rounded-xl border border-rule bg-sheet">
            {data!.documents.map((d) => (
              <li key={d.id} className="flex items-center gap-3 px-4 py-3 text-sm">
                <FileText className="size-4 shrink-0 text-ink-3" aria-hidden />
                <span className="min-w-0 flex-1 truncate">{d.fileName}</span>
                <Badge>{d.docType === 'AADHAAR' ? 'Aadhaar' : 'PAN'}</Badge>
                <span className="num hidden text-ink-3 sm:inline">{kb(d.sizeBytes)}</span>
                <span className="hidden text-ink-3 sm:inline">{formatDateTime(d.uploadedAt)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
