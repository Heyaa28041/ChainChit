import { Navbar } from '@/components/navbar';
import { LiveCyclesProvider } from '@/components/providers/live-cycles-provider';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <LiveCyclesProvider>
      <Navbar />
      <main className="mx-auto w-full max-w-7xl px-4 pb-28 pt-8 sm:px-6 md:pb-16 lg:px-8">{children}</main>
    </LiveCyclesProvider>
  );
}
