'use client';

import Link from 'next/link';
import { BellOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { EmptyState, Notice, PageHeader, PageLoader } from '@/components/ui/misc';
import { useToast } from '@/components/providers/toast-provider';
import { api, errorMessage } from '@/lib/api';
import { formatDateTime } from '@/lib/format';
import { useFetch } from '@/lib/use-fetch';
import type { NotificationRow } from '@/lib/types';
import { cn } from '@/lib/cn';

/** Where a notification should take you. */
function target(n: NotificationRow): string | null {
  if (n.entityType === 'DISPUTE' && n.entityId) return `/disputes/${n.entityId}`;
  if (n.entityType === 'PAYOUT' && n.entityId) return `/receipts/${n.entityId}`;
  if (n.type.startsWith('KYC_')) return '/kyc';
  if (n.type.startsWith('CONTRIBUTION') || n.type.includes('DELINQUENT')) return '/dashboard';
  if (n.type === 'FRAUD_FLAG') return '/dashboard';
  return null;
}

export default function NotificationsPage() {
  const toast = useToast();
  const { data, error, loading, reload } = useFetch<{ notifications: NotificationRow[]; unread: number }>('/api/notifications');

  async function markAll() {
    try {
      await api('/api/notifications', { method: 'POST', body: { all: true } });
      await reload();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Couldn’t update', body: errorMessage(err) });
    }
  }
  async function markOne(id: string) {
    await api('/api/notifications', { method: 'POST', body: { id } }).catch(() => {});
    void reload();
  }

  if (loading) return <PageLoader />;
  const list = data?.notifications ?? [];
  return (
    <div className="space-y-6">
      <PageHeader
        title="Notifications"
        description="Reminders, KYC decisions, fraud flags, payouts and dispute updates."
        actions={data?.unread ? <Button variant="secondary" onClick={markAll}>Mark all read</Button> : undefined}
      />
      {error && <Notice tone="flag" title="Couldn’t load notifications">{error}</Notice>}
      {list.length === 0 ? (
        <EmptyState icon={<BellOff className="size-8" />} title="Nothing yet">Updates about your contributions, bids and disputes will appear here.</EmptyState>
      ) : (
        <ul className="divide-y divide-rule overflow-hidden rounded-2xl border border-rule bg-sheet">
          {list.map((n) => {
            const href = target(n);
            const body = (
              <div className="flex items-start gap-3 p-4">
                <span className={cn('mt-1.5 size-2 shrink-0 rounded-full', n.readAt ? 'bg-transparent' : 'bg-pine')} aria-label={n.readAt ? 'Read' : 'Unread'} />
                <div className="min-w-0 flex-1">
                  <p className={cn('text-sm', !n.readAt && 'font-medium')}>{n.message}</p>
                  <p className="mt-0.5 text-[13px] text-ink-3">{formatDateTime(n.createdAt)}</p>
                </div>
              </div>
            );
            return (
              <li key={n.id}>
                {href ? <Link href={href} onClick={() => !n.readAt && void markOne(n.id)} className="block hover:bg-paper">{body}</Link> : (
                  <button type="button" onClick={() => !n.readAt && void markOne(n.id)} className="block w-full text-left hover:bg-paper">{body}</button>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
