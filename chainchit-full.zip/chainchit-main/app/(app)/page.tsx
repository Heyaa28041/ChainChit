'use client';

import Link from 'next/link';
import { ArrowRight, Gavel, Landmark } from 'lucide-react';
import { Badge, cycleStatusMeta } from '@/components/ui/badge';
import { buttonStyles } from '@/components/ui/button';
import { EmptyState, PageHeader, PageLoader } from '@/components/ui/misc';
import { Countdown } from '@/components/room/countdown';
import { useLiveCycles } from '@/components/providers/live-cycles-provider';
import { useSession } from '@/components/providers/session-provider';
import { formatDateTime, formatINR } from '@/lib/format';
import type { CycleSummary } from '@/lib/types';

function LiveRoomCard({ cycle }: { cycle: CycleSummary }) {
  return (
    <Link
      href={`/cycle/${cycle.id}`}
      className="on-board group flex flex-col justify-between rounded-2xl bg-board p-6 text-board-ink transition-colors hover:bg-board-2"
    >
      <div>
        <div className="flex items-center justify-between gap-3">
          <p className="flex items-center gap-1.5 text-[13px] font-medium text-brass">
            <span className="size-1.5 animate-pulse rounded-full bg-brass" aria-hidden /> Bidding open
          </p>
          <span className="num text-[13px] text-board-ink-3">Cycle {cycle.cycleNumber}</span>
        </div>
        <h2 className="mt-4 text-2xl text-board-ink">{cycle.groupName}</h2>
        <p className="num mt-1 text-sm text-board-ink-2">Pool of {formatINR(cycle.chitValue)}</p>
      </div>
      <div className="mt-8 flex items-end justify-between gap-4">
        <div className="min-w-0 scale-90 origin-bottom-left">
          <Countdown
            endTime={cycle.biddingEndTime}
            durationSeconds={cycle.biddingDurationSeconds}
            status={cycle.status}
            skewMs={0}
            onExpire={() => {}}
          />
        </div>
        <span className="flex items-center gap-1.5 text-sm font-medium text-board-ink">
          Enter room <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" aria-hidden />
        </span>
      </div>
    </Link>
  );
}

export default function LobbyPage() {
  const { user } = useSession();
  const { loaded, cycles, live } = useLiveCycles();

  if (!loaded) return <PageLoader label="Loading rooms" />;

  const others = cycles.filter((c) => c.status !== 'BIDDING_OPEN');
  const isForeman = user?.role === 'FOREMAN';

  return (
    <div className="space-y-10">
      <PageHeader
        title="Bidding rooms"
        description="Each chit group runs one reverse auction per cycle. The member who bids the lowest valid prize wins, and the difference is shared back as dividend."
      />

      {live.length > 0 ? (
        <section aria-label="Open now" className="grid gap-4 md:grid-cols-2">
          {live.map((c) => (
            <LiveRoomCard key={c.id} cycle={c} />
          ))}
        </section>
      ) : (
        <EmptyState
          icon={<Gavel className="size-8" />}
          title="No auction is open right now"
          action={
            isForeman ? (
              <Link href="/foreman" className={buttonStyles({})}>
                Open the foreman desk
              </Link>
            ) : undefined
          }
        >
          {isForeman
            ? 'Start a cycle from the foreman desk and members will see it here.'
            : 'When the foreman opens a bidding window it shows up here, and you can join straight away.'}
        </EmptyState>
      )}

      {others.length > 0 && (
        <section aria-labelledby="past-title">
          <h2 id="past-title" className="text-xl">
            Other cycles
          </h2>
          <div className="mt-4 overflow-x-auto rounded-2xl border border-rule bg-sheet">
            <table className="w-full min-w-[40rem] text-left text-sm">
              <thead className="border-b border-rule text-ink-3">
                <tr>
                  <th scope="col" className="px-5 py-3 font-medium">Group</th>
                  <th scope="col" className="px-3 py-3 font-medium">Cycle</th>
                  <th scope="col" className="px-3 py-3 font-medium">Status</th>
                  <th scope="col" className="px-3 py-3 font-medium">Winner</th>
                  <th scope="col" className="px-3 py-3 text-right font-medium">Prize</th>
                  <th scope="col" className="px-5 py-3 text-right font-medium">Opened</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-rule">
                {others.map((c) => {
                  const meta = cycleStatusMeta(c.status);
                  return (
                    <tr key={c.id} className="hover:bg-paper/60">
                      <td className="px-5 py-3">
                        <Link href={`/cycle/${c.id}`} className="inline-flex items-center gap-2 font-medium text-pine underline-offset-4 hover:underline">
                          <Landmark className="size-4 text-ink-3" aria-hidden /> {c.groupName}
                        </Link>
                      </td>
                      <td className="num px-3 py-3">{c.cycleNumber}</td>
                      <td className="px-3 py-3">
                        <Badge tone={meta.tone} dot>{meta.label}</Badge>
                      </td>
                      <td className="px-3 py-3">{c.winnerName ?? <span className="text-ink-3">None yet</span>}</td>
                      <td className="num px-3 py-3 text-right">{formatINR(c.payoutAmount)}</td>
                      <td className="num px-5 py-3 text-right text-ink-2">{formatDateTime(c.biddingStartTime ?? c.createdAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}
