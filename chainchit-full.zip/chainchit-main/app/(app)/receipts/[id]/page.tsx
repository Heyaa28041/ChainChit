'use client';

import { use } from 'react';
import { CheckCircle2, Printer, ShieldX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Notice, PageLoader } from '@/components/ui/misc';
import { Badge } from '@/components/ui/badge';
import { formatDateTime, formatINR } from '@/lib/format';
import { useFetch } from '@/lib/use-fetch';

interface ReceiptRes {
  receipt: {
    receiptId: string; groupCode: string | null; groupName: string; cycleNumber: number; winnerName: string; winnerCode: string | null;
    payoutAmount: number; chitValue: number; dividendPerMember: number; escrowReleased: number; contributionsReleased: number; issuedAt: string;
  };
  signature: string; signerKeyId: string; signatureValid: boolean; publicKeyPem: string;
}

/** FR28: the settlement receipt, re-verified against the ledger's Ed25519 key every time it's opened. */
export default function ReceiptPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data, loading, error } = useFetch<ReceiptRes>(`/api/receipts/${id}`);
  if (loading) return <PageLoader />;
  if (error || !data) return <Notice tone="flag" title="Couldn’t load this receipt">{error}</Notice>;
  const r = data.receipt;
  const row = (label: string, value: React.ReactNode) => (
    <div className="flex items-baseline gap-2 py-1.5"><dt className="text-sm text-ink-2">{label}</dt><span className="leader" aria-hidden /><dd className="num text-right font-medium">{value}</dd></div>
  );

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <article className="rounded-2xl border border-rule bg-sheet p-7 print:border-0">
        <p className="text-[13px] font-medium uppercase tracking-wide text-ink-3">Settlement receipt</p>
        <h1 className="mt-1 text-3xl">{formatINR(r.payoutAmount)}</h1>
        <p className="num mt-1 text-sm text-ink-2">{r.receiptId}</p>
        <dl className="mt-6">
          {row('Paid to', `${r.winnerName}${r.winnerCode ? ` (${r.winnerCode})` : ''}`)}
          {row('Group', `${r.groupCode} · ${r.groupName}`)}
          {row('Cycle', r.cycleNumber)}
          {row('Pool value', formatINR(r.chitValue))}
          {row('Dividend per member', formatINR(r.dividendPerMember))}
          {row('Escrow released', `${formatINR(r.escrowReleased)} (${r.contributionsReleased} contributions)`)}
          {row('Issued', formatDateTime(r.issuedAt))}
        </dl>
        <div className="mt-6 border-t border-dashed border-rule-2 pt-4">
          <p className="flex items-center gap-2 text-sm font-medium">
            {data.signatureValid ? <CheckCircle2 className="size-4 text-ok" aria-hidden /> : <ShieldX className="size-4 text-flag" aria-hidden />}
            {data.signatureValid ? 'Digital signature verified' : 'Signature does NOT verify'}
            <Badge>Ed25519</Badge>
          </p>
          <p className="mt-2 break-all text-[12px] text-ink-3">Key {data.signerKeyId}<br />Signature {data.signature}</p>
        </div>
      </article>
      <div className="flex gap-2 print:hidden"><Button variant="secondary" onClick={() => window.print()}><Printer className="size-4" aria-hidden /> Print</Button></div>
    </div>
  );
}
