import { Logo } from '@/components/brand/logo';

const steps = [
  { title: 'Bid the prize down', body: 'Each member names the lowest payout they will accept from the pool.' },
  { title: 'The lowest valid bid wins', body: 'A Z-score check holds any underbid that is statistically out of line.' },
  { title: 'Everyone shares the discount', body: 'What the winner gives up is paid back to the group as dividends.' },
];

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-dvh lg:grid-cols-[1.1fr_1fr]">
      <aside className="on-board relative hidden flex-col justify-between overflow-hidden bg-board px-12 py-10 text-board-ink lg:flex">
        <Logo inverted />

        <div className="max-w-lg">
          <h1 className="text-[3.4rem] leading-[1.02] text-board-ink">Chit auctions you can audit.</h1>
          <p className="mt-5 max-w-md text-base text-board-ink-2">
            Members bid the prize down in real time. Every bid is checked against the group&apos;s own history and
            every action is sealed into a SHA-256 chain that anyone with oversight can verify.
          </p>

          <ol className="mt-10 space-y-5 border-l border-board-rule pl-6">
            {steps.map((s, i) => (
              <li key={s.title} className="relative">
                <span
                  className="absolute -left-[2.15rem] top-0.5 flex size-5 items-center justify-center rounded-full bg-board-2 font-display text-xs font-semibold text-brass ring-1 ring-board-rule"
                  aria-hidden
                >
                  {i + 1}
                </span>
                <p className="font-medium text-board-ink">{s.title}</p>
                <p className="mt-0.5 text-sm text-board-ink-2">{s.body}</p>
              </li>
            ))}
          </ol>
        </div>

        <p className="text-sm text-board-ink-3">Permissioned groups · KYC-verified members · Escrow held until fraud checks clear</p>

        {/* the one flourish: a pool amount stepping down, like a reverse auction */}
        <div
          aria-hidden
          className="pointer-events-none absolute -right-6 top-24 select-none font-display text-[11rem] font-semibold leading-none text-board-2"
        >
          ₹
        </div>
      </aside>

      <div className="flex min-h-dvh flex-col px-5 py-8 sm:px-10">
        <div className="lg:hidden">
          <Logo />
        </div>
        <div className="mx-auto flex w-full max-w-sm flex-1 flex-col justify-center py-10">{children}</div>
      </div>
    </div>
  );
}
