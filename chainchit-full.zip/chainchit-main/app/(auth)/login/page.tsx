'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { AlertCircle, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Field, Input } from '@/components/ui/field';
import { useSession } from '@/components/providers/session-provider';
import { api, errorMessage } from '@/lib/api';
import type { AuthUser } from '@/lib/types';

function homeFor(user: Pick<AuthUser, 'role'>) {
  if (user.role === 'FOREMAN') return '/foreman';
  if (user.role === 'OVERSIGHT_VIEWER') return '/audit';
  return '/';
}

export default function LoginPage() {
  const router = useRouter();
  const { user, ready, refresh } = useSession();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Already signed in → go straight to the right home.
  useEffect(() => {
    if (ready && user) router.replace(homeFor(user));
  }, [ready, user, router]);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const data = await api<{ user: AuthUser }>('/api/auth/login', {
        method: 'POST',
        body: { email, password },
      });
      await refresh();
      router.replace(homeFor(data.user));
    } catch (err) {
      setError(errorMessage(err));
      setLoading(false);
    }
  }

  return (
    <div>
      <h2 className="text-3xl">Sign in</h2>
      <p className="mt-2 text-sm text-ink-2">Use the email and password you registered with.</p>

      <form onSubmit={handleLogin} className="mt-8 space-y-5">
        <Field label="Email">
          {(id) => (
            <Input
              id={id}
              type="email"
              required
              autoComplete="email"
              inputMode="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
            />
          )}
        </Field>

        <Field label="Password">
          {(id) => (
            <div className="relative">
              <Input
                id={id}
                type={showPassword ? 'text' : 'password'}
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pr-11"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-1.5 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-md text-ink-3 hover:text-ink"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
          )}
        </Field>

        {error && (
          <div role="alert" className="flex items-start gap-2 rounded-lg bg-flag-wash px-3 py-2.5 text-sm text-flag">
            <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden />
            <span>{error}</span>
          </div>
        )}

        <Button type="submit" size="lg" loading={loading} className="w-full">
          {loading ? 'Signing in' : 'Sign in'}
        </Button>
      </form>

      <p className="mt-8 text-sm text-ink-2">
        New to ChainChit?{' '}
        <Link href="/register" className="font-medium text-pine underline underline-offset-4 hover:text-pine-2">
          Create a member account
        </Link>
      </p>

      <div className="mt-10 border-t border-rule pt-5">
        <p className="text-[13px] text-ink-3">Trying the seeded demo?</p>
        <button
          type="button"
          onClick={() => {
            setEmail('foreman@chainchit.io');
            setPassword('Password@123');
            setError(null);
          }}
          className="mt-1 text-sm font-medium text-pine underline underline-offset-4 hover:text-pine-2"
        >
          Fill in the foreman login
        </button>
      </div>
    </div>
  );
}
