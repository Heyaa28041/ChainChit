'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { AlertCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Field, Input } from '@/components/ui/field';
import { Notice } from '@/components/ui/misc';
import { useSession } from '@/components/providers/session-provider';
import { api, errorMessage } from '@/lib/api';

export default function RegisterPage() {
  const router = useRouter();
  const { user, ready, refresh } = useSession();
  const [form, setForm] = useState({ name: '', email: '', password: '', mobile: '', govtId: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (ready && user) router.replace('/');
  }, [ready, user, router]);

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await api('/api/auth/register', { method: 'POST', body: form });
      await refresh();
      router.replace('/kyc');
    } catch (err) {
      setError(errorMessage(err));
      setLoading(false);
    }
  }

  return (
    <div>
      <h2 className="text-3xl">Create your account</h2>
      <p className="mt-2 text-sm text-ink-2">Members are approved by the foreman before they can bid.</p>

      <form onSubmit={handleRegister} className="mt-8 space-y-4">
        <Field label="Full legal name">
          {(id) => (
            <Input id={id} required autoComplete="name" value={form.name} onChange={set('name')} placeholder="As on your ID" />
          )}
        </Field>
        <Field label="Email">
          {(id) => (
            <Input
              id={id}
              type="email"
              required
              autoComplete="email"
              inputMode="email"
              value={form.email}
              onChange={set('email')}
            />
          )}
        </Field>
        <Field label="Password" hint="At least 6 characters.">
          {(id, describedBy) => (
            <Input
              id={id}
              type="password"
              required
              minLength={6}
              autoComplete="new-password"
              aria-describedby={describedBy}
              value={form.password}
              onChange={set('password')}
            />
          )}
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Mobile number">
            {(id) => (
              <Input
                id={id}
                type="tel"
                required
                autoComplete="tel"
                inputMode="tel"
                value={form.mobile}
                onChange={set('mobile')}
              />
            )}
          </Field>
          <Field label="PAN or Aadhaar">
            {(id) => (
              <Input
                id={id}
                required
                autoComplete="off"
                value={form.govtId}
                onChange={(e) => setForm((f) => ({ ...f, govtId: e.target.value.toUpperCase() }))}
                className="font-mono text-sm tracking-wide"
              />
            )}
          </Field>
        </div>

        <Notice tone="brass" icon={<Clock className="size-4 text-brass-ink" aria-hidden />}>
          Your account starts as <strong>KYC pending</strong>. You can look around straight away; bidding opens once the
          foreman approves your ID.
        </Notice>

        {error && (
          <div role="alert" className="flex items-start gap-2 rounded-lg bg-flag-wash px-3 py-2.5 text-sm text-flag">
            <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden />
            <span>{error}</span>
          </div>
        )}

        <Button type="submit" size="lg" loading={loading} className="w-full">
          {loading ? 'Creating account' : 'Create account'}
        </Button>
      </form>

      <p className="mt-8 text-sm text-ink-2">
        Already registered?{' '}
        <Link href="/login" className="font-medium text-pine underline underline-offset-4 hover:text-pine-2">
          Sign in
        </Link>
      </p>
    </div>
  );
}
