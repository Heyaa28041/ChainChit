import { NextResponse } from 'next/server';
import { requireRole } from '@/lib/auth';
import { buildSignedExport } from '@/lib/server/exports';

/** Whole-ledger signed export (?format=csv|pdf, optional ?groupId=). */
export async function GET(req: Request) {
  try {
    const auth = await requireRole('FOREMAN', 'OVERSIGHT_VIEWER');
    if ('error' in auth) return auth.error;
    const q = new URL(req.url).searchParams;
    const format = (q.get('format') || 'csv').toLowerCase();
    if (format !== 'csv' && format !== 'pdf') return NextResponse.json({ error: 'format must be csv or pdf', code: 'VALIDATION' }, { status: 400 });
    const out = await buildSignedExport({ groupId: q.get('groupId') || undefined, format, exportedBy: `${auth.user.name} (${auth.user.role})` });
    return new Response(new Uint8Array(out.body), {
      headers: { 'Content-Type': out.contentType, 'Content-Disposition': `attachment; filename="${out.filename}"`, 'X-Export-SHA256': out.sha256, 'X-Export-Signature': out.signature, 'Cache-Control': 'no-store' },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
