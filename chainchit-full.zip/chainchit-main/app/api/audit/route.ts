import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { auditLogs, users } from '@/lib/db/schema';
import { desc, eq, and, type SQL } from 'drizzle-orm';
import { verifyAuditChainIntegrity } from '@/lib/audit-logger';
import { requireRole } from '@/lib/auth';

/** NFR09: the queryable ledger. Filters: ?groupId=&action=&entityId=&limit= (default 100, max 1000). */
export async function GET(req: Request) {
  try {
    const auth = await requireRole('FOREMAN', 'OVERSIGHT_VIEWER');
    if ('error' in auth) return auth.error;
    const q = new URL(req.url).searchParams;
    const limit = Math.min(1000, Math.max(1, Number(q.get('limit')) || 100));

    const conds: SQL[] = [];
    if (q.get('groupId')) conds.push(eq(auditLogs.groupId, q.get('groupId')!));
    if (q.get('action')) conds.push(eq(auditLogs.action, q.get('action')!));
    if (q.get('entityId')) conds.push(eq(auditLogs.entityId, q.get('entityId')!));

    const logs = await db
      .select({
        id: auditLogs.id, sequence: auditLogs.sequence, actorId: auditLogs.actorId, actorName: users.name, actorRole: auditLogs.actorRole,
        action: auditLogs.action, entityType: auditLogs.entityType, entityId: auditLogs.entityId, groupId: auditLogs.groupId,
        payloadJson: auditLogs.payloadJson, previousHash: auditLogs.previousHash, entryHash: auditLogs.entryHash,
        signature: auditLogs.signature, signerKeyId: auditLogs.signerKeyId, timestamp: auditLogs.timestamp,
      })
      .from(auditLogs).leftJoin(users, eq(auditLogs.actorId, users.id))
      .where(conds.length ? and(...conds) : undefined)
      .orderBy(desc(auditLogs.sequence)).limit(limit);

    return NextResponse.json({ logs, integrity: await verifyAuditChainIntegrity() });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
