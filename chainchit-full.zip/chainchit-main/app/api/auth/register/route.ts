import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { users } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { hashPassword, startSession } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { validateRegistration } from '@/lib/validation';
import { encryptField } from '@/lib/server/crypto';
import { nextMemberCode } from '@/lib/server/codes';

/** FR01 / FR05: public self-registration always onboards a MEMBER. Foreman and oversight accounts are created by a foreman (POST /api/foreman/users). */
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const invalid = validateRegistration(body);
    if (invalid) return NextResponse.json({ error: invalid, code: 'VALIDATION' }, { status: 400 });

    const email = body.email.toLowerCase().trim();
    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) return NextResponse.json({ error: 'An account with this email address already exists', code: 'DUPLICATE_EMAIL' }, { status: 409 });

    const newUser = await db.transaction(async (tx) => {
      const memberCode = await nextMemberCode(tx);
      const [u] = await tx.insert(users).values({
        memberCode,
        name: body.name.trim(),
        email,
        passwordHash: hashPassword(body.password),
        mobile: body.mobile.trim(),
        govtId: encryptField(body.govtId.trim()),
        role: 'MEMBER',
        kycStatus: 'PENDING',
        trustScore: 100.0,
      }).returning();
      await logAuditEvent({
        actorId: u.id, actorRole: 'MEMBER', action: 'MEMBER_REGISTERED', entityType: 'USER', entityId: u.id,
        payload: { memberCode, name: u.name, email: u.email, kycStatus: u.kycStatus },
      }, tx);
      return u;
    });

    await startSession(newUser.id);
    return NextResponse.json({
      success: true,
      user: { id: newUser.id, memberCode: newUser.memberCode, name: newUser.name, email: newUser.email, role: newUser.role, kycStatus: newUser.kycStatus, trustScore: newUser.trustScore },
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
