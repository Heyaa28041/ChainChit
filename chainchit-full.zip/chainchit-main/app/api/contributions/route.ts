import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { contributions, cycles, chitGroups, groupMembers } from '@/lib/db/schema';
import { and, desc, eq, inArray } from 'drizzle-orm';
import { getCurrentUser, requireRole } from '@/lib/auth';
import { makeContribution } from '@/lib/server/contributions';
import { contributionAmount, dueState } from '@/lib/schedule';

/** FR12: contribution history. Members see their own; foreman / oversight can filter by group or cycle. */
export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const q = new URL(req.url).searchParams;
    const cycleId = q.get('cycleId');
    const groupId = q.get('groupId');

    let rows = await db
      .select({ c: contributions, cycleNumber: cycles.cycleNumber, groupId: cycles.groupId })
      .from(contributions).innerJoin(cycles, eq(contributions.cycleId, cycles.id))
      .orderBy(desc(contributions.paidAt));
    if (user.role === 'MEMBER') rows = rows.filter((r) => r.c.memberId === user.id);
    if (cycleId) rows = rows.filter((r) => r.c.cycleId === cycleId);
    if (groupId) rows = rows.filter((r) => r.groupId === groupId);
    return NextResponse.json({ contributions: rows.map((r) => ({ ...r.c, cycleNumber: r.cycleNumber, groupId: r.groupId })) });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** FR12 / FR13: pay this cycle's contribution; confirmed funds are locked in escrow immediately. */
export async function POST(req: Request) {
  try {
    const auth = await requireRole('MEMBER');
    if ('error' in auth) return auth.error;
    const { cycleId, amount, mode, simulateDecline } = await req.json();
    if (!cycleId) return NextResponse.json({ error: 'cycleId is required', code: 'VALIDATION' }, { status: 400 });
    if (amount != null && !(Number(amount) > 0)) return NextResponse.json({ error: 'Invalid amount', code: 'VALIDATION' }, { status: 400 });

    const res = await makeContribution(auth.user, { cycleId, amount: amount == null ? undefined : Number(amount), mode, simulateDecline: !!simulateDecline });
    if (!res.ok) return NextResponse.json({ error: res.error, code: res.code }, { status: res.status });
    return NextResponse.json({ success: true, contribution: res.contribution, escrowStatus: res.contribution.escrowStatus }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
