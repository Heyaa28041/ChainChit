import { NextResponse } from 'next/server';
import { requireRole } from '@/lib/auth';
import { settleCycle } from '@/lib/server/settlement';

/** FR27-FR30: release escrow to the winner via the payout contract and issue the signed receipt. */
export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;
    const { id: cycleId } = await params;

    const res = await settleCycle(cycleId, auth.user);
    if (!res.ok) return NextResponse.json({ error: res.error, code: res.code }, { status: res.status });
    return NextResponse.json({
      success: true,
      receiptId: res.receipt.receiptId,
      receipt: res.receipt,
      signature: res.payout.signature,
      signerKeyId: res.payout.signerKeyId,
      payoutId: res.payout.id,
    });
  } catch (err: any) {
    console.error('Settlement error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
