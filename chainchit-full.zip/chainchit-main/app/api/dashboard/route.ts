import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { bids, chitGroups, contributions, cycles, disputes, fraudAlerts, groupMembers, kycDocuments, notifications, payouts, users, auditLogs } from '@/lib/db/schema';
import { and, desc, eq, inArray, isNull, sql } from 'drizzle-orm';
import { getCurrentUser } from '@/lib/auth';
import { contributionAmount, dueState } from '@/lib/schedule';
import { getWinFrequency } from '@/lib/fraud-detector';
import { verifyAuditChainIntegrity } from '@/lib/audit-logger';
import { maybeSweep } from '@/lib/server/reminders';

/** FR35: one endpoint, three shapes. The role decides what is returned, so a member can never receive foreman data. */
export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    await maybeSweep();
    const now = new Date();
    const [{ unread }] = await db.select({ unread: sql<number>`count(*)::int` }).from(notifications).where(and(eq(notifications.userId, user.id), isNull(notifications.readAt)));

    /* ------------------------------ MEMBER ------------------------------ */
    if (user.role === 'MEMBER') {
      const [me] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
      const docs = await db.select({ id: kycDocuments.id, docType: kycDocuments.docType, fileName: kycDocuments.fileName, uploadedAt: kycDocuments.uploadedAt }).from(kycDocuments).where(eq(kycDocuments.userId, user.id));

      const memberships = await db.select({ group: chitGroups, delinquent: groupMembers.delinquent }).from(groupMembers).innerJoin(chitGroups, eq(groupMembers.groupId, chitGroups.id)).where(eq(groupMembers.memberId, user.id));
      const groupIds = memberships.map((m) => m.group.id);

      const groupCycles = groupIds.length ? await db.select().from(cycles).where(inArray(cycles.groupId, groupIds)) : [];
      const myContribs = await db.select().from(contributions).where(eq(contributions.memberId, user.id)).orderBy(desc(contributions.paidAt));
      const paidCycles = new Set(myContribs.filter((c) => c.status === 'CONFIRMED').map((c) => c.cycleId));
      const groupById = new Map(memberships.map((m) => [m.group.id, m.group]));

      const upcoming = groupCycles
        .filter((c) => c.status !== 'SETTLED' && !paidCycles.has(c.id) && c.dueDate)
        .sort((a, b) => a.cycleNumber - b.cycleNumber)
        .slice(0, 20)
        .map((c) => {
          const g = groupById.get(c.groupId)!;
          return { cycleId: c.id, groupCode: g.code, cycleNumber: c.cycleNumber, dueDate: c.dueDate, amount: contributionAmount(g.chitValue, g.numberOfMembers), state: dueState(now, c.dueDate!, g.gracePeriodDays, g.reminderLeadDays) };
        });

      const myBids = await db.select({ b: bids, cycleNumber: cycles.cycleNumber, groupId: cycles.groupId }).from(bids).innerJoin(cycles, eq(bids.cycleId, cycles.id)).where(eq(bids.memberId, user.id)).orderBy(desc(bids.timestamp)).limit(50);
      const myPayouts = await db.select().from(payouts).where(eq(payouts.winnerId, user.id)).orderBy(desc(payouts.payoutDate));
      const myDisputes = await db.select({ id: disputes.id, code: disputes.code, status: disputes.status, createdAt: disputes.createdAt }).from(disputes).where(eq(disputes.raisedBy, user.id)).orderBy(desc(disputes.createdAt));

      return NextResponse.json({
        role: 'MEMBER',
        profile: { id: me.id, memberCode: me.memberCode, name: me.name, kycStatus: me.kycStatus, kycRejectionReason: me.kycRejectionReason, trustScore: me.trustScore, documents: docs },
        groups: memberships.map((m) => ({ id: m.group.id, code: m.group.code, name: m.group.name, status: m.group.status, chitValue: m.group.chitValue, contributionAmount: contributionAmount(m.group.chitValue, m.group.numberOfMembers), delinquent: m.delinquent })),
        upcomingContributions: upcoming,
        contributionHistory: myContribs.map((c) => ({ id: c.id, cycleId: c.cycleId, amount: c.amount, status: c.status, escrowStatus: c.escrowStatus, paidAt: c.paidAt, paymentRef: c.paymentRef })),
        bidHistory: myBids.map(({ b, cycleNumber }) => ({ id: b.id, cycleId: b.cycleId, cycleNumber, bidAmount: b.bidAmount, status: b.status, zScore: b.zScore, timestamp: b.timestamp })),
        payoutHistory: myPayouts.map((p) => ({ id: p.id, cycleId: p.cycleId, amount: p.amount, receiptId: p.receiptId, payoutDate: p.payoutDate })),
        disputes: myDisputes,
        unreadNotifications: unread,
      });
    }

    /* ------------------------------ FOREMAN ------------------------------ */
    if (user.role === 'FOREMAN') {
      const myGroups = await db.select().from(chitGroups).where(eq(chitGroups.foremanId, user.id)).orderBy(desc(chitGroups.createdAt));
      const ids = myGroups.map((g) => g.id);
      const groupCycles = ids.length ? await db.select().from(cycles).where(inArray(cycles.groupId, ids)) : [];
      const cycleIds = groupCycles.map((c) => c.id);
      const rosters = ids.length ? await db.select({ groupId: groupMembers.groupId, memberId: groupMembers.memberId, delinquent: groupMembers.delinquent, name: users.name, memberCode: users.memberCode }).from(groupMembers).innerJoin(users, eq(groupMembers.memberId, users.id)).where(inArray(groupMembers.groupId, ids)) : [];
      const confirmed = cycleIds.length ? await db.select().from(contributions).where(and(inArray(contributions.cycleId, cycleIds), eq(contributions.status, 'CONFIRMED'))).orderBy(desc(contributions.paidAt)) : [];
      const groupPayouts = cycleIds.length ? await db.select().from(payouts).where(inArray(payouts.cycleId, cycleIds)).orderBy(desc(payouts.payoutDate)) : [];
      const groupBids = cycleIds.length ? await db.select({ b: bids, memberName: users.name }).from(bids).innerJoin(users, eq(bids.memberId, users.id)).where(inArray(bids.cycleId, cycleIds)).orderBy(desc(bids.timestamp)).limit(100) : [];
      const openAlerts = cycleIds.length ? await db.select().from(fraudAlerts).where(and(inArray(fraudAlerts.cycleId, cycleIds), eq(fraudAlerts.resolved, false))) : [];
      const openDisputes = cycleIds.length ? await db.select().from(disputes).where(and(inArray(disputes.cycleId, cycleIds), inArray(disputes.status, ['OPEN', 'ESCALATED']))) : [];
      const [{ pendingKyc }] = await db.select({ pendingKyc: sql<number>`count(*)::int` }).from(users).where(and(eq(users.role, 'MEMBER'), inArray(users.kycStatus, ['PENDING', 'UNDER_REVIEW'])));

      return NextResponse.json({
        role: 'FOREMAN',
        groups: myGroups.map((g) => {
          const roster = rosters.filter((r) => r.groupId === g.id);
          const gc = groupCycles.filter((c) => c.groupId === g.id).sort((a, b) => a.cycleNumber - b.cycleNumber);
          return {
            id: g.id, code: g.code, name: g.name, status: g.status, chitValue: g.chitValue, enrolled: roster.length, capacity: g.numberOfMembers, minMembers: g.minMembers,
            settledCycles: gc.filter((c) => c.status === 'SETTLED').length, totalCycles: g.totalCycles,
            delinquentMembers: roster.filter((r) => r.delinquent).map((r) => ({ id: r.memberId, name: r.name, memberCode: r.memberCode })),
            cycles: gc.map((c) => {
              const paid = confirmed.filter((p) => p.cycleId === c.id);
              return { id: c.id, cycleNumber: c.cycleNumber, status: c.status, dueDate: c.dueDate, collected: paid.length, expected: roster.length, escrowHeld: paid.filter((p) => p.escrowStatus === 'LOCKED').reduce((a, p) => a + p.amount, 0) };
            }),
          };
        }),
        pendingKycCount: pendingKyc,
        openFraudAlerts: openAlerts.length,
        openDisputes: openDisputes.length,
        recentContributions: confirmed.slice(0, 20),
        recentBids: groupBids.slice(0, 20).map(({ b, memberName }) => ({ id: b.id, cycleId: b.cycleId, memberName, bidAmount: b.bidAmount, status: b.status, zScore: b.zScore, timestamp: b.timestamp })),
        payoutHistory: groupPayouts.map((p) => ({ id: p.id, cycleId: p.cycleId, amount: p.amount, receiptId: p.receiptId, payoutDate: p.payoutDate })),
        unreadNotifications: unread,
      });
    }

    /* ------------------------------ OVERSIGHT VIEWER (read-only) ------------------------------ */
    const allGroups = await db.select().from(chitGroups).orderBy(desc(chitGroups.createdAt));
    const flagged = await db.select({ a: fraudAlerts, memberName: users.name }).from(fraudAlerts).innerJoin(users, eq(fraudAlerts.memberId, users.id)).orderBy(desc(fraudAlerts.createdAt)).limit(50);
    const allDisputes = await db.select({ id: disputes.id, code: disputes.code, status: disputes.status, cycleId: disputes.cycleId, createdAt: disputes.createdAt }).from(disputes).orderBy(desc(disputes.createdAt)).limit(50);
    const recent = await db.select({ sequence: auditLogs.sequence, timestamp: auditLogs.timestamp, action: auditLogs.action, entityType: auditLogs.entityType, entityId: auditLogs.entityId, entryHash: auditLogs.entryHash }).from(auditLogs).orderBy(desc(auditLogs.sequence)).limit(20);
    const payoutRows = await db.select({ id: payouts.id, cycleId: payouts.cycleId, amount: payouts.amount, receiptId: payouts.receiptId, payoutDate: payouts.payoutDate }).from(payouts).orderBy(desc(payouts.payoutDate)).limit(50);
    const members = await db.select({ memberId: groupMembers.memberId, groupId: groupMembers.groupId }).from(groupMembers);
    const review: { groupCode: string | null; memberId: string; wins: number; window: number }[] = [];
    for (const g of allGroups.filter((x) => x.allowRepeatWinners)) {
      for (const m of members.filter((x) => x.groupId === g.id)) {
        const f = await getWinFrequency(g.id, m.memberId);
        if (f.flagged) review.push({ groupCode: g.code, memberId: m.memberId, wins: f.wins, window: f.window });
      }
    }
    return NextResponse.json({
      role: 'OVERSIGHT_VIEWER',
      groups: allGroups.map((g) => ({ id: g.id, code: g.code, name: g.name, status: g.status, chitValue: g.chitValue })),
      flaggedBids: flagged.map(({ a, memberName }) => ({ alertId: a.id, bidId: a.bidId, cycleId: a.cycleId, memberName, rule: a.ruleViolated, severity: a.severity, resolved: a.resolved, resolutionAction: a.resolutionAction, createdAt: a.createdAt })),
      disputes: allDisputes,
      payouts: payoutRows,
      collusionReview: review,
      recentLedger: recent,
      integrity: await verifyAuditChainIntegrity({ maxAgeMs: 5000 }),
      unreadNotifications: unread,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
