import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { chitGroups, cycles, disputes } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { getCurrentUser, requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { notify } from '@/lib/server/notify';

async function load(id: string) {
  const [row] = await db
    .select({ d: disputes, groupId: chitGroups.id, groupCode: chitGroups.code, foremanId: chitGroups.foremanId })
    .from(disputes).innerJoin(cycles, eq(disputes.cycleId, cycles.id)).innerJoin(chitGroups, eq(cycles.groupId, chitGroups.id))
    .where(eq(disputes.id, id)).limit(1);
  return row;
}

/** Dispute with its auto-attached evidence. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const row = await load((await params).id);
    if (!row) return NextResponse.json({ error: 'Dispute not found' }, { status: 404 });
    if ((user.role === 'MEMBER' && row.d.raisedBy !== user.id) || (user.role === 'FOREMAN' && row.foremanId !== user.id)) {
      return NextResponse.json({ error: 'Access denied', code: 'FORBIDDEN' }, { status: 403 });
    }
    const { evidenceJson, ...d } = row.d;
    return NextResponse.json({ dispute: { ...d, groupCode: row.groupCode, evidence: JSON.parse(evidenceJson) } });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** FR33: foreman or oversight viewer marks a dispute RESOLVED, REJECTED or ESCALATED, with comments. */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireRole('FOREMAN', 'OVERSIGHT_VIEWER');
    if ('error' in auth) return auth.error;
    const row = await load((await params).id);
    if (!row) return NextResponse.json({ error: 'Dispute not found' }, { status: 404 });
    if (auth.user.role === 'FOREMAN' && row.foremanId !== auth.user.id) return NextResponse.json({ error: 'Not your group', code: 'FORBIDDEN' }, { status: 403 });

    const { status, comments } = await req.json();
    if (!['RESOLVED', 'REJECTED', 'ESCALATED'].includes(status)) {
      return NextResponse.json({ error: 'status must be RESOLVED, REJECTED or ESCALATED', code: 'VALIDATION' }, { status: 400 });
    }
    const note = typeof comments === 'string' ? comments.trim() : '';
    if (!note) return NextResponse.json({ error: 'Comments are required', code: 'COMMENTS_REQUIRED' }, { status: 400 });

    const current = row.d.status;
    if (current === 'RESOLVED' || current === 'REJECTED') return NextResponse.json({ error: `Dispute is already ${current}`, code: 'ALREADY_CLOSED' }, { status: 409 });
    if (current === 'ESCALATED' && status === 'ESCALATED') return NextResponse.json({ error: 'Dispute is already escalated', code: 'ALREADY_ESCALATED' }, { status: 409 });

    const stamp = `[${new Date().toISOString()} ${auth.user.role} ${auth.user.name}] ${note}`;
    const updated = await db.transaction(async (tx) => {
      const [d] = await tx.update(disputes).set({
        status, comments: row.d.comments ? `${row.d.comments}\n${stamp}` : stamp, resolvedBy: status === 'ESCALATED' ? null : auth.user.id, updatedAt: new Date(),
      }).where(eq(disputes.id, row.d.id)).returning();
      await logAuditEvent({
        actorId: auth.user.id, actorRole: auth.user.role, action: `DISPUTE_${status}`, entityType: 'DISPUTE', entityId: d.id, groupId: row.groupId,
        payload: { code: d.code, from: current, to: status, comments: note },
      }, tx);
      return d;
    });
    await notify({ userId: row.d.raisedBy, type: `DISPUTE_${status}`, message: `Your dispute ${updated.code} is now ${status.toLowerCase()}: ${note}`, entityType: 'DISPUTE', entityId: updated.id, dedupeKey: `dispute:${updated.id}:${status}:${Date.now()}` });
    return NextResponse.json({ success: true, dispute: { id: updated.id, code: updated.code, status: updated.status, comments: updated.comments } });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
