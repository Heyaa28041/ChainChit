import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { bids, chitGroups, cycles, disputes, groupMembers, payouts, users } from '@/lib/db/schema';
import { and, desc, eq, sql } from 'drizzle-orm';
import { getCurrentUser, requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { buildDisputeEvidence } from '@/lib/server/evidence';
import { notifyMany, oversightViewerIds } from '@/lib/server/notify';

const DAY = 86400000;

/** Members see their own disputes, a foreman those of their groups, an oversight viewer all of them. */
export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const status = new URL(req.url).searchParams.get('status');

    let rows = await db
      .select({ d: disputes, raisedByName: users.name, groupId: cycles.groupId, groupCode: chitGroups.code, foremanId: chitGroups.foremanId, cycleNumber: cycles.cycleNumber })
      .from(disputes)
      .innerJoin(users, eq(disputes.raisedBy, users.id))
      .innerJoin(cycles, eq(disputes.cycleId, cycles.id))
      .innerJoin(chitGroups, eq(cycles.groupId, chitGroups.id))
      .orderBy(desc(disputes.createdAt));
    if (user.role === 'MEMBER') rows = rows.filter((r) => r.d.raisedBy === user.id);
    if (user.role === 'FOREMAN') rows = rows.filter((r) => r.foremanId === user.id);
    if (status) rows = rows.filter((r) => r.d.status === status);

    return NextResponse.json({
      disputes: rows.map(({ d, ...rest }) => ({ id: d.id, code: d.code, status: d.status, description: d.description, comments: d.comments, bidId: d.bidId, payoutId: d.payoutId, cycleId: d.cycleId, createdAt: d.createdAt, updatedAt: d.updatedAt, raisedBy: d.raisedBy, raisedByName: rest.raisedByName, groupId: rest.groupId, groupCode: rest.groupCode, cycleNumber: rest.cycleNumber })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** FR31 / FR32: raise a dispute against a bid or a payout inside the group's dispute window; evidence is attached automatically. */
export async function POST(req: Request) {
  try {
    const auth = await requireRole('MEMBER');
    if ('error' in auth) return auth.error;
    const { bidId, payoutId, description } = await req.json();
    if ((!bidId && !payoutId) || (bidId && payoutId)) {
      return NextResponse.json({ error: 'Provide exactly one of bidId or payoutId', code: 'VALIDATION' }, { status: 400 });
    }
    const text = typeof description === 'string' ? description.trim() : '';
    if (!text) return NextResponse.json({ error: 'A description of the dispute is required', code: 'VALIDATION' }, { status: 400 });

    let cycleId: string;
    let eventTime: Date;
    if (payoutId) {
      const [p] = await db.select().from(payouts).where(eq(payouts.id, payoutId)).limit(1);
      if (!p) return NextResponse.json({ error: 'Payout not found' }, { status: 404 });
      cycleId = p.cycleId;
      eventTime = p.payoutDate;
    } else {
      const [b] = await db.select().from(bids).where(eq(bids.id, bidId)).limit(1);
      if (!b) return NextResponse.json({ error: 'Bid not found' }, { status: 404 });
      cycleId = b.cycleId;
      eventTime = b.timestamp;
    }
    const [cycle] = await db.select().from(cycles).where(eq(cycles.id, cycleId)).limit(1);
    const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, cycle.groupId)).limit(1);

    const [enrolled] = await db.select({ id: groupMembers.id }).from(groupMembers).where(and(eq(groupMembers.groupId, group.id), eq(groupMembers.memberId, auth.user.id))).limit(1);
    if (!enrolled) return NextResponse.json({ error: 'Only members of this group can raise a dispute', code: 'NOT_ENROLLED' }, { status: 403 });

    // A bid's event time is when the cycle settled, if it has; otherwise when the bid was placed.
    const reference = bidId && cycle.settledAt ? cycle.settledAt : eventTime;
    if (Date.now() > reference.getTime() + group.disputeWindowDays * DAY) {
      return NextResponse.json({ error: 'Dispute window has closed', code: 'DISPUTE_WINDOW_CLOSED' }, { status: 409 });
    }

    const { json, sha256 } = await buildDisputeEvidence({ cycleId, bidId, payoutId, raisedBy: auth.user.id });

    const dispute = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(727004)`);
      const r: any = await tx.execute(sql`select coalesce(max(substring(code from 2)::int), 0) + 1 as n from disputes where code ~ '^D[0-9]+$'`);
      const code = `D${String((r.rows ?? r)[0].n).padStart(3, '0')}`;
      const [d] = await tx.insert(disputes).values({ code, raisedBy: auth.user.id, cycleId, bidId: bidId ?? null, payoutId: payoutId ?? null, description: text, evidenceJson: json }).returning();
      await logAuditEvent({
        actorId: auth.user.id, actorRole: 'MEMBER', action: 'DISPUTE_RAISED', entityType: 'DISPUTE', entityId: d.id, groupId: group.id,
        payload: { code, cycleId, bidId: bidId ?? null, payoutId: payoutId ?? null, evidenceSha256: sha256 },
      }, tx);
      return d;
    });

    await notifyMany([group.foremanId, ...(await oversightViewerIds())], {
      type: 'DISPUTE_RAISED', message: `Dispute ${dispute.code} raised on ${group.code} cycle ${cycle.cycleNumber}.`, entityType: 'DISPUTE', entityId: dispute.id, dedupeKey: `dispute:${dispute.id}`,
    });
    return NextResponse.json({ success: true, dispute: { id: dispute.id, code: dispute.code, status: dispute.status, cycleId }, evidenceAttached: true, evidenceSha256: sha256 }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
