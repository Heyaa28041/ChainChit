import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';

/**
 * FR16 / FT-26: there is no way to withdraw escrow other than the payout contract
 * (settleCycle). This endpoint exists so any attempt is refused loudly and recorded.
 * The database enforces the same rule with a trigger, so a direct SQL UPDATE is refused too.
 */
async function refuse(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Sign in required', code: 'UNAUTHENTICATED' }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  await logAuditEvent({
    actorId: user.id, actorRole: user.role, action: 'ESCROW_WITHDRAWAL_REJECTED', entityType: 'CHIT_GROUP', entityId: String(body.groupId ?? 'unknown'),
    groupId: typeof body.groupId === 'string' ? body.groupId : null, payload: { attempted: body },
  });
  return NextResponse.json({ error: 'Withdrawal rejected: escrow funds can only be released by the payout contract.', code: 'ESCROW_WITHDRAWAL_FORBIDDEN' }, { status: 403 });
}
export const POST = refuse;
export const PUT = refuse;
export const PATCH = refuse;
export const DELETE = refuse;
