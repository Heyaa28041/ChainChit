import { NextResponse } from 'next/server';
import { verifySignedCsv } from '@/lib/server/exports';

/** Public: an external auditor posts the CSV text (body: { csv }) to check it is untouched. */
export async function POST(req: Request) {
  try {
    const { csv } = await req.json();
    if (typeof csv !== 'string') return NextResponse.json({ error: 'csv (string) is required' }, { status: 400 });
    return NextResponse.json(verifySignedCsv(csv));
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
