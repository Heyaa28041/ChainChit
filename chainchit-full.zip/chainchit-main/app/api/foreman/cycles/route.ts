import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { cycles, chitGroups, groupMembers } from '@/lib/db/schema';
import { and, asc, eq, ne, sql } from 'drizzle-orm';
import { requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { maintenanceOverlap } from '@/lib/server/maintenance';

/** FR10 / FR17: start the next scheduled cycle of a group and open its bidding window. */
export async function POST(req: Request) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;

    const { groupId, durationSeconds } = await req.json();
    if (!groupId) return NextResponse.json({ error: 'groupId is required', code: 'VALIDATION' }, { status: 400 });

    const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, groupId)).limit(1);
    if (!group) return NextResponse.json({ error: 'Group not found' }, { status: 404 });
    if (group.status === 'COMPLETED') return NextResponse.json({ error: 'This group has completed all its cycles', code: 'GROUP_COMPLETED' }, { status: 409 });

    const duration = durationSeconds == null ? group.biddingWindowSeconds : Number(durationSeconds);
    if (!Number.isInteger(duration) || duration < 10 || duration > 30 * 86400) {
      return NextResponse.json({ error: 'Bidding window must be between 10 seconds and 30 days', code: 'VALIDATION' }, { status: 400 });
    }

    const [{ n: enrolled }] = await db.select({ n: sql<number>`count(*)::int` }).from(groupMembers).where(eq(groupMembers.groupId, groupId));
    if (enrolled < group.minMembers) {
      return NextResponse.json({ error: `Minimum members not enrolled (${enrolled} of ${group.minMembers} required)`, code: 'MIN_MEMBERS_NOT_MET' }, { status: 409 });
    }

    const result = await db.transaction(async (tx) => {
      await tx.select({ id: chitGroups.id }).from(chitGroups).where(eq(chitGroups.id, groupId)).for('update');
      const unfinished = await tx.select().from(cycles).where(and(eq(cycles.groupId, groupId), ne(cycles.status, 'SCHEDULED'), ne(cycles.status, 'SETTLED'))).limit(1);
      if (unfinished.length) return { error: `Cycle ${unfinished[0].cycleNumber} is still ${unfinished[0].status}; settle it first`, code: 'CYCLE_IN_PROGRESS', status: 409 } as const;

      const [next] = await tx.select().from(cycles).where(and(eq(cycles.groupId, groupId), eq(cycles.status, 'SCHEDULED'))).orderBy(asc(cycles.cycleNumber)).limit(1);
      if (!next) return { error: 'No scheduled cycle remains', code: 'NO_SCHEDULED_CYCLE', status: 409 } as const;

      const start = new Date();
      const end = new Date(start.getTime() + duration * 1000);
      // NFR12 mirrored: bidding must not open inside a maintenance window.
      const clash = await maintenanceOverlap(start, end);
      if (clash.length) return { error: `A maintenance window (${clash[0].startsAt.toISOString()} – ${clash[0].endsAt.toISOString()}) overlaps this bidding window`, code: 'MAINTENANCE_OVERLAP', status: 409 } as const;

      const [opened] = await tx.update(cycles).set({
        status: 'BIDDING_OPEN', biddingStartTime: start, biddingEndTime: end, biddingDurationSeconds: duration, escrowStatus: 'LOCKED',
      }).where(eq(cycles.id, next.id)).returning();
      await logAuditEvent({
        actorId: auth.user.id, actorRole: 'FOREMAN', action: 'CYCLE_OPENED', entityType: 'CYCLE', entityId: opened.id, groupId,
        payload: { groupCode: group.code, cycleNumber: opened.cycleNumber, durationSeconds: duration, endsAt: end.toISOString() },
      }, tx);
      return { cycle: opened } as const;
    });
    if ('error' in result) return NextResponse.json({ error: result.error, code: result.code }, { status: result.status });
    return NextResponse.json({ success: true, cycle: result.cycle }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
