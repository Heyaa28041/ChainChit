import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { chitGroups, cycles, groupMembers, users } from '@/lib/db/schema';
import { and, eq, ne, sql } from 'drizzle-orm';
import { requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';

/** FR07: enrolment and removal are only allowed before the group's first cycle begins. */
async function enrolmentOpen(groupId: string): Promise<boolean> {
  const started = await db.select({ id: cycles.id }).from(cycles).where(and(eq(cycles.groupId, groupId), ne(cycles.status, 'SCHEDULED'))).limit(1);
  return started.length === 0;
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;
    const { id: groupId } = await params;
    const { memberId } = await req.json();

    const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, groupId)).limit(1);
    if (!group) return NextResponse.json({ error: 'Group not found' }, { status: 404 });
    if (!(await enrolmentOpen(groupId))) return NextResponse.json({ error: 'Enrolment is closed for this group', code: 'ENROLMENT_CLOSED' }, { status: 409 });

    const [member] = await db.select().from(users).where(eq(users.id, String(memberId ?? ''))).limit(1);
    if (!member || member.role !== 'MEMBER') return NextResponse.json({ error: 'Member not found' }, { status: 404 });
    if (member.kycStatus !== 'VERIFIED') return NextResponse.json({ error: 'KYC not verified', code: 'KYC_NOT_VERIFIED' }, { status: 400 });

    const result = await db.transaction(async (tx) => {
      // Lock the group row so two enrolments cannot both take the last seat.
      await tx.select({ id: chitGroups.id }).from(chitGroups).where(eq(chitGroups.id, groupId)).for('update');
      const [{ n }] = await tx.select({ n: sql<number>`count(*)::int` }).from(groupMembers).where(eq(groupMembers.groupId, groupId));
      if (n >= group.numberOfMembers) return { error: 'Group is full', code: 'GROUP_FULL', status: 409 } as const;
      const inserted = await tx.insert(groupMembers).values({ groupId, memberId: member.id }).onConflictDoNothing().returning();
      if (inserted.length === 0) return { error: 'Member is already enrolled', code: 'ALREADY_ENROLLED', status: 409 } as const;
      await logAuditEvent({
        actorId: auth.user.id, actorRole: 'FOREMAN', action: 'MEMBER_ENROLLED', entityType: 'CHIT_GROUP', entityId: groupId, groupId,
        payload: { memberId: member.id, memberCode: member.memberCode, enrolledCount: n + 1 },
      }, tx);
      return { enrolledCount: n + 1 } as const;
    });
    if ('error' in result) return NextResponse.json({ error: result.error, code: result.code }, { status: result.status });
    return NextResponse.json({ success: true, ...result }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;
    const { id: groupId } = await params;
    const memberId = new URL(req.url).searchParams.get('memberId') ?? (await req.json().catch(() => ({}))).memberId;
    if (!memberId) return NextResponse.json({ error: 'memberId is required', code: 'VALIDATION' }, { status: 400 });

    if (!(await enrolmentOpen(groupId))) return NextResponse.json({ error: 'Enrolment is closed for this group', code: 'ENROLMENT_CLOSED' }, { status: 409 });

    const [member] = await db.select().from(users).where(eq(users.id, memberId)).limit(1);
    const removed = await db.transaction(async (tx) => {
      const rows = await tx.delete(groupMembers).where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.memberId, memberId))).returning();
      if (rows.length === 0) return false;
      await logAuditEvent({
        actorId: auth.user.id, actorRole: 'FOREMAN', action: 'MEMBER_REMOVED', entityType: 'CHIT_GROUP', entityId: groupId, groupId,
        payload: { memberId, memberCode: member?.memberCode },
      }, tx);
      return true;
    });
    if (!removed) return NextResponse.json({ error: 'Member is not enrolled in this group', code: 'NOT_ENROLLED' }, { status: 404 });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
