import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { chitGroups, cycles, groupMembers, users } from '@/lib/db/schema';
import { asc, eq } from 'drizzle-orm';
import { getCurrentUser, requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';

/** Group detail with its schedule (FR11) and roster. Members only see groups they belong to. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const { id } = await params;
    const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, id)).limit(1);
    if (!group) return NextResponse.json({ error: 'Group not found' }, { status: 404 });

    const roster = await db.select({ id: users.id, memberCode: users.memberCode, name: users.name, kycStatus: users.kycStatus, trustScore: users.trustScore, delinquent: groupMembers.delinquent })
      .from(groupMembers).innerJoin(users, eq(groupMembers.memberId, users.id)).where(eq(groupMembers.groupId, id));
    if (user.role === 'MEMBER' && !roster.some((r) => r.id === user.id)) {
      return NextResponse.json({ error: 'Not a member of this group', code: 'FORBIDDEN' }, { status: 403 });
    }
    const schedule = await db.select({
      id: cycles.id, cycleNumber: cycles.cycleNumber, status: cycles.status, startDate: cycles.startDate, endDate: cycles.endDate, dueDate: cycles.dueDate, settledAt: cycles.settledAt,
    }).from(cycles).where(eq(cycles.groupId, id)).orderBy(asc(cycles.cycleNumber));
    return NextResponse.json({ group, roster, schedule });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

const NUMERIC_FIELDS: Record<string, { min: number; max?: number; int?: boolean }> = {
  fraudThresholdZ: { min: 0.5, max: 10 },
  gracePeriodDays: { min: 0, max: 60, int: true },
  reminderLeadDays: { min: 0, max: 30, int: true },
  disputeWindowDays: { min: 0, max: 90, int: true },
  biddingWindowSeconds: { min: 30, max: 14 * 86400, int: true },
  winFreqWindow: { min: 1, max: 60, int: true },
  winFreqMinWins: { min: 1, max: 60, int: true },
  minMembers: { min: 2, max: 50, int: true },
};

/** Group edits (cycle configuration, fraud thresholds). Takes effect immediately, no redeploy (NFR11); logged with actor and timestamp (NFR14). */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;
    const { id } = await params;
    const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, id)).limit(1);
    if (!group) return NextResponse.json({ error: 'Group not found' }, { status: 404 });

    const body = await req.json();
    const patch: Record<string, any> = {};
    for (const [key, rule] of Object.entries(NUMERIC_FIELDS)) {
      if (body[key] === undefined) continue;
      const v = Number(body[key]);
      if (!Number.isFinite(v) || v < rule.min || (rule.max != null && v > rule.max) || (rule.int && !Number.isInteger(v))) {
        return NextResponse.json({ error: `${key} must be ${rule.int ? 'a whole number ' : ''}between ${rule.min} and ${rule.max ?? '∞'}`, code: 'VALIDATION' }, { status: 400 });
      }
      patch[key] = v;
    }
    if (typeof body.name === 'string' && body.name.trim()) patch.name = body.name.trim();
    if (typeof body.allowRepeatWinners === 'boolean') patch.allowRepeatWinners = body.allowRepeatWinners;
    if (patch.minMembers != null && patch.minMembers > group.numberOfMembers) {
      return NextResponse.json({ error: `minMembers cannot exceed the group size (${group.numberOfMembers})`, code: 'VALIDATION' }, { status: 400 });
    }
    if (Object.keys(patch).length === 0) return NextResponse.json({ error: 'No editable fields supplied', code: 'VALIDATION' }, { status: 400 });

    const before = Object.fromEntries(Object.keys(patch).map((k) => [k, (group as any)[k]]));
    const updated = await db.transaction(async (tx) => {
      const [g] = await tx.update(chitGroups).set(patch).where(eq(chitGroups.id, id)).returning();
      await logAuditEvent({ actorId: auth.user.id, actorRole: 'FOREMAN', action: 'GROUP_EDITED', entityType: 'CHIT_GROUP', entityId: id, groupId: id, payload: { before, after: patch } }, tx);
      return g;
    });
    return NextResponse.json({ success: true, group: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
