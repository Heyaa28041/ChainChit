import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { chitGroups, groupMembers, users, cycles } from '@/lib/db/schema';
import { eq, desc, sql, inArray } from 'drizzle-orm';
import { getCurrentUser, requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { nextGroupCode } from '@/lib/server/codes';
import { buildSchedule, contributionAmount } from '@/lib/schedule';

/** FR09: every signed-in role can list active and completed groups. ?status=ACTIVE|COMPLETED filters. */
export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const status = new URL(req.url).searchParams.get('status');
    let rows = await db.select().from(chitGroups).orderBy(desc(chitGroups.createdAt));
    if (status === 'ACTIVE' || status === 'COMPLETED') rows = rows.filter((g) => g.status === status);

    const counts = await db.select({ groupId: groupMembers.groupId, count: sql<number>`count(*)::int` }).from(groupMembers).groupBy(groupMembers.groupId);
    const settled = await db.select({ groupId: cycles.groupId, count: sql<number>`count(*)::int` }).from(cycles).where(eq(cycles.status, 'SETTLED')).groupBy(cycles.groupId);
    const countByGroup = new Map(counts.map((c) => [c.groupId, c.count]));
    const settledByGroup = new Map(settled.map((c) => [c.groupId, c.count]));

    const groups = rows.map((g) => ({
      ...g,
      enrolledCount: countByGroup.get(g.id) ?? 0,
      settledCycles: settledByGroup.get(g.id) ?? 0,
      contributionAmount: contributionAmount(g.chitValue, g.numberOfMembers),
    }));
    return NextResponse.json({ groups, active: groups.filter((g) => g.status === 'ACTIVE'), completed: groups.filter((g) => g.status === 'COMPLETED') });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** FR06 / FR08 / FR11: create the group, its unique ID, and its full cycle schedule. */
export async function POST(req: Request) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;
    const user = auth.user;

    const b = await req.json();
    const chitValue = Number(b.chitValue);
    const capacity = Number(b.numberOfMembers);
    const durationDays = b.cycleDurationDays == null ? 30 : Number(b.cycleDurationDays);
    const totalCycles = b.totalCycles == null ? capacity : Number(b.totalCycles);
    const minMembers = b.minMembers == null ? capacity : Number(b.minMembers);

    if (!b.name?.toString().trim()) return NextResponse.json({ error: 'Group name is required', code: 'VALIDATION' }, { status: 400 });
    if (!(chitValue > 0)) return NextResponse.json({ error: 'Chit value must be greater than 0', code: 'VALIDATION' }, { status: 400 });
    if (!Number.isInteger(capacity) || capacity < 2) return NextResponse.json({ error: 'A chit group needs at least 2 members', code: 'VALIDATION' }, { status: 400 });
    if (capacity > 50) return NextResponse.json({ error: 'A group supports at most 50 members', code: 'VALIDATION' }, { status: 400 });
    if (!Number.isInteger(durationDays) || durationDays < 1) return NextResponse.json({ error: 'Cycle duration must be at least 1 day', code: 'VALIDATION' }, { status: 400 });
    if (!Number.isInteger(totalCycles) || totalCycles < 1 || totalCycles > 120) return NextResponse.json({ error: 'Total cycles must be between 1 and 120', code: 'VALIDATION' }, { status: 400 });
    if (!Number.isInteger(minMembers) || minMembers < 2 || minMembers > capacity) return NextResponse.json({ error: `Minimum members must be between 2 and ${capacity}`, code: 'VALIDATION' }, { status: 400 });

    const memberIds: string[] = Array.isArray(b.memberIds) ? [...new Set<string>(b.memberIds)] : [];
    if (memberIds.length > capacity) return NextResponse.json({ error: `Cannot enroll ${memberIds.length} members in a group sized for ${capacity}`, code: 'VALIDATION' }, { status: 400 });
    if (memberIds.length) {
      const found = await db.select().from(users).where(inArray(users.id, memberIds));
      const bad = memberIds.filter((id) => !found.find((f) => f.id === id && f.role === 'MEMBER' && f.kycStatus === 'VERIFIED'));
      if (bad.length) return NextResponse.json({ error: 'Only KYC-verified members can be enrolled', code: 'KYC_NOT_VERIFIED', memberIds: bad }, { status: 400 });
    }

    const startDate = b.startDate ? new Date(b.startDate) : new Date();
    if (Number.isNaN(startDate.getTime())) return NextResponse.json({ error: 'Invalid start date', code: 'VALIDATION' }, { status: 400 });

    const group = await db.transaction(async (tx) => {
      const code = await nextGroupCode(tx);
      const [g] = await tx.insert(chitGroups).values({
        code,
        name: b.name.trim(),
        chitValue,
        numberOfMembers: capacity,
        cycleDurationDays: durationDays,
        totalCycles,
        minMembers,
        startDate,
        biddingWindowSeconds: b.biddingWindowSeconds ? Number(b.biddingWindowSeconds) : 180,
        gracePeriodDays: b.gracePeriodDays != null ? Number(b.gracePeriodDays) : 5,
        reminderLeadDays: b.reminderLeadDays != null ? Number(b.reminderLeadDays) : 3,
        disputeWindowDays: b.disputeWindowDays != null ? Number(b.disputeWindowDays) : 7,
        allowRepeatWinners: !!b.allowRepeatWinners,
        foremanId: user.id,
        historicalMeanBid: chitValue * 0.85,
        historicalSdBid: chitValue * 0.04,
        fraudThresholdZ: b.fraudThresholdZ ? Number(b.fraudThresholdZ) : 2.5,
      }).returning();

      const schedule = buildSchedule(startDate, totalCycles, durationDays);
      await tx.insert(cycles).values(schedule.map((c) => ({
        groupId: g.id, cycleNumber: c.cycleNumber, status: 'SCHEDULED' as const, startDate: c.startDate, endDate: c.endDate, dueDate: c.dueDate,
      })));
      if (memberIds.length) await tx.insert(groupMembers).values(memberIds.map((memberId) => ({ groupId: g.id, memberId })));

      // FR08: the unique group ID goes on the ledger.
      await logAuditEvent({
        actorId: user.id, actorRole: 'FOREMAN', action: 'GROUP_CREATED', entityType: 'CHIT_GROUP', entityId: g.id, groupId: g.id,
        payload: { code, name: g.name, chitValue, numberOfMembers: capacity, cycleDurationDays: durationDays, totalCycles, minMembers, enrolledCount: memberIds.length, firstCycleStart: schedule[0].startDate.toISOString(), lastCycleEnd: schedule[schedule.length - 1].endDate.toISOString() },
      }, tx);
      return g;
    });

    return NextResponse.json({ success: true, group, scheduleCycles: totalCycles }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
