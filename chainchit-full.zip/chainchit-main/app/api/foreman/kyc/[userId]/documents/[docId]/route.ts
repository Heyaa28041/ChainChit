import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { kycDocuments } from '@/lib/db/schema';
import { and, eq } from 'drizzle-orm';
import fs from 'fs/promises';
import path from 'path';
import { requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { decryptBuffer, sha256Hex } from '@/lib/server/crypto';
import { KYC_DIR } from '@/lib/server/kyc-storage';

/** Foreman-only: decrypt and stream a KYC document for review. Every view is written to the ledger. */
export async function GET(_req: Request, { params }: { params: Promise<{ userId: string; docId: string }> }) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;
    const { userId, docId } = await params;
    const [doc] = await db.select().from(kycDocuments).where(and(eq(kycDocuments.id, docId), eq(kycDocuments.userId, userId))).limit(1);
    if (!doc) return NextResponse.json({ error: 'Document not found' }, { status: 404 });

    const plain = decryptBuffer(await fs.readFile(path.join(KYC_DIR, doc.storageKey)));
    if (sha256Hex(plain) !== doc.sha256) return NextResponse.json({ error: 'Stored document failed its integrity check' }, { status: 500 });

    await logAuditEvent({ actorId: auth.user.id, actorRole: 'FOREMAN', action: 'KYC_DOCUMENT_VIEWED', entityType: 'KYC_DOCUMENT', entityId: doc.id, payload: { userId, docType: doc.docType } });
    return new Response(new Uint8Array(plain), {
      headers: { 'Content-Type': doc.mimeType, 'Content-Disposition': `inline; filename="${doc.fileName.replace(/"/g, '')}"`, 'Cache-Control': 'no-store' },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
