import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { users, kycDocuments } from '@/lib/db/schema';
import { eq, desc } from 'drizzle-orm';
import { requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { decryptField, maskGovtId } from '@/lib/server/crypto';
import { notify } from '@/lib/server/notify';

export async function GET() {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;

    const members = await db.select().from(users).where(eq(users.role, 'MEMBER')).orderBy(desc(users.createdAt));
    const docs = await db.select({
      id: kycDocuments.id, userId: kycDocuments.userId, docType: kycDocuments.docType, fileName: kycDocuments.fileName,
      mimeType: kycDocuments.mimeType, sizeBytes: kycDocuments.sizeBytes, uploadedAt: kycDocuments.uploadedAt,
    }).from(kycDocuments);

    return NextResponse.json({
      members: members.map((m) => ({
        id: m.id, memberCode: m.memberCode, name: m.name, email: m.email, mobile: m.mobile,
        govtId: maskGovtId(decryptField(m.govtId)), // the full number never leaves the server
        kycStatus: m.kycStatus, kycRejectionReason: m.kycRejectionReason, trustScore: m.trustScore, createdAt: m.createdAt,
        documents: docs.filter((d) => d.userId === m.id),
      })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** FR04: approve, or reject with a mandatory reason (stored on the member and in the ledger). */
export async function POST(req: Request) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;

    const { memberId, action, rejectionReason } = await req.json();
    if (!memberId || !['APPROVE', 'REJECT'].includes(action)) {
      return NextResponse.json({ error: 'Valid memberId and action (APPROVE or REJECT) required', code: 'VALIDATION' }, { status: 400 });
    }
    const reason = typeof rejectionReason === 'string' ? rejectionReason.trim() : '';
    if (action === 'REJECT' && !reason) {
      return NextResponse.json({ error: 'Reason is mandatory', code: 'REASON_REQUIRED' }, { status: 400 });
    }

    const [target] = await db.select().from(users).where(eq(users.id, memberId)).limit(1);
    if (!target || target.role !== 'MEMBER') return NextResponse.json({ error: 'Member not found' }, { status: 404 });

    if (action === 'APPROVE') {
      const docs = await db.select({ id: kycDocuments.id }).from(kycDocuments).where(eq(kycDocuments.userId, memberId));
      if (docs.length === 0) return NextResponse.json({ error: 'No KYC documents have been submitted by this member', code: 'NO_DOCUMENTS' }, { status: 409 });
    }

    const newStatus = action === 'APPROVE' ? 'VERIFIED' : 'REJECTED';
    const updated = await db.transaction(async (tx) => {
      const [u] = await tx.update(users)
        .set({ kycStatus: newStatus, kycRejectionReason: action === 'REJECT' ? reason : null })
        .where(eq(users.id, memberId)).returning();
      await logAuditEvent({
        actorId: auth.user.id, actorRole: 'FOREMAN', action: `KYC_${newStatus}`, entityType: 'USER', entityId: memberId,
        payload: { memberCode: u.memberCode, memberName: u.name, previousStatus: target.kycStatus, reason: action === 'REJECT' ? reason : 'KYC verified' },
      }, tx);
      return u;
    });

    await notify({
      userId: memberId, type: `KYC_${newStatus}`,
      message: action === 'APPROVE' ? 'Your KYC has been verified.' : `Your KYC was rejected: ${reason}`,
      entityType: 'USER', entityId: memberId, dedupeKey: `kyc:${memberId}:${Date.now()}`,
    });

    return NextResponse.json({ success: true, member: { id: updated.id, memberCode: updated.memberCode, name: updated.name, kycStatus: updated.kycStatus, kycRejectionReason: updated.kycRejectionReason } });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
