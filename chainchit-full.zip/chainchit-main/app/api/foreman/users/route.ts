import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { users } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { hashPassword, requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { validateRegistration } from '@/lib/validation';
import { encryptField } from '@/lib/server/crypto';
import { nextMemberCode } from '@/lib/server/codes';

/** FR05: a foreman onboards a user and assigns exactly one role (MEMBER, FOREMAN or OVERSIGHT_VIEWER). */
export async function POST(req: Request) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;

    const body = await req.json();
    if (!['MEMBER', 'FOREMAN', 'OVERSIGHT_VIEWER'].includes(body.role)) {
      return NextResponse.json({ error: 'role must be MEMBER, FOREMAN or OVERSIGHT_VIEWER', code: 'VALIDATION' }, { status: 400 });
    }
    const invalid = validateRegistration(body);
    if (invalid) return NextResponse.json({ error: invalid, code: 'VALIDATION' }, { status: 400 });

    const email = body.email.toLowerCase().trim();
    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) return NextResponse.json({ error: 'An account with this email address already exists', code: 'DUPLICATE_EMAIL' }, { status: 409 });

    const created = await db.transaction(async (tx) => {
      const memberCode = await nextMemberCode(tx);
      const staff = body.role !== 'MEMBER';
      const [u] = await tx.insert(users).values({
        memberCode, name: body.name.trim(), email, passwordHash: hashPassword(body.password), mobile: body.mobile.trim(),
        govtId: encryptField(body.govtId.trim()), role: body.role, kycStatus: staff ? 'VERIFIED' : 'PENDING',
      }).returning();
      await logAuditEvent({
        actorId: auth.user.id, actorRole: 'FOREMAN', action: 'USER_ONBOARDED', entityType: 'USER', entityId: u.id,
        payload: { memberCode, role: u.role, email: u.email },
      }, tx);
      return u;
    });
    return NextResponse.json({ success: true, user: { id: created.id, memberCode: created.memberCode, name: created.name, email: created.email, role: created.role, kycStatus: created.kycStatus } }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
