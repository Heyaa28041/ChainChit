import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { fraudAlerts, bids, cycles, users } from '@/lib/db/schema';
import { and, asc, eq } from 'drizzle-orm';
import { logAuditEvent } from '@/lib/audit-logger';
import { sseBroker } from '@/lib/sse-broker';
import { getCurrentUser } from '@/lib/auth';

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'FOREMAN') {
      return NextResponse.json({ error: 'Access denied. Foreman role required.', code: 'FORBIDDEN' }, { status: 403 });
    }

    const { alertId, action, reason } = await req.json();

    if (!alertId || !['OVERRIDDEN', 'DISQUALIFIED'].includes(action)) {
      return NextResponse.json({ error: 'Valid alertId and action (OVERRIDDEN or DISQUALIFIED) required' }, { status: 400 });
    }

    const [alert] = await db.select().from(fraudAlerts).where(eq(fraudAlerts.id, alertId)).limit(1);
    if (!alert) {
      return NextResponse.json({ error: 'Alert not found' }, { status: 404 });
    }
    if (alert.resolved) {
      return NextResponse.json({ error: 'This alert has already been resolved', code: 'ALREADY_RESOLVED' }, { status: 409 });
    }

    // 1. Update Alert status
    await db
      .update(fraudAlerts)
      .set({ resolved: true, resolutionAction: action })
      .where(eq(fraudAlerts.id, alertId));

    // 2. Update Bid status accordingly
    const newBidStatus = action === 'OVERRIDDEN' ? 'ACCEPTED' : 'REJECTED';
    await db.update(bids).set({ status: newBidStatus }).where(eq(bids.id, alert.bidId));

    // 3. Log into Audit Log
    await logAuditEvent({
      actorId: user.id,
      actorRole: 'FOREMAN',
      action: `FRAUD_ALERT_${action}`,
      entityType: 'FRAUD_ALERT',
      entityId: alertId,
      payload: {
        alertId,
        bidId: alert.bidId,
        action,
        reason: reason || 'Foreman manual adjudication',
      },
    });

    // 4. If the auction already closed, the ruling may change who rightfully won.
    const [cycle] = await db.select().from(cycles).where(eq(cycles.id, alert.cycleId)).limit(1);
    let winnerChanged = false;

    if (cycle && (cycle.status === 'BIDDING_CLOSED' || cycle.status === 'DISPUTED')) {
      const cycleBids = await db
        .select()
        .from(bids)
        .where(eq(bids.cycleId, cycle.id))
        .orderBy(asc(bids.bidAmount), asc(bids.timestamp));

      const rightfulWinner = cycleBids.find((b) => b.status === 'ACCEPTED' || b.status === 'WINNING_BID');
      const openAlerts = await db
        .select({ id: fraudAlerts.id })
        .from(fraudAlerts)
        .where(and(eq(fraudAlerts.cycleId, cycle.id), eq(fraudAlerts.resolved, false)));
      const stillHeld = openAlerts.length > 0;

      if (rightfulWinner && rightfulWinner.id !== cycle.winningBidId) {
        // Demote the previous winning bid, promote the new one
        if (cycle.winningBidId) {
          await db
            .update(bids)
            .set({ status: 'ACCEPTED' })
            .where(and(eq(bids.id, cycle.winningBidId), eq(bids.status, 'WINNING_BID')));
        }
        await db.update(bids).set({ status: 'WINNING_BID' }).where(eq(bids.id, rightfulWinner.id));
        await db
          .update(cycles)
          .set({
            status: 'BIDDING_CLOSED',
            winningBidId: rightfulWinner.id,
            winnerMemberId: rightfulWinner.memberId,
            payoutAmount: rightfulWinner.bidAmount,
            escrowStatus: stillHeld ? 'HELD_FOR_REVIEW' : 'LOCKED',
          })
          .where(eq(cycles.id, cycle.id));
        winnerChanged = true;

        const [winnerUser] = await db
          .select({ id: users.id, name: users.name, email: users.email })
          .from(users)
          .where(eq(users.id, rightfulWinner.memberId))
          .limit(1);

        await logAuditEvent({
          actorId: user.id,
          actorRole: 'FOREMAN',
          action: 'WINNER_REDETERMINED',
          entityType: 'CYCLE',
          entityId: cycle.id,
          payload: {
            winningBidId: rightfulWinner.id,
            winnerMemberId: rightfulWinner.memberId,
            winnerName: winnerUser?.name,
            winningAmount: rightfulWinner.bidAmount,
            trigger: `FRAUD_ALERT_${action}`,
          },
        });
        sseBroker.broadcast(`cycle:${cycle.id}`, 'WINNER_DETERMINED', {
          cycleId: cycle.id,
          winner: winnerUser,
          winningBid: rightfulWinner,
        });
      } else if (rightfulWinner && cycle.escrowStatus === 'HELD_FOR_REVIEW' && !stillHeld) {
        // Same winner, but nothing is left to investigate: release the hold on the escrow.
        await db.update(cycles).set({ escrowStatus: 'LOCKED' }).where(eq(cycles.id, cycle.id));
      } else if (!rightfulWinner) {
        await db
          .update(cycles)
          .set({ status: 'DISPUTED', escrowStatus: 'HELD_FOR_REVIEW' })
          .where(eq(cycles.id, cycle.id));
      }
    }

    sseBroker.broadcast(`cycle:${alert.cycleId}`, 'ALERT_RESOLVED', {
      alertId,
      bidId: alert.bidId,
      action,
      newBidStatus,
      winnerChanged,
    });

    return NextResponse.json({ success: true, alertId, action, newBidStatus, winnerChanged });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
