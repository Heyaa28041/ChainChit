import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { chitGroups } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { requireRole } from '@/lib/auth';
import { buildSignedExport } from '@/lib/server/exports';
import { logAuditEvent } from '@/lib/audit-logger';

/** FR34 / NFR15: GET /api/groups/:id/export?format=csv|pdf - Foreman (own groups) and Oversight Viewer. */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireRole('FOREMAN', 'OVERSIGHT_VIEWER');
    if ('error' in auth) return auth.error;
    const { id } = await params;
    const format = (new URL(req.url).searchParams.get('format') || 'csv').toLowerCase();
    if (format !== 'csv' && format !== 'pdf') return NextResponse.json({ error: 'format must be csv or pdf', code: 'VALIDATION' }, { status: 400 });

    const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, id)).limit(1);
    if (!group) return NextResponse.json({ error: 'Group not found' }, { status: 404 });
    if (auth.user.role === 'FOREMAN' && group.foremanId !== auth.user.id) return NextResponse.json({ error: 'Not your group', code: 'FORBIDDEN' }, { status: 403 });

    const out = await buildSignedExport({ groupId: id, format, exportedBy: `${auth.user.name} (${auth.user.role})` });
    await logAuditEvent({ actorId: auth.user.id, actorRole: auth.user.role, action: 'LEDGER_EXPORTED', entityType: 'CHIT_GROUP', entityId: id, groupId: id, payload: { format, sha256: out.sha256 } });
    return new Response(new Uint8Array(out.body), {
      headers: {
        'Content-Type': out.contentType,
        'Content-Disposition': `attachment; filename="${out.filename}"`,
        'X-Export-SHA256': out.sha256,
        'X-Export-Signature': out.signature,
        'Cache-Control': 'no-store',
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
