import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { chitGroups, groupMembers, auditLogs } from '@/lib/db/schema';
import { and, desc, eq } from 'drizzle-orm';
import { getCurrentUser } from '@/lib/auth';
import { verifyAuditChainIntegrity } from '@/lib/audit-logger';

/** FR29 / NFR09: the group's ledger, visible to its members, its foreman and oversight viewers. ?limit= (default 200). */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const { id } = await params;
    const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, id)).limit(1);
    if (!group) return NextResponse.json({ error: 'Group not found' }, { status: 404 });
    if (user.role === 'MEMBER') {
      const [m] = await db.select({ id: groupMembers.id }).from(groupMembers).where(and(eq(groupMembers.groupId, id), eq(groupMembers.memberId, user.id))).limit(1);
      if (!m) return NextResponse.json({ error: 'Not a member of this group', code: 'FORBIDDEN' }, { status: 403 });
    }
    if (user.role === 'FOREMAN' && group.foremanId !== user.id) return NextResponse.json({ error: 'Not your group', code: 'FORBIDDEN' }, { status: 403 });

    const limit = Math.min(1000, Math.max(1, Number(new URL(req.url).searchParams.get('limit')) || 200));
    const entries = await db.select({
      sequence: auditLogs.sequence, timestamp: auditLogs.timestamp, actorRole: auditLogs.actorRole, action: auditLogs.action, entityType: auditLogs.entityType,
      entityId: auditLogs.entityId, payloadJson: auditLogs.payloadJson, previousHash: auditLogs.previousHash, entryHash: auditLogs.entryHash, signature: auditLogs.signature,
    }).from(auditLogs).where(eq(auditLogs.groupId, id)).orderBy(desc(auditLogs.sequence)).limit(limit);
    const integrity = await verifyAuditChainIntegrity();
    return NextResponse.json({ group: { id: group.id, code: group.code, name: group.name }, entries, integrity: { valid: integrity.valid, totalEntries: integrity.totalEntries, message: integrity.message } });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
