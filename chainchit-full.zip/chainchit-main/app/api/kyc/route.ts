import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { kycDocuments, users } from '@/lib/db/schema';
import { eq, desc } from 'drizzle-orm';
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { KYC_DOC_TYPES, KYC_MAX_BYTES, validateKycFile } from '@/lib/validation';
import { encryptBuffer, sha256Hex } from '@/lib/server/crypto';
import { notifyMany } from '@/lib/server/notify';

import { KYC_DIR } from '@/lib/server/kyc-storage';

/** The member's own uploads and KYC state. */
export async function GET() {
  const auth = await requireRole('MEMBER');
  if ('error' in auth) return auth.error;
  const [me] = await db.select().from(users).where(eq(users.id, auth.user.id)).limit(1);
  const documents = await db
    .select({ id: kycDocuments.id, docType: kycDocuments.docType, fileName: kycDocuments.fileName, mimeType: kycDocuments.mimeType, sizeBytes: kycDocuments.sizeBytes, uploadedAt: kycDocuments.uploadedAt })
    .from(kycDocuments).where(eq(kycDocuments.userId, auth.user.id)).orderBy(desc(kycDocuments.uploadedAt));
  return NextResponse.json({ kycStatus: me.kycStatus, rejectionReason: me.kycRejectionReason, documents, maxBytes: KYC_MAX_BYTES });
}

/** FR02 / FR03: multipart upload (fields: docType, file). Validated, then stored AES-256-GCM encrypted. */
export async function POST(req: Request) {
  try {
    const auth = await requireRole('MEMBER');
    if ('error' in auth) return auth.error;

    // Reject oversized bodies before buffering them.
    const declared = Number(req.headers.get('content-length') || 0);
    if (declared > KYC_MAX_BYTES + 64 * 1024) {
      return NextResponse.json({ error: 'File exceeds permitted size', code: 'FILE_TOO_LARGE' }, { status: 413 });
    }

    const form = await req.formData();
    const docType = String(form.get('docType') || '').toUpperCase();
    const file = form.get('file');
    if (!(KYC_DOC_TYPES as readonly string[]).includes(docType)) {
      return NextResponse.json({ error: 'docType must be AADHAAR or PAN', code: 'VALIDATION' }, { status: 400 });
    }
    if (!(file instanceof File)) return NextResponse.json({ error: 'A file is required', code: 'VALIDATION' }, { status: 400 });

    const buf = Buffer.from(await file.arrayBuffer());
    const verdict = validateKycFile(file.name, buf);
    if ('error' in verdict) return NextResponse.json({ error: verdict.error, code: verdict.code }, { status: verdict.code === 'FILE_TOO_LARGE' ? 413 : 400 });

    await fs.mkdir(KYC_DIR, { recursive: true, mode: 0o700 });
    const storageKey = `${crypto.randomUUID()}.enc`;
    await fs.writeFile(path.join(KYC_DIR, storageKey), encryptBuffer(buf), { mode: 0o600 });

    const [me] = await db.select().from(users).where(eq(users.id, auth.user.id)).limit(1);
    const doc = await db.transaction(async (tx) => {
      const [d] = await tx.insert(kycDocuments).values({
        userId: me.id, docType, fileName: file.name.slice(0, 200), mimeType: verdict.mime, sizeBytes: buf.length, storageKey, sha256: sha256Hex(buf),
      }).returning();
      // Verified members stay verified; everyone else moves to review (also covers re-submission after rejection).
      if (me.kycStatus !== 'VERIFIED') {
        await tx.update(users).set({ kycStatus: 'UNDER_REVIEW', kycRejectionReason: null }).where(eq(users.id, me.id));
      }
      await logAuditEvent({
        actorId: me.id, actorRole: 'MEMBER', action: 'KYC_DOCUMENT_UPLOADED', entityType: 'KYC_DOCUMENT', entityId: d.id,
        payload: { docType, mimeType: verdict.mime, sizeBytes: buf.length, sha256: d.sha256 },
      }, tx);
      return d;
    });

    return NextResponse.json({
      success: true,
      document: { id: doc.id, docType: doc.docType, fileName: doc.fileName, mimeType: doc.mimeType, sizeBytes: doc.sizeBytes },
      kycStatus: me.kycStatus === 'VERIFIED' ? 'VERIFIED' : 'UNDER_REVIEW',
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
