import { NextResponse } from 'next/server';
import { publicKeyPem, signerKeyId } from '@/lib/server/crypto';

/** Public verification key (Ed25519) for ledger entries, receipts and exports. */
export async function GET() {
  return NextResponse.json({ algorithm: 'Ed25519', keyId: signerKeyId(), publicKeyPem: publicKeyPem() });
}
