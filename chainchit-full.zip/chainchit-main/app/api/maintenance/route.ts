import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { maintenanceWindows } from '@/lib/db/schema';
import { asc, eq } from 'drizzle-orm';
import { requireRole } from '@/lib/auth';
import { logAuditEvent } from '@/lib/audit-logger';
import { activeBiddingOverlap } from '@/lib/server/maintenance';

export async function GET() {
  const auth = await requireRole('FOREMAN', 'OVERSIGHT_VIEWER');
  if ('error' in auth) return auth.error;
  return NextResponse.json({ windows: await db.select().from(maintenanceWindows).orderBy(asc(maintenanceWindows.startsAt)) });
}

/** NFR12 / NFT-12: scheduled maintenance may never overlap an active bidding session. */
export async function POST(req: Request) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;
    const { startsAt, endsAt, reason } = await req.json();
    const start = new Date(startsAt);
    const end = new Date(endsAt);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) {
      return NextResponse.json({ error: 'startsAt and endsAt must be valid dates with endsAt after startsAt', code: 'VALIDATION' }, { status: 400 });
    }
    if (typeof reason !== 'string' || !reason.trim()) return NextResponse.json({ error: 'A reason is required', code: 'VALIDATION' }, { status: 400 });

    const clash = await activeBiddingOverlap(start, end);
    if (clash.length) {
      return NextResponse.json({
        error: 'Maintenance cannot be scheduled: it overlaps an active bidding session.', code: 'MAINTENANCE_OVERLAPS_BIDDING',
        conflicts: clash.map((c) => ({ cycleId: c.id, biddingStartTime: c.biddingStartTime, biddingEndTime: c.biddingEndTime })),
      }, { status: 409 });
    }
    const win = await db.transaction(async (tx) => {
      const [w] = await tx.insert(maintenanceWindows).values({ startsAt: start, endsAt: end, reason: reason.trim(), createdBy: auth.user.id }).returning();
      await logAuditEvent({ actorId: auth.user.id, actorRole: 'FOREMAN', action: 'MAINTENANCE_SCHEDULED', entityType: 'MAINTENANCE', entityId: w.id, groupId: null, payload: { startsAt: start.toISOString(), endsAt: end.toISOString(), reason: w.reason } }, tx);
      return w;
    });
    return NextResponse.json({ success: true, window: win }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const auth = await requireRole('FOREMAN');
    if ('error' in auth) return auth.error;
    const id = new URL(req.url).searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'id is required', code: 'VALIDATION' }, { status: 400 });
    const rows = await db.delete(maintenanceWindows).where(eq(maintenanceWindows.id, id)).returning();
    if (!rows.length) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    await logAuditEvent({ actorId: auth.user.id, actorRole: 'FOREMAN', action: 'MAINTENANCE_CANCELLED', entityType: 'MAINTENANCE', entityId: id, groupId: null, payload: {} });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
