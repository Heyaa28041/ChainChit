import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { runSweep } from '@/lib/server/reminders';

/**
 * Runs the reminder / missed-payment sweep (FR14, FR15). Call it from cron with the x-cron-secret header,
 * or as a foreman. `asOf` (ISO date) advances the clock and is refused in production.
 */
export async function POST(req: Request) {
  try {
    const secret = process.env.CRON_SECRET;
    const viaCron = !!secret && req.headers.get('x-cron-secret') === secret;
    if (!viaCron) {
      const user = await getCurrentUser();
      if (!user || user.role !== 'FOREMAN') return NextResponse.json({ error: 'Access denied. Foreman role required.', code: 'FORBIDDEN' }, { status: 403 });
    }
    const body = await req.json().catch(() => ({}));
    let asOf = new Date();
    if (body.asOf) {
      if (process.env.NODE_ENV === 'production') return NextResponse.json({ error: 'asOf is not allowed in production' }, { status: 400 });
      asOf = new Date(body.asOf);
      if (Number.isNaN(asOf.getTime())) return NextResponse.json({ error: 'Invalid asOf', code: 'VALIDATION' }, { status: 400 });
    }
    return NextResponse.json({ success: true, report: await runSweep(asOf) });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
