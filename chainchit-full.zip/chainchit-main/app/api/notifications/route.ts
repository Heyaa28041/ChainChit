import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { notifications } from '@/lib/db/schema';
import { and, desc, eq, isNull, sql } from 'drizzle-orm';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const rows = await db.select().from(notifications).where(eq(notifications.userId, user.id)).orderBy(desc(notifications.createdAt)).limit(50);
    const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(notifications).where(and(eq(notifications.userId, user.id), isNull(notifications.readAt)));
    return NextResponse.json({ notifications: rows, unread: n });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/** Mark one ({ id }) or all ({ all: true }) of the caller's notifications read. */
export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const { id, all } = await req.json();
    if (!id && !all) return NextResponse.json({ error: 'id or all required', code: 'VALIDATION' }, { status: 400 });
    const cond = all ? and(eq(notifications.userId, user.id), isNull(notifications.readAt)) : and(eq(notifications.userId, user.id), eq(notifications.id, id));
    const rows = await db.update(notifications).set({ readAt: new Date() }).where(cond).returning({ id: notifications.id });
    return NextResponse.json({ success: true, marked: rows.length });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
