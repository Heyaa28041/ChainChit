import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { chitGroups, cycles, payouts } from '@/lib/db/schema';
import { eq, or } from 'drizzle-orm';
import { getCurrentUser } from '@/lib/auth';
import { verifyReceipt } from '@/lib/server/settlement';

const UUID = /^[0-9a-f-]{36}$/i;

/** FR28: the settlement receipt (looked up by receipt ID or payout ID) with its Ed25519 signature re-verified on read. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const { id } = await params;
    const [row] = await db
      .select({ p: payouts, foremanId: chitGroups.foremanId })
      .from(payouts).innerJoin(cycles, eq(payouts.cycleId, cycles.id)).innerJoin(chitGroups, eq(cycles.groupId, chitGroups.id))
      .where(UUID.test(id) ? or(eq(payouts.receiptId, id), eq(payouts.id, id)) : eq(payouts.receiptId, id)).limit(1);
    if (!row) return NextResponse.json({ error: 'Receipt not found' }, { status: 404 });
    if ((user.role === 'MEMBER' && row.p.winnerId !== user.id) || (user.role === 'FOREMAN' && row.foremanId !== user.id)) {
      return NextResponse.json({ error: 'Access denied', code: 'FORBIDDEN' }, { status: 403 });
    }
    const v = verifyReceipt(row.p);
    return NextResponse.json({
      payoutId: row.p.id, receipt: JSON.parse(row.p.receiptJson), signature: row.p.signature, signerKeyId: row.p.signerKeyId,
      signed: row.p.receiptJson, signatureValid: v.valid, algorithm: v.algorithm, publicKeyPem: v.publicKeyPem,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
