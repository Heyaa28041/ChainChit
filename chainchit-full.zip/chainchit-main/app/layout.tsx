import type { Metadata, Viewport } from 'next';
import '@fontsource-variable/geist';
import '@fontsource-variable/geist-mono';
import '@fontsource-variable/bricolage-grotesque';
import './globals.css';
import { SessionProvider } from '@/components/providers/session-provider';
import { ToastProvider } from '@/components/providers/toast-provider';

export const metadata: Metadata = {
  title: {
    default: 'ChainChit — chit auctions you can audit',
    template: '%s · ChainChit',
  },
  description:
    'Reverse-auction chit funds with live statistical fraud checks and a tamper-evident SHA-256 audit trail.',
};

export const viewport: Viewport = {
  themeColor: '#eef0ea',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <SessionProvider>
          <ToastProvider>{children}</ToastProvider>
        </SessionProvider>
      </body>
    </html>
  );
}
