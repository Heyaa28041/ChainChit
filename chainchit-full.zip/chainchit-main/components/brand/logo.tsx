import Link from 'next/link';
import { cn } from '@/lib/cn';

/** A chit slip with punched notches and a falling bid line. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn('size-8', className)} aria-hidden>
      <rect width="32" height="32" rx="8" className="fill-pine" />
      <path
        d="M7 9.5a2.5 2.5 0 0 1 2.5-2.5h13A2.5 2.5 0 0 1 25 9.5v2.2a1.8 1.8 0 0 0 0 3.6v2.2a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 7 17.5v-2.2a1.8 1.8 0 0 0 0-3.6Z"
        className="fill-brass"
        transform="translate(0 2)"
      />
      <path d="M12 13.5h8M12 17.2l3 2.6 5-4" className="stroke-board" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </svg>
  );
}

export function Logo({ href = '/', inverted = false }: { href?: string; inverted?: boolean }) {
  return (
    <Link href={href} className="inline-flex items-center gap-2.5" aria-label="ChainChit home">
      <LogoMark />
      <span
        className={cn(
          'font-display text-xl font-semibold tracking-tight',
          inverted ? 'text-board-ink' : 'text-ink'
        )}
      >
        ChainChit
      </span>
    </Link>
  );
}
