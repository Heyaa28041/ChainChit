'use client';

import { useState } from 'react';
import { Dialog } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/field';
import { useToast } from '@/components/providers/toast-provider';
import { api, errorMessage } from '@/lib/api';

/** FR31: raise a dispute on a bid or a payout. Transaction history and fraud logs are attached automatically by the server. */
export function RaiseDisputeDialog({
  target,
  onClose,
  onRaised,
}: {
  target: { kind: 'bid' | 'payout'; id: string; label: string } | null;
  onClose: () => void;
  onRaised: () => void;
}) {
  const toast = useToast();
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit() {
    if (!target) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ dispute: { code: string } }>('/api/disputes', {
        method: 'POST',
        body: { [target.kind === 'bid' ? 'bidId' : 'payoutId']: target.id, description: text.trim() },
      });
      toast.push({ tone: 'success', title: `Dispute ${res.dispute.code} raised`, body: 'The foreman and oversight viewer have been told. Your transaction history and fraud-check logs were attached.' });
      setText('');
      onRaised();
      onClose();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog
      open={!!target}
      onClose={onClose}
      title="Raise a dispute"
      description={target ? `About ${target.label}. Disputes must be raised within the group’s dispute window.` : undefined}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={busy}>Cancel</Button>
          <Button onClick={submit} loading={busy} disabled={text.trim().length < 5}>Submit dispute</Button>
        </>
      }
    >
      <label htmlFor="dispute-text" className="mb-1.5 block text-[13px] font-medium text-ink-2">What went wrong?</label>
      <Textarea id="dispute-text" value={text} onChange={(e) => setText(e.target.value)} maxLength={600} autoFocus />
      {error && <p role="alert" className="mt-2 rounded-lg bg-flag-wash px-3 py-2 text-sm text-flag">{error}</p>}
    </Dialog>
  );
}
