'use client';

import Link from 'next/link';
import { useState } from 'react';
import { AlertTriangle, BellRing, CalendarClock, ShieldAlert, Trash2 } from 'lucide-react';
import { Badge, cycleStatusMeta } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Field, Input, Textarea } from '@/components/ui/field';
import { Notice } from '@/components/ui/misc';
import { DataTable, Stat } from '@/components/ui/tabs';
import { useToast } from '@/components/providers/toast-provider';
import { useFetch } from '@/lib/use-fetch';
import { api, errorMessage } from '@/lib/api';
import { formatDateTime, formatINR } from '@/lib/format';

export interface ForemanDash {
  groups: {
    id: string; code: string | null; name: string; status: string; chitValue: number; enrolled: number; capacity: number; minMembers: number;
    settledCycles: number; totalCycles: number; delinquentMembers: { id: string; name: string; memberCode: string | null }[];
    cycles: { id: string; cycleNumber: number; status: string; dueDate: string; collected: number; expected: number; escrowHeld: number }[];
  }[];
  pendingKycCount: number; openFraudAlerts: number; openDisputes: number;
  recentBids: { id: string; cycleId: string; memberName: string; bidAmount: number; status: string; zScore: number; timestamp: string }[];
  payoutHistory: { id: string; amount: number; receiptId: string; payoutDate: string }[];
}

interface MaintWindow { id: string; startsAt: string; endsAt: string; reason: string }

/** NFR12 maintenance windows + FR14/FR15 reminder sweep, kept together as "Operations". */
function Operations() {
  const toast = useToast();
  const { data, reload } = useFetch<{ windows: MaintWindow[] }>('/api/maintenance');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sweeping, setSweeping] = useState(false);

  async function schedule(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api('/api/maintenance', { method: 'POST', body: { startsAt: new Date(start).toISOString(), endsAt: new Date(end).toISOString(), reason } });
      toast.push({ tone: 'success', title: 'Maintenance scheduled' });
      setStart(''); setEnd(''); setReason('');
      await reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function sweep() {
    setSweeping(true);
    try {
      const r = await api<{ report: { reminders: number; delinquent: number } }>('/api/maintenance/sweep', { method: 'POST', body: {} });
      toast.push({ tone: 'info', title: 'Sweep complete', body: `${r.report.reminders} reminders sent, ${r.report.delinquent} members newly flagged.` });
    } catch (err) {
      toast.push({ tone: 'error', title: 'Sweep failed', body: errorMessage(err) });
    } finally {
      setSweeping(false);
    }
  }

  return (
    <section aria-labelledby="ops" className="grid gap-6 lg:grid-cols-2">
      <div className="rounded-2xl border border-rule bg-sheet p-5">
        <h2 id="ops" className="flex items-center gap-2 text-lg"><BellRing className="size-4" aria-hidden /> Reminders and missed payments</h2>
        <p className="mt-1 text-sm text-ink-2">Reminders go out before each due date; members past the grace period are flagged. This runs on its own; use it to run it now.</p>
        <Button className="mt-4" variant="secondary" loading={sweeping} onClick={sweep}>Run sweep now</Button>
      </div>

      <form onSubmit={schedule} className="rounded-2xl border border-rule bg-sheet p-5">
        <h2 className="flex items-center gap-2 text-lg"><CalendarClock className="size-4" aria-hidden /> Schedule maintenance</h2>
        <p className="mt-1 text-sm text-ink-2">Maintenance can’t overlap a live bidding session.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Field label="Starts">{(id) => <Input id={id} type="datetime-local" required value={start} onChange={(e) => setStart(e.target.value)} />}</Field>
          <Field label="Ends">{(id) => <Input id={id} type="datetime-local" required value={end} onChange={(e) => setEnd(e.target.value)} />}</Field>
        </div>
        <Field className="mt-3" label="Reason">{(id) => <Textarea id={id} className="min-h-16" required value={reason} onChange={(e) => setReason(e.target.value)} />}</Field>
        {error && <p role="alert" className="mt-3 rounded-lg bg-flag-wash px-3 py-2 text-sm text-flag">{error}</p>}
        <Button className="mt-4" type="submit" loading={busy}>Schedule</Button>
        {(data?.windows ?? []).length > 0 && (
          <ul className="mt-4 divide-y divide-rule border-t border-rule text-sm">
            {data!.windows.map((w) => (
              <li key={w.id} className="flex items-center justify-between gap-3 py-2">
                <span><span className="num">{formatDateTime(w.startsAt)} – {formatDateTime(w.endsAt)}</span><br /><span className="text-ink-3">{w.reason}</span></span>
                <button type="button" aria-label="Cancel maintenance" className="rounded p-1.5 text-ink-3 hover:bg-wash hover:text-flag" onClick={async () => { await api(`/api/maintenance?id=${w.id}`, { method: 'DELETE' }).catch(() => {}); void reload(); }}><Trash2 className="size-4" /></button>
              </li>
            ))}
          </ul>
        )}
      </form>
    </section>
  );
}

export function ForemanDashboard({ data }: { data: ForemanDash }) {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="KYC to review" value={data.pendingKycCount} hint="Members awaiting a decision" tone={data.pendingKycCount ? 'flag' : undefined} />
        <Stat label="Open fraud alerts" value={data.openFraudAlerts} hint="Hold the payout until ruled on" tone={data.openFraudAlerts ? 'flag' : 'ok'} />
        <Stat label="Open disputes" value={data.openDisputes} tone={data.openDisputes ? 'flag' : 'ok'} />
        <Stat label="Groups" value={data.groups.length} hint={`${data.groups.filter((g) => g.status === 'ACTIVE').length} active`} />
      </div>

      {(data.pendingKycCount > 0 || data.openFraudAlerts > 0 || data.openDisputes > 0) && (
        <Notice tone="brass" icon={<ShieldAlert className="size-4 text-brass-ink" />} title="Needs your attention">
          <ul className="list-inside list-disc">
            {data.pendingKycCount > 0 && <li><Link className="underline" href="/foreman">Review {data.pendingKycCount} KYC submission{data.pendingKycCount > 1 ? 's' : ''}</Link></li>}
            {data.openFraudAlerts > 0 && <li>{data.openFraudAlerts} flagged bid{data.openFraudAlerts > 1 ? 's' : ''} waiting for a ruling in the bidding room</li>}
            {data.openDisputes > 0 && <li><Link className="underline" href="/disputes">{data.openDisputes} dispute{data.openDisputes > 1 ? 's' : ''} to resolve</Link></li>}
          </ul>
        </Notice>
      )}

      <section aria-labelledby="fgroups" className="space-y-4">
        <div className="flex items-end justify-between gap-3">
          <h2 id="fgroups" className="text-xl">Your groups</h2>
          <Link href="/foreman" className="text-sm font-medium text-pine underline">New group</Link>
        </div>
        {data.groups.length === 0 && <p className="text-sm text-ink-2">No groups yet. Create one from the Foreman desk.</p>}
        {data.groups.map((g) => (
          <div key={g.id} className="rounded-2xl border border-rule bg-sheet p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <Link href={`/groups/${g.id}`} className="font-display text-lg font-semibold hover:underline">{g.name}</Link>
                <p className="num mt-0.5 text-sm text-ink-2">{g.code} · {formatINR(g.chitValue)} · {g.enrolled}/{g.capacity} enrolled (min {g.minMembers}) · {g.settledCycles}/{g.totalCycles} cycles settled</p>
              </div>
              <Badge tone={g.status === 'ACTIVE' ? 'ok' : 'info'}>{g.status === 'ACTIVE' ? 'Active' : 'Completed'}</Badge>
            </div>
            {g.delinquentMembers.length > 0 && (
              <p className="mt-3 flex flex-wrap items-center gap-2 text-sm text-flag"><AlertTriangle className="size-4" aria-hidden /> Delinquent: {g.delinquentMembers.map((m) => m.name).join(', ')}</p>
            )}
            <div className="mt-4">
              <DataTable head={['Cycle', 'Status', 'Due', 'Collected', 'In escrow']}>
                {g.cycles.map((c) => {
                  const m = cycleStatusMeta(c.status);
                  return (
                    <tr key={c.id}>
                      <td className="num px-4 py-2.5">{c.status === 'SCHEDULED' ? c.cycleNumber : <Link href={`/cycle/${c.id}`} className="underline">{c.cycleNumber}</Link>}</td>
                      <td className="px-4 py-2.5"><Badge tone={m.tone}>{m.label}</Badge></td>
                      <td className="px-4 py-2.5">{formatDateTime(c.dueDate)}</td>
                      <td className="num px-4 py-2.5">{c.collected}/{c.expected}</td>
                      <td className="num px-4 py-2.5">{formatINR(c.escrowHeld)}</td>
                    </tr>
                  );
                })}
              </DataTable>
            </div>
          </div>
        ))}
      </section>

      <Operations />

      <div className="grid gap-6 lg:grid-cols-2">
        <section aria-labelledby="fbids">
          <h2 id="fbids" className="mb-3 text-xl">Recent bids</h2>
          <DataTable head={['Member', 'Bid', 'Result']} empty="No bids yet.">
            {data.recentBids.slice(0, 8).map((b) => (
              <tr key={b.id}>
                <td className="px-4 py-2.5">{b.memberName}</td>
                <td className="num px-4 py-2.5">{formatINR(b.bidAmount)}</td>
                <td className="px-4 py-2.5"><Badge tone={b.status === 'FLAGGED_SUSPICIOUS' ? 'flag' : b.status === 'WINNING_BID' ? 'pine' : 'ok'} dot>{b.status === 'FLAGGED_SUSPICIOUS' ? `Flagged (${b.zScore}σ)` : b.status === 'WINNING_BID' ? 'Winning' : 'Accepted'}</Badge></td>
              </tr>
            ))}
          </DataTable>
        </section>
        <section aria-labelledby="fpay">
          <h2 id="fpay" className="mb-3 text-xl">Payouts</h2>
          <DataTable head={['Date', 'Amount', 'Receipt']} empty="No payouts yet.">
            {data.payoutHistory.slice(0, 8).map((p) => (
              <tr key={p.id}>
                <td className="px-4 py-2.5">{formatDateTime(p.payoutDate)}</td>
                <td className="num px-4 py-2.5">{formatINR(p.amount)}</td>
                <td className="px-4 py-2.5"><Link className="text-pine underline" href={`/receipts/${p.receiptId}`}>{p.receiptId}</Link></td>
              </tr>
            ))}
          </DataTable>
        </section>
      </div>
    </div>
  );
}
