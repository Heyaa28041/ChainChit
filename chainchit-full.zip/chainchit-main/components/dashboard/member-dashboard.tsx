'use client';

import Link from 'next/link';
import { useState } from 'react';
import { AlertTriangle, ArrowRight, Receipt, Wallet } from 'lucide-react';
import { Badge, type Tone } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog } from '@/components/ui/dialog';
import { Field, Select } from '@/components/ui/field';
import { Notice } from '@/components/ui/misc';
import { DataTable, Stat, Tabs } from '@/components/ui/tabs';
import { useToast } from '@/components/providers/toast-provider';
import { RaiseDisputeDialog } from './dispute-dialog';
import { api, errorMessage } from '@/lib/api';
import { formatDateTime, formatINR } from '@/lib/format';
import { kycLabel, kycTone } from '@/components/ui/badge';

export interface MemberDash {
  profile: { memberCode: string | null; name: string; kycStatus: string; kycRejectionReason: string | null; trustScore: number };
  groups: { id: string; code: string | null; name: string; status: string; chitValue: number; contributionAmount: number; delinquent: boolean }[];
  upcomingContributions: { cycleId: string; groupCode: string | null; cycleNumber: number; dueDate: string; amount: number; state: string }[];
  contributionHistory: { id: string; cycleId: string; amount: number; status: string; escrowStatus: string; paidAt: string; paymentRef: string | null }[];
  bidHistory: { id: string; cycleId: string; cycleNumber: number; bidAmount: number; status: string; zScore: number; timestamp: string }[];
  payoutHistory: { id: string; cycleId: string; amount: number; receiptId: string; payoutDate: string }[];
  disputes: { id: string; code: string; status: string; createdAt: string }[];
}

const DUE: Record<string, { label: string; tone: Tone }> = {
  NOT_DUE: { label: 'Upcoming', tone: 'neutral' },
  REMINDER_DUE: { label: 'Due soon', tone: 'brass' },
  DUE: { label: 'Due', tone: 'brass' },
  LATE: { label: 'Overdue · grace period', tone: 'flag' },
  DELINQUENT: { label: 'Flagged as delinquent', tone: 'flag' },
};
const BID: Record<string, { label: string; tone: Tone }> = {
  ACCEPTED: { label: 'Accepted', tone: 'ok' }, WINNING_BID: { label: 'Won', tone: 'pine' },
  FLAGGED_SUSPICIOUS: { label: 'Flagged', tone: 'flag' }, REJECTED: { label: 'Rejected', tone: 'neutral' },
};
export const DISPUTE_TONE: Record<string, Tone> = { OPEN: 'brass', ESCALATED: 'flag', RESOLVED: 'ok', REJECTED: 'neutral' };

type Tab = 'contributions' | 'bids' | 'payouts' | 'disputes';

export function MemberDashboard({ data, reload }: { data: MemberDash; reload: () => void }) {
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('contributions');
  const [paying, setPaying] = useState<MemberDash['upcomingContributions'][number] | null>(null);
  const [mode, setMode] = useState('UPI');
  const [decline, setDecline] = useState(false);
  const [busy, setBusy] = useState(false);
  const [payError, setPayError] = useState<string | null>(null);
  const [dispute, setDispute] = useState<{ kind: 'bid' | 'payout'; id: string; label: string } | null>(null);

  const verified = data.profile.kycStatus === 'VERIFIED';
  const overdue = data.upcomingContributions.filter((c) => c.state === 'LATE' || c.state === 'DELINQUENT');
  const confirmed = data.contributionHistory.filter((c) => c.status === 'CONFIRMED');

  async function pay() {
    if (!paying) return;
    setBusy(true);
    setPayError(null);
    try {
      await api('/api/contributions', { method: 'POST', body: { cycleId: paying.cycleId, amount: paying.amount, mode, simulateDecline: decline } });
      toast.push({ tone: 'success', title: `Paid ${formatINR(paying.amount)}`, body: 'Your contribution is locked in escrow until the cycle’s payout.' });
      setPaying(null);
      setDecline(false);
      reload();
    } catch (err) {
      setPayError(errorMessage(err));
      reload();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-8">
      {!verified && (
        <Notice tone={data.profile.kycStatus === 'REJECTED' ? 'flag' : 'brass'} title={kycLabel(data.profile.kycStatus)}>
          You need verified KYC before the foreman can enrol you or you can contribute and bid.{' '}
          <Link href="/kyc" className="font-medium text-pine underline">Go to KYC <ArrowRight className="inline size-3.5" aria-hidden /></Link>
        </Notice>
      )}
      {overdue.length > 0 && (
        <Notice tone="flag" icon={<AlertTriangle className="size-4 text-flag" />} title={`${overdue.length} overdue contribution${overdue.length > 1 ? 's' : ''}`}>
          Pay before the grace period ends to avoid being flagged as delinquent.
        </Notice>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Trust score" value={Math.round(data.profile.trustScore)} hint="Out of 100" />
        <Stat label="KYC" value={<Badge tone={kycTone(data.profile.kycStatus)} dot>{kycLabel(data.profile.kycStatus)}</Badge>} />
        <Stat label="Contributed" value={formatINR(confirmed.reduce((a, c) => a + c.amount, 0))} hint={`${confirmed.length} payments`} />
        <Stat label="Payouts won" value={formatINR(data.payoutHistory.reduce((a, p) => a + p.amount, 0))} hint={`${data.payoutHistory.length} cycle${data.payoutHistory.length === 1 ? '' : 's'}`} />
      </div>

      <section aria-labelledby="my-groups">
        <h2 id="my-groups" className="text-xl">My groups</h2>
        {data.groups.length === 0 ? (
          <p className="mt-3 text-sm text-ink-2">You’re not enrolled in a group yet. The foreman enrols verified members.</p>
        ) : (
          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {data.groups.map((g) => (
              <li key={g.id}>
                <Link href={`/groups/${g.id}`} className="block rounded-xl border border-rule bg-sheet p-4 hover:border-rule-2">
                  <p className="flex items-center justify-between gap-2"><span className="font-medium">{g.name}</span><span className="num text-[13px] text-ink-3">{g.code}</span></p>
                  <p className="num mt-1 text-sm text-ink-2">{formatINR(g.chitValue)} pool · {formatINR(g.contributionAmount)} per cycle</p>
                  <p className="mt-2 flex gap-2"><Badge tone={g.status === 'ACTIVE' ? 'ok' : 'info'}>{g.status === 'ACTIVE' ? 'Active' : 'Completed'}</Badge>{g.delinquent && <Badge tone="flag" dot>Delinquent</Badge>}</p>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section aria-labelledby="due">
        <h2 id="due" className="text-xl">Contributions to pay</h2>
        <div className="mt-4">
          <DataTable head={['Group', 'Cycle', 'Due', 'Amount', 'Status', '']} empty="Nothing to pay right now.">
            {data.upcomingContributions.map((c) => (
              <tr key={c.cycleId}>
                <td className="px-4 py-3">{c.groupCode}</td>
                <td className="num px-4 py-3">{c.cycleNumber}</td>
                <td className="px-4 py-3">{formatDateTime(c.dueDate)}</td>
                <td className="num px-4 py-3 font-medium">{formatINR(c.amount)}</td>
                <td className="px-4 py-3"><Badge tone={DUE[c.state]?.tone} dot>{DUE[c.state]?.label ?? c.state}</Badge></td>
                <td className="px-4 py-3 text-right"><Button size="sm" disabled={!verified} onClick={() => { setPayError(null); setPaying(c); }}><Wallet className="size-3.5" aria-hidden /> Pay</Button></td>
              </tr>
            ))}
          </DataTable>
        </div>
      </section>

      <section className="space-y-4">
        <Tabs label="History" value={tab} onChange={setTab} tabs={[
          { id: 'contributions', label: 'Contributions', count: data.contributionHistory.length },
          { id: 'bids', label: 'Bids', count: data.bidHistory.length },
          { id: 'payouts', label: 'Payouts', count: data.payoutHistory.length },
          { id: 'disputes', label: 'Disputes', count: data.disputes.length },
        ]} />
        {tab === 'contributions' && (
          <DataTable head={['Paid', 'Amount', 'Result', 'Escrow', 'Reference']} empty="No contributions yet.">
            {data.contributionHistory.map((c) => (
              <tr key={c.id}>
                <td className="px-4 py-3">{formatDateTime(c.paidAt)}</td>
                <td className="num px-4 py-3">{formatINR(c.amount)}</td>
                <td className="px-4 py-3"><Badge tone={c.status === 'CONFIRMED' ? 'ok' : 'flag'}>{c.status === 'CONFIRMED' ? 'Confirmed' : 'Declined'}</Badge></td>
                <td className="px-4 py-3">{c.escrowStatus === 'LOCKED' ? <Badge tone="brass">Locked in escrow</Badge> : c.escrowStatus === 'RELEASED' ? <Badge tone="info">Released</Badge> : '—'}</td>
                <td className="num px-4 py-3 text-ink-3">{c.paymentRef ?? '—'}</td>
              </tr>
            ))}
          </DataTable>
        )}
        {tab === 'bids' && (
          <DataTable head={['When', 'Cycle', 'Bid', 'Result', '']} empty="You haven’t bid yet.">
            {data.bidHistory.map((b) => (
              <tr key={b.id}>
                <td className="px-4 py-3">{formatDateTime(b.timestamp)}</td>
                <td className="num px-4 py-3"><Link href={`/cycle/${b.cycleId}`} className="underline">#{b.cycleNumber}</Link></td>
                <td className="num px-4 py-3">{formatINR(b.bidAmount)}</td>
                <td className="px-4 py-3"><Badge tone={BID[b.status]?.tone} dot>{BID[b.status]?.label ?? b.status}</Badge></td>
                <td className="px-4 py-3 text-right"><Button size="sm" variant="ghost" onClick={() => setDispute({ kind: 'bid', id: b.id, label: `your ${formatINR(b.bidAmount)} bid in cycle ${b.cycleNumber}` })}>Dispute</Button></td>
              </tr>
            ))}
          </DataTable>
        )}
        {tab === 'payouts' && (
          <DataTable head={['Paid out', 'Amount', 'Receipt', '']} empty="No payouts yet.">
            {data.payoutHistory.map((p) => (
              <tr key={p.id}>
                <td className="px-4 py-3">{formatDateTime(p.payoutDate)}</td>
                <td className="num px-4 py-3 font-medium">{formatINR(p.amount)}</td>
                <td className="px-4 py-3"><Link href={`/receipts/${p.receiptId}`} className="inline-flex items-center gap-1.5 text-pine underline"><Receipt className="size-3.5" aria-hidden />{p.receiptId}</Link></td>
                <td className="px-4 py-3 text-right"><Button size="sm" variant="ghost" onClick={() => setDispute({ kind: 'payout', id: p.id, label: `payout ${p.receiptId}` })}>Dispute</Button></td>
              </tr>
            ))}
          </DataTable>
        )}
        {tab === 'disputes' && (
          <DataTable head={['Dispute', 'Raised', 'Status']} empty="You haven’t raised any disputes.">
            {data.disputes.map((d) => (
              <tr key={d.id}>
                <td className="px-4 py-3"><Link href={`/disputes/${d.id}`} className="font-medium text-pine underline">{d.code}</Link></td>
                <td className="px-4 py-3">{formatDateTime(d.createdAt)}</td>
                <td className="px-4 py-3"><Badge tone={DISPUTE_TONE[d.status]} dot>{d.status.charAt(0) + d.status.slice(1).toLowerCase()}</Badge></td>
              </tr>
            ))}
          </DataTable>
        )}
      </section>

      <Dialog
        open={!!paying}
        onClose={() => setPaying(null)}
        title={`Pay ${paying ? formatINR(paying.amount) : ''}`}
        description={paying ? `${paying.groupCode} · cycle ${paying.cycleNumber}. Payment is simulated; confirmed funds are locked in escrow and can only leave through the payout.` : undefined}
        footer={<><Button variant="secondary" onClick={() => setPaying(null)} disabled={busy}>Cancel</Button><Button onClick={pay} loading={busy}>Confirm payment</Button></>}
      >
        <div className="space-y-4">
          <Field label="Payment method">
            {(id) => <Select id={id} value={mode} onChange={(e) => setMode(e.target.value)}><option>UPI</option><option>Card</option><option>Net banking</option></Select>}
          </Field>
          <label className="flex items-start gap-2.5 rounded-lg border border-dashed border-rule-2 p-3 text-sm text-ink-2">
            <input type="checkbox" className="mt-0.5 size-4 accent-[var(--color-pine)]" checked={decline} onChange={(e) => setDecline(e.target.checked)} />
            <span><span className="font-medium text-ink">Simulate a declined payment</span><br />Demo only: shows what happens when the bank declines.</span>
          </label>
          {payError && <p role="alert" className="rounded-lg bg-flag-wash px-3 py-2 text-sm text-flag">{payError}</p>}
        </div>
      </Dialog>
      <RaiseDisputeDialog target={dispute} onClose={() => setDispute(null)} onRaised={reload} />
    </div>
  );
}
