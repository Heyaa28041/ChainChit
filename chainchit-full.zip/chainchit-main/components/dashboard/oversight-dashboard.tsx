'use client';

import Link from 'next/link';
import { CheckCircle2, Download, ShieldX } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { buttonStyles } from '@/components/ui/button';
import { Notice } from '@/components/ui/misc';
import { DataTable, Stat } from '@/components/ui/tabs';
import { DISPUTE_TONE } from './member-dashboard';
import { formatDateTime, formatINR } from '@/lib/format';
import { ruleLabel } from '@/lib/room';

export interface OversightDash {
  groups: { id: string; code: string | null; name: string; status: string; chitValue: number }[];
  flaggedBids: { alertId: string; cycleId: string; memberName: string; rule: string; severity: string; resolved: boolean; resolutionAction: string | null; createdAt: string }[];
  disputes: { id: string; code: string; status: string; createdAt: string }[];
  payouts: { id: string; amount: number; receiptId: string; payoutDate: string }[];
  collusionReview: { groupCode: string | null; memberId: string; wins: number; window: number }[];
  recentLedger: { sequence: number; timestamp: string; action: string; entityType: string; entryHash: string }[];
  integrity: { valid: boolean; totalEntries: number; message: string };
}

export function OversightDashboard({ data }: { data: OversightDash }) {
  const open = data.flaggedBids.filter((f) => !f.resolved).length;
  return (
    <div className="space-y-8">
      <Notice tone={data.integrity.valid ? 'ok' : 'flag'} icon={data.integrity.valid ? <CheckCircle2 className="size-4 text-ok" /> : <ShieldX className="size-4 text-flag" />} title={data.integrity.valid ? 'Ledger verified' : 'Ledger integrity failure'}>
        {data.integrity.message} <Link href="/audit" className="font-medium underline">Open the ledger</Link>
      </Notice>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Groups" value={data.groups.length} />
        <Stat label="Unresolved flags" value={open} tone={open ? 'flag' : 'ok'} />
        <Stat label="Disputes" value={data.disputes.length} hint={`${data.disputes.filter((d) => d.status === 'ESCALATED').length} escalated`} />
        <Stat label="Ledger entries" value={data.integrity.totalEntries} />
      </div>

      <section aria-labelledby="ogroups" className="space-y-3">
        <h2 id="ogroups" className="text-xl">Groups and signed exports</h2>
        <DataTable head={['Group', 'Pool', 'Status', 'Signed transaction log']} empty="No groups yet.">
          {data.groups.map((g) => (
            <tr key={g.id}>
              <td className="px-4 py-3"><Link href={`/groups/${g.id}`} className="font-medium underline">{g.code} · {g.name}</Link></td>
              <td className="num px-4 py-3">{formatINR(g.chitValue)}</td>
              <td className="px-4 py-3"><Badge tone={g.status === 'ACTIVE' ? 'ok' : 'info'}>{g.status === 'ACTIVE' ? 'Active' : 'Completed'}</Badge></td>
              <td className="px-4 py-3"><span className="flex gap-2">
                <a className={buttonStyles({ variant: 'secondary', size: 'sm' })} href={`/api/groups/${g.id}/export?format=csv`}><Download className="size-3.5" aria-hidden /> CSV</a>
                <a className={buttonStyles({ variant: 'secondary', size: 'sm' })} href={`/api/groups/${g.id}/export?format=pdf`}><Download className="size-3.5" aria-hidden /> PDF</a>
              </span></td>
            </tr>
          ))}
        </DataTable>
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section aria-labelledby="oflag" className="space-y-3">
          <h2 id="oflag" className="text-xl">Flagged bids</h2>
          <DataTable head={['Member', 'Rule', 'Status']} empty="Nothing flagged.">
            {data.flaggedBids.map((f) => (
              <tr key={f.alertId}>
                <td className="px-4 py-2.5"><Link className="underline" href={`/cycle/${f.cycleId}`}>{f.memberName}</Link></td>
                <td className="px-4 py-2.5">{ruleLabel(f.rule)}</td>
                <td className="px-4 py-2.5"><Badge tone={f.resolved ? 'neutral' : 'flag'} dot>{f.resolved ? (f.resolutionAction === 'OVERRIDDEN' ? 'Cleared' : 'Disqualified') : 'Open'}</Badge></td>
              </tr>
            ))}
          </DataTable>
        </section>
        <section aria-labelledby="odisp" className="space-y-3">
          <h2 id="odisp" className="text-xl">Disputes</h2>
          <DataTable head={['Dispute', 'Raised', 'Status']} empty="No disputes.">
            {data.disputes.map((d) => (
              <tr key={d.id}>
                <td className="px-4 py-2.5"><Link href={`/disputes/${d.id}`} className="font-medium text-pine underline">{d.code}</Link></td>
                <td className="px-4 py-2.5">{formatDateTime(d.createdAt)}</td>
                <td className="px-4 py-2.5"><Badge tone={DISPUTE_TONE[d.status]} dot>{d.status.charAt(0) + d.status.slice(1).toLowerCase()}</Badge></td>
              </tr>
            ))}
          </DataTable>
        </section>
      </div>

      {data.collusionReview.length > 0 && (
        <Notice tone="brass" title="Win-frequency review">
          {data.collusionReview.map((c) => `${c.groupCode}: one member won ${c.wins} of the last ${c.window} cycles`).join(' · ')}
        </Notice>
      )}

      <section aria-labelledby="oledger" className="space-y-3">
        <h2 id="oledger" className="text-xl">Latest ledger entries</h2>
        <DataTable head={['#', 'Time', 'Action', 'Hash']}>
          {data.recentLedger.map((l) => (
            <tr key={l.sequence}>
              <td className="num px-4 py-2">{l.sequence}</td>
              <td className="px-4 py-2">{formatDateTime(l.timestamp)}</td>
              <td className="px-4 py-2">{l.action.replace(/_/g, ' ').toLowerCase()}</td>
              <td className="num px-4 py-2 text-ink-3">{l.entryHash.slice(0, 12)}…</td>
            </tr>
          ))}
        </DataTable>
      </section>
    </div>
  );
}
