'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Bell, ClipboardCheck, Gavel, IdCard, LayoutDashboard, Layers, LogOut, Scale, ScrollText } from 'lucide-react';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { Logo } from '@/components/brand/logo';
import { Badge, kycLabel, kycTone } from '@/components/ui/badge';
import { useSession } from '@/components/providers/session-provider';
import { useLiveCycles } from '@/components/providers/live-cycles-provider';
import { cn } from '@/lib/cn';
import { initials, roleLabel } from '@/lib/format';

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  active: boolean;
  badge?: number;
}

export function Navbar() {
  const pathname = usePathname();
  const { user, logout } = useSession();
  const { live } = useLiveCycles();

  const isForeman = user?.role === 'FOREMAN';
  const isAuditor = user?.role === 'OVERSIGHT_VIEWER';

  const [unread, setUnread] = useState(0);
  useEffect(() => {
    if (!user) return;
    let alive = true;
    const load = () => api<{ unread: number }>('/api/notifications').then((d) => alive && setUnread(d.unread)).catch(() => {});
    load();
    const t = window.setInterval(load, 30000);
    return () => { alive = false; window.clearInterval(t); };
  }, [user, pathname]);

  const items: NavItem[] = [];
  if (user) {
    items.push({ href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, active: pathname.startsWith('/dashboard') });
  }
  if (user?.role === 'MEMBER') {
    items.push({ href: '/kyc', label: 'KYC', icon: IdCard, active: pathname.startsWith('/kyc') });
  }
  if (user) {
    items.push({ href: '/groups', label: 'Groups', icon: Layers, active: pathname.startsWith('/groups') });
  }
  if (user && !isAuditor) {
    items.push({
      href: '/',
      label: 'Bidding room',
      icon: Gavel,
      active: pathname === '/' || pathname.startsWith('/cycle'),
      badge: live.length,
    });
  }
  if (isForeman) {
    items.push({ href: '/foreman', label: 'Foreman desk', icon: ClipboardCheck, active: pathname.startsWith('/foreman') });
  }
  if (user) {
    items.push({ href: '/disputes', label: 'Disputes', icon: Scale, active: pathname.startsWith('/disputes') });
  }
  if (isForeman || isAuditor) {
    items.push({ href: '/audit', label: 'Audit ledger', icon: ScrollText, active: pathname.startsWith('/audit') });
  }

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-rule bg-paper/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4 sm:px-6 lg:px-8">
          <Logo href={user ? '/dashboard' : '/'} />

          <nav className="hidden items-center gap-0.5 md:flex" aria-label="Main">
            {items.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                aria-current={item.active ? 'page' : undefined}
                className={cn(
                  'flex h-9 items-center gap-2 rounded-lg px-2.5 text-sm font-medium transition-colors',
                  item.active ? 'bg-pine text-board-ink' : 'text-ink-2 hover:bg-wash hover:text-ink'
                )}
              >
                <item.icon className="size-4" />
                {item.label}
                {!!item.badge && (
                  <span
                    className={cn(
                      'flex items-center gap-1 rounded-full px-1.5 text-xs',
                      item.active ? 'bg-board-ink/15 text-board-ink' : 'bg-ok-wash text-ok'
                    )}
                  >
                    <span className="size-1.5 animate-pulse rounded-full bg-current" aria-hidden />
                    {item.badge} live
                  </span>
                )}
              </Link>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-3">
            {user ? (
              <>
                <div className="hidden text-right leading-tight sm:block">
                  <p className="text-sm font-medium text-ink">{user.name}</p>
                  <p className="flex items-center justify-end gap-1.5 text-xs text-ink-3">
                    {roleLabel(user.role)}
                    {user.role === 'MEMBER' && (
                      <>
                        <span aria-hidden>·</span>
                        <span className="num">Trust {Math.round(user.trustScore)}</span>
                      </>
                    )}
                  </p>
                </div>
                {user.role === 'MEMBER' && user.kycStatus !== 'VERIFIED' && (
                  <Badge tone={kycTone(user.kycStatus)} className="hidden lg:inline-flex">
                    {kycLabel(user.kycStatus)}
                  </Badge>
                )}
                <Link href="/notifications" className="relative flex size-9 items-center justify-center rounded-lg text-ink-2 hover:bg-wash hover:text-ink" aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`}>
                  <Bell className="size-[18px]" />
                  {unread > 0 && <span className="num absolute right-0.5 top-0.5 flex min-w-4 items-center justify-center rounded-full bg-flag px-1 text-[10px] font-semibold text-white">{unread > 9 ? '9+' : unread}</span>}
                </Link>
                <span
                  className="flex size-9 items-center justify-center rounded-full bg-board font-display text-sm font-semibold text-brass"
                  aria-hidden
                >
                  {initials(user.name)}
                </span>
                <button
                  type="button"
                  onClick={() => void logout()}
                  className="flex h-9 items-center gap-2 rounded-lg px-2.5 text-sm text-ink-2 transition-colors hover:bg-wash hover:text-ink"
                  aria-label="Sign out"
                >
                  <LogOut className="size-4" />
                  <span className="hidden lg:inline">Sign out</span>
                </button>
              </>
            ) : (
              <Link
                href="/login"
                className="flex h-9 items-center rounded-lg bg-pine px-4 text-sm font-medium text-board-ink hover:bg-pine-2"
              >
                Sign in
              </Link>
            )}
          </div>
        </div>
      </header>

      {items.length > 1 && (
        <nav
          className="fixed inset-x-0 bottom-0 z-40 grid border-t border-rule bg-sheet/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden"
          style={{ gridTemplateColumns: `repeat(${items.length}, minmax(0, 1fr))` }}
          aria-label="Main"
        >
          {items.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={item.active ? 'page' : undefined}
              className={cn(
                'relative flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium',
                item.active ? 'text-pine' : 'text-ink-3'
              )}
            >
              <item.icon className="size-5" />
              {item.label}
              {!!item.badge && (
                <span className="absolute right-[calc(50%-1.6rem)] top-1.5 flex size-4 items-center justify-center rounded-full bg-ok text-[10px] font-semibold text-white">
                  {item.badge}
                </span>
              )}
              {item.active && <span className="absolute inset-x-6 top-0 h-0.5 rounded-b bg-pine" aria-hidden />}
            </Link>
          ))}
        </nav>
      )}
    </>
  );
}
