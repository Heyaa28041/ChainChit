'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '@/lib/api';
import type { CycleSummary, CyclesResponse } from '@/lib/types';

interface LiveCyclesContextValue {
  loaded: boolean;
  cycles: CycleSummary[];
  live: CycleSummary[];
  refresh: () => Promise<void>;
}

const LiveCyclesContext = createContext<LiveCyclesContextValue | null>(null);

/** Single source of truth for "which auctions exist / are live", polled lightly. */
export function LiveCyclesProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<CyclesResponse | null>(null);

  const refresh = useCallback(async () => {
    try {
      setData(await api<CyclesResponse>('/api/cycles'));
    } catch {
      // keep last known data; the next poll will retry
    }
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void refresh();
    const timer = window.setInterval(() => {
      if (document.visibilityState === 'visible') void refresh();
    }, 12000);
    const onVisible = () => {
      if (document.visibilityState === 'visible') void refresh();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [refresh]);

  const value = useMemo<LiveCyclesContextValue>(
    () => ({
      loaded: data !== null,
      cycles: data?.cycles ?? [],
      live: data?.activeCycles ?? [],
      refresh,
    }),
    [data, refresh]
  );

  return <LiveCyclesContext.Provider value={value}>{children}</LiveCyclesContext.Provider>;
}

export function useLiveCycles(): LiveCyclesContextValue {
  const ctx = useContext(LiveCyclesContext);
  if (!ctx) throw new Error('useLiveCycles must be used inside <LiveCyclesProvider>');
  return ctx;
}
