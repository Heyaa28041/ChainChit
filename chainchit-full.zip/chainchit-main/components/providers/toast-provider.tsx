'use client';

import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, Info, X, Zap } from 'lucide-react';
import { cn } from '@/lib/cn';

type Tone = 'success' | 'error' | 'info' | 'bid' | 'flag';

interface Toast {
  id: number;
  tone: Tone;
  title: string;
  body?: string;
}

interface ToastContextValue {
  push: (toast: Omit<Toast, 'id'>) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

const toneStyles: Record<Tone, { box: string; icon: React.ReactNode }> = {
  success: { box: 'border-ok/40', icon: <CheckCircle2 className="size-4 text-ok" aria-hidden /> },
  error: { box: 'border-flag/50', icon: <AlertTriangle className="size-4 text-flag" aria-hidden /> },
  info: { box: 'border-info/40', icon: <Info className="size-4 text-info" aria-hidden /> },
  bid: { box: 'border-brass', icon: <Zap className="size-4 text-brass-ink" aria-hidden /> },
  flag: { box: 'border-flag/50', icon: <AlertTriangle className="size-4 text-flag" aria-hidden /> },
};

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const nextId = useRef(1);

  const dismiss = useCallback((id: number) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  const push = useCallback(
    (toast: Omit<Toast, 'id'>) => {
      const id = nextId.current++;
      setToasts((t) => [...t.slice(-3), { ...toast, id }]);
      window.setTimeout(() => dismiss(id), toast.tone === 'error' ? 7000 : 4500);
    },
    [dismiss]
  );

  const value = useMemo(() => ({ push }), [push]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div
        aria-live="polite"
        aria-atomic="false"
        className="pointer-events-none fixed inset-x-0 bottom-20 z-[60] flex flex-col items-center gap-2 px-4 md:bottom-6"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            role={t.tone === 'error' || t.tone === 'flag' ? 'alert' : 'status'}
            className={cn(
              'pointer-events-auto flex w-full max-w-md animate-rise items-start gap-3 rounded-xl border bg-sheet px-4 py-3 shadow-[0_12px_32px_-12px_rgb(14_29_24/0.35)]',
              toneStyles[t.tone].box
            )}
          >
            <span className="mt-0.5">{toneStyles[t.tone].icon}</span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-ink">{t.title}</p>
              {t.body && <p className="mt-0.5 text-[13px] text-ink-2">{t.body}</p>}
            </div>
            <button
              type="button"
              onClick={() => dismiss(t.id)}
              className="-mr-1 rounded p-1 text-ink-3 hover:text-ink"
              aria-label="Dismiss notification"
            >
              <X className="size-3.5" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used inside <ToastProvider>');
  return ctx;
}
