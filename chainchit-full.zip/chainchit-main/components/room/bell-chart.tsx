'use client';

import { useEffect, useId, useRef, useState } from 'react';
import { formatINR, formatINRShort } from '@/lib/format';
import type { Bid } from '@/lib/types';

interface BellChartProps {
  mean: number;
  sd: number;
  thresholdZ: number;
  chitValue: number;
  bids: Bid[];
  leadingBidId: string | null;
  meId?: string;
}

function niceStep(raw: number): number {
  const steps = [500, 1000, 2000, 2500, 5000, 10000, 20000, 25000, 50000];
  return steps.find((s) => s >= raw) ?? 50000;
}

function useWidth<T extends HTMLElement>(initial = 720) {
  const ref = useRef<T>(null);
  const [width, setWidth] = useState(initial);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => setWidth(Math.max(280, Math.round(entry.contentRect.width))));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, width] as const;
}

/**
 * The group's bid history as a bell curve. Everything left of the flag line is the zone
 * where an underbid is held for the foreman; each bid stands on the curve as a pin.
 */
export function BellChart({ mean, sd, thresholdZ, chitValue, bids, leadingBidId, meId }: BellChartProps) {
  const [wrapRef, W] = useWidth<HTMLDivElement>();
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');

  const safeSd = sd > 0 ? sd : Math.max(1, chitValue * 0.04);
  const safeMean = mean > 0 ? mean : chitValue * 0.85;
  const threshold = safeMean - thresholdZ * safeSd;

  const lowestBid = bids.length ? Math.min(...bids.map((b) => b.bidAmount)) : Infinity;
  const domainMin = Math.min(safeMean - 4.2 * safeSd, lowestBid - 0.6 * safeSd);
  const domainMax = Math.max(safeMean + 3 * safeSd, Math.min(chitValue + 0.4 * safeSd, safeMean + 6 * safeSd));

  const H = W < 520 ? 210 : 236;
  const padX = 18;
  const padTop = 44;
  const padBottom = 30;
  const baseY = H - padBottom;
  const plotW = W - padX * 2;
  const plotH = baseY - padTop;
  const narrow = W < 520;

  const x = (v: number) => padX + ((Math.min(domainMax, Math.max(domainMin, v)) - domainMin) / (domainMax - domainMin)) * plotW;
  const dens = (v: number) => Math.exp(-0.5 * Math.pow((v - safeMean) / safeSd, 2));
  const y = (v: number) => baseY - dens(v) * plotH;

  const samples = 140;
  const pts: Array<[number, number]> = [];
  for (let i = 0; i <= samples; i++) {
    const v = domainMin + (i / samples) * (domainMax - domainMin);
    pts.push([x(v), y(v)]);
  }
  const curve = pts.map(([px, py], i) => `${i === 0 ? 'M' : 'L'}${px.toFixed(1)} ${py.toFixed(1)}`).join(' ');
  const area = `${curve} L${x(domainMax).toFixed(1)} ${baseY} L${x(domainMin).toFixed(1)} ${baseY} Z`;

  const zonePts = pts.filter(([px]) => px <= x(threshold));
  const zone =
    zonePts.length > 1
      ? `${zonePts.map(([px, py], i) => `${i === 0 ? 'M' : 'L'}${px.toFixed(1)} ${py.toFixed(1)}`).join(' ')} L${x(threshold).toFixed(1)} ${y(threshold).toFixed(1)} L${x(threshold).toFixed(1)} ${baseY} L${zonePts[0][0].toFixed(1)} ${baseY} Z`
      : '';

  const step = niceStep((domainMax - domainMin) / (narrow ? 4 : 6));
  const ticks: number[] = [];
  for (let v = Math.ceil(domainMin / step) * step; v <= domainMax; v += step) ticks.push(v);

  const thresholdX = x(threshold);
  const meanX = x(safeMean);
  const ceilingInView = chitValue <= domainMax && chitValue >= domainMin;

  return (
    <div ref={wrapRef} className="w-full">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        width="100%"
        height={H}
        role="img"
        aria-label={`Bid distribution. Group average ${formatINR(safeMean)}. Bids below ${formatINR(threshold)} are held for the foreman. ${bids.length} bids placed.`}
      >
        <defs>
          <linearGradient id={`${uid}-fill`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#d9ae4a" stopOpacity="0.28" />
            <stop offset="100%" stopColor="#d9ae4a" stopOpacity="0.02" />
          </linearGradient>
          <pattern id={`${uid}-hatch`} width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
            <rect width="7" height="7" fill="#ff9a82" fillOpacity="0.08" />
            <line x1="0" y1="0" x2="0" y2="7" stroke="#ff9a82" strokeOpacity="0.55" strokeWidth="1.6" />
          </pattern>
        </defs>

        {/* flag zone */}
        {zone && <path d={zone} fill={`url(#${uid}-hatch)`} />}

        {/* curve */}
        <path d={area} fill={`url(#${uid}-fill)`} />
        <path d={curve} fill="none" stroke="#d9ae4a" strokeWidth="2.25" strokeLinejoin="round" />

        {/* baseline + ticks */}
        <line x1={padX} x2={W - padX} y1={baseY} y2={baseY} stroke="#28463d" />
        {ticks.map((t) => (
          <g key={t}>
            <line x1={x(t)} x2={x(t)} y1={baseY} y2={baseY + 4} stroke="#4a6a5f" />
            <text x={x(t)} y={baseY + 19} textAnchor="middle" fontSize="12" fill="#7f9187" className="num">
              {formatINRShort(t)}
            </text>
          </g>
        ))}

        {/* mean */}
        <line x1={meanX} x2={meanX} y1={padTop - 8} y2={baseY} stroke="#a3b3a8" strokeDasharray="2 4" />
        <text x={meanX + 6} y={padTop - 14} fontSize="12" fill="#a3b3a8">
          {narrow ? `Avg ${formatINRShort(safeMean)}` : `Group average ${formatINRShort(safeMean)}`}
        </text>

        {/* flag line */}
        <line x1={thresholdX} x2={thresholdX} y1={padTop - 8} y2={baseY} stroke="#ff9a82" strokeWidth="1.5" strokeDasharray="5 4" />
        <text x={thresholdX - 6} y={padTop - 14} textAnchor="end" fontSize="12" fill="#ff9a82">
          {narrow ? `Flag ${formatINRShort(threshold)}` : `Held for review below ${formatINRShort(threshold)}`}
        </text>

        {/* ceiling */}
        {ceilingInView && (
          <g>
            <line x1={x(chitValue)} x2={x(chitValue)} y1={baseY - 22} y2={baseY} stroke="#7f9187" />
            <text x={x(chitValue) - 4} y={baseY - 28} textAnchor="end" fontSize="12" fill="#7f9187">
              Pool
            </text>
          </g>
        )}

        {/* bids as pins */}
        {bids.map((bid) => {
          const bx = x(bid.bidAmount);
          const curveY = y(bid.bidAmount);
          const py = Math.min(curveY, baseY - 16);
          const flagged = bid.status === 'FLAGGED_SUSPICIOUS';
          const rejected = bid.status === 'REJECTED';
          const leading = bid.id === leadingBidId;
          const mine = !!meId && bid.memberId === meId;
          const label = leading || flagged || mine;
          const color = flagged ? '#ff9a82' : rejected ? '#5f726a' : leading ? '#d9ae4a' : '#efe9d6';
          const tag = `${mine ? 'You · ' : ''}${formatINRShort(bid.bidAmount)}${flagged ? ' · held' : ''}`;
          const tagX = Math.min(W - 60, Math.max(60, bx));
          return (
            <g key={bid.id}>
              <title>{`${bid.memberName}: ${formatINR(bid.bidAmount)}${flagged ? ' (flagged)' : ''}`}</title>
              <line x1={bx} x2={bx} y1={py} y2={baseY} stroke={color} strokeOpacity="0.55" />
              {leading && (
                <circle cx={bx} cy={py} r="6" fill="none" stroke="#d9ae4a" className="origin-center animate-ring" style={{ transformBox: 'fill-box' }} />
              )}
              <circle
                cx={bx}
                cy={py}
                r={leading ? 6.5 : 5}
                fill={rejected ? 'none' : color}
                stroke={rejected ? color : '#0e1d18'}
                strokeWidth={rejected ? 1.5 : 2}
              />
              {label && (
                <text x={tagX} y={py - 12} textAnchor="middle" fontSize="12.5" fontWeight="600" fill={color} className="num">
                  {tag}
                </text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

