'use client';

import { useState } from 'react';
import { CheckCircle2, Clock, Info, Lock, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Notice } from '@/components/ui/misc';
import { api, ApiError, errorMessage } from '@/lib/api';
import { formatINR } from '@/lib/format';
import { leadingBid } from '@/lib/room';
import type { AuthUser, Bid, CycleDetail } from '@/lib/types';

interface BidSlipProps {
  detail: CycleDetail;
  user: AuthUser | null;
  onBidPlaced: (bid: Bid) => void;
  /** Ask the room to re-fetch (e.g. the window closed while the member was typing). */
  onStale: () => void;
}

interface Placed {
  bid: Bid;
  flagged: boolean;
  details?: string;
}

const STEPS = [500, 1000, 2500];
const inrPlain = new Intl.NumberFormat('en-IN');

/** The bid form, laid out as a paper chit: your bid on top, what it means for the group below the tear line. */
export function BidSlip({ detail, user, onBidPlaced, onStale }: BidSlipProps) {
  const { cycle, group, bids, enrolledMembers, stats } = detail;
  const [raw, setRaw] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [placed, setPlaced] = useState<Placed | null>(null);

  const amount = raw ? Number(raw) : 0;
  const lead = leadingBid(bids);
  const open = cycle.status === 'BIDDING_OPEN';
  const holdsLead = !!user && lead?.memberId === user.id;
  const flagLine = stats.mean - stats.thresholdZ * stats.stdDev;

  const members = group.numberOfMembers;
  const discount = Math.max(0, group.chitValue - amount);
  const dividend = members > 0 ? discount / members : 0;
  const baseDue = members > 0 ? group.chitValue / members : 0;
  const dueAfterDividend = Math.max(0, baseDue - dividend);

  // Why can't this person bid? (null = they can)
  let blocker: { icon: React.ReactNode; title: string; body: string } | null = null;
  if (!user) {
    blocker = { icon: <Lock className="size-4" />, title: 'Sign in to bid', body: 'You need to be signed in as an enrolled member.' };
  } else if (user.role !== 'MEMBER') {
    blocker = {
      icon: <Info className="size-4" />,
      title: user.role === 'FOREMAN' ? 'Foremen run the auction, they don’t bid' : 'Oversight accounts are read-only',
      body: 'Sign in as an enrolled, KYC-verified member to place bids.',
    };
  } else if (user.kycStatus === 'PENDING') {
    blocker = {
      icon: <Clock className="size-4" />,
      title: 'Waiting for KYC approval',
      body: 'The foreman is reviewing your ID. You can bid as soon as it is approved.',
    };
  } else if (user.kycStatus === 'REJECTED') {
    blocker = {
      icon: <ShieldAlert className="size-4" />,
      title: 'KYC was rejected',
      body: 'Contact the foreman to resubmit your details before bidding.',
    };
  } else if (!enrolledMembers.some((m) => m.id === user.id)) {
    blocker = {
      icon: <Info className="size-4" />,
      title: 'You aren’t enrolled in this group',
      body: 'Only members the foreman has enrolled can bid in this room.',
    };
  }

  function setAmount(value: number) {
    setRaw(String(Math.max(0, Math.round(value))));
    setError(null);
    setPlaced(null);
  }

  // Inline guidance while typing
  let hint: { tone: 'info' | 'flag'; text: string } | null = null;
  if (amount > 0) {
    if (amount > group.chitValue) hint = { tone: 'flag', text: `A bid can’t be higher than the pool (${formatINR(group.chitValue)}).` };
    else if (amount <= flagLine) hint = { tone: 'flag', text: `That’s below the flag line (${formatINR(flagLine)}). It will be accepted into the room but held for the foreman, and can’t win until cleared.` };
    else if (lead && amount >= lead.bidAmount) hint = { tone: 'info', text: `The lead is ${formatINR(lead.bidAmount)}. This bid wouldn’t beat it.` };
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !amount) return;
    if (amount > group.chitValue) return;

    setLoading(true);
    setError(null);
    setPlaced(null);
    try {
      const res = await api<{ bid: Bid; fraudCheck?: { isAnomaly: boolean; details?: string } }>(
        `/api/cycles/${cycle.id}/bid`,
        { method: 'POST', body: { memberId: user.id, bidAmount: amount } }
      );
      setPlaced({ bid: res.bid, flagged: !!res.fraudCheck?.isAnomaly, details: res.fraudCheck?.details });
      onBidPlaced(res.bid);
      setRaw('');
    } catch (err) {
      if (err instanceof ApiError && (err.code === 'WINDOW_CLOSED' || err.code === 'ALREADY_LOWEST_BIDDER')) {
        onStale();
      }
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="rounded-2xl border border-rule bg-sheet" aria-labelledby="slip-title">
      <header className="px-6 pb-6 pt-6">
        <h2 id="slip-title" className="text-2xl">
          Your bid
        </h2>
        <p className="mt-1.5 text-sm text-ink-2">
          Name the lowest prize you’d accept from the {formatINR(group.chitValue)} pool. The lowest valid bid wins.
        </p>
      </header>

      <div className="slip-perf" aria-hidden />

      <div className="px-6 pb-6 pt-6">
        {!open ? (
          <Notice tone="info" icon={<Lock className="size-4" />} title="Bidding is closed for this cycle">
            {cycle.status === 'SCHEDULED' ? 'The foreman hasn’t opened the window yet.' : 'The result is on the board above.'}
          </Notice>
        ) : blocker ? (
          <Notice tone="brass" icon={blocker.icon} title={blocker.title}>
            {blocker.body}
          </Notice>
        ) : (
          <form onSubmit={submit} noValidate>
            <label htmlFor="bid-amount" className="text-[13px] font-medium text-ink-2">
              Bid amount
            </label>
            <div className="relative mt-1.5">
              <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 font-display text-3xl text-ink-3" aria-hidden>
                ₹
              </span>
              <input
                id="bid-amount"
                inputMode="numeric"
                autoComplete="off"
                placeholder={lead ? inrPlain.format(lead.bidAmount - 500) : inrPlain.format(group.chitValue - 500)}
                value={raw ? inrPlain.format(Number(raw)) : ''}
                onChange={(e) => {
                  setRaw(e.target.value.replace(/\D/g, '').slice(0, 9));
                  setError(null);
                  setPlaced(null);
                }}
                disabled={holdsLead}
                aria-describedby="bid-hint"
                className="num h-16 w-full rounded-xl border border-rule-2 bg-paper pl-11 pr-4 font-display text-4xl font-semibold text-ink placeholder:text-ink-3/40 hover:border-ink-3 focus:border-pine focus:outline-none focus:ring-2 focus:ring-pine/20 disabled:cursor-not-allowed disabled:opacity-60"
              />
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className="text-[13px] text-ink-3">{lead ? 'Beat the lead by' : 'Open at'}</span>
              {STEPS.map((step) => (
                <button
                  key={step}
                  type="button"
                  disabled={holdsLead}
                  onClick={() => setAmount((lead?.bidAmount ?? group.chitValue) - step)}
                  className="num h-8 rounded-full border border-rule-2 bg-sheet px-3 text-[13px] font-medium text-ink-2 transition-colors hover:border-pine hover:text-pine disabled:opacity-50"
                >
                  {lead ? `−${inrPlain.format(step)}` : formatINR(group.chitValue - step)}
                </button>
              ))}
            </div>

            <div id="bid-hint" aria-live="polite" className="min-h-6">
              {hint && (
                <p className={`mt-3 text-[13px] ${hint.tone === 'flag' ? 'text-flag' : 'text-ink-2'}`}>{hint.text}</p>
              )}
            </div>

            <dl className="mt-4 space-y-2.5 text-[15px]">
              {[
                ['Pool value', formatINR(group.chitValue), false],
                ['Prize you take', amount ? formatINR(amount) : '—', false],
                ['Discount shared with the group', amount ? formatINR(discount) : '—', false],
                [`Dividend per member (÷ ${members})`, amount ? formatINR(dividend) : '—', false],
                ['Your monthly due after dividend', amount ? formatINR(dueAfterDividend) : '—', true],
              ].map(([label, value, strong]) => (
                <div key={label as string} className="flex items-baseline gap-2">
                  <dt className={strong ? 'font-medium text-ink' : 'text-ink-2'}>{label}</dt>
                  <span className="leader" aria-hidden />
                  <dd className={`num ${strong ? 'font-display text-xl font-semibold text-ink' : 'text-ink'}`}>{value}</dd>
                </div>
              ))}
            </dl>

            {holdsLead && (
              <Notice tone="brass" icon={<CheckCircle2 className="size-4 text-brass-ink" />} className="mt-5" title="You hold the lowest valid bid">
                You’re at {formatINR(lead!.bidAmount)}. You can bid again once another member goes lower.
              </Notice>
            )}

            {error && (
              <p role="alert" className="mt-5 rounded-lg bg-flag-wash px-3 py-2.5 text-sm text-flag">
                {error}
              </p>
            )}

            {placed && !placed.flagged && (
              <p role="status" className="mt-5 flex items-start gap-2 rounded-lg bg-ok-wash px-3 py-2.5 text-sm text-ok">
                <CheckCircle2 className="mt-0.5 size-4 shrink-0" aria-hidden />
                Bid placed at {formatINR(placed.bid.bidAmount)}.
              </p>
            )}
            {placed?.flagged && (
              <Notice tone="flag" icon={<ShieldAlert className="size-4 text-flag" />} className="mt-5" title={`${formatINR(placed.bid.bidAmount)} is held for review`}>
                {placed.details}
              </Notice>
            )}

            <Button
              type="submit"
              size="lg"
              loading={loading}
              disabled={!amount || amount > group.chitValue || holdsLead}
              className="mt-6 w-full"
            >
              {loading ? 'Placing bid' : amount ? `Place bid of ${formatINR(amount)}` : 'Place bid'}
            </Button>
          </form>
        )}
      </div>
    </section>
  );
}
