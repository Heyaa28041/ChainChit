'use client';

import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/cn';
import { formatClock, formatTime } from '@/lib/format';
import type { CycleStatus } from '@/lib/types';

interface CountdownProps {
  endTime: string | null;
  durationSeconds: number;
  status: CycleStatus;
  /** serverNow − clientNow in ms */
  skewMs: number;
  /** Fires once per end time when the window reaches zero. */
  onExpire: () => void;
}

export function Countdown({ endTime, durationSeconds, status, skewMs, onExpire }: CountdownProps) {
  const open = status === 'BIDDING_OPEN' && !!endTime;
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!open) return;
    const timer = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(timer);
  }, [open]);

  const remainingMs = open ? Math.max(0, Date.parse(endTime!) - (now + skewMs)) : 0;

  const firedFor = useRef<string | null>(null);
  useEffect(() => {
    if (open && remainingMs === 0 && firedFor.current !== endTime) {
      firedFor.current = endTime;
      onExpire();
    }
  }, [open, remainingMs, endTime, onExpire]);

  if (!open) {
    return (
      <div className="text-left lg:text-right">
        <p className="text-sm text-board-ink-2">Bidding window</p>
        <p className="mt-1 font-display text-4xl text-board-ink-2">Closed</p>
        {endTime && <p className="mt-1 text-sm text-board-ink-3 num">at {formatTime(endTime)}</p>}
      </div>
    );
  }

  const seconds = Math.ceil(remainingMs / 1000);
  const urgent = seconds <= 30;
  const progress = durationSeconds > 0 ? Math.min(1, remainingMs / (durationSeconds * 1000)) : 0;

  return (
    <div className="min-w-48 text-left lg:text-right">
      <p className="text-sm text-board-ink-2">{urgent ? 'Closing soon' : 'Window closes in'}</p>
      <p
        className={cn(
          'num mt-1 font-display text-6xl font-semibold leading-none',
          urgent ? 'text-flag-soft' : 'text-board-ink'
        )}
        role="timer"
        aria-live="off"
        aria-label={`${seconds} seconds remaining`}
      >
        {formatClock(seconds)}
      </p>
      <div className="mt-4 h-1 overflow-hidden rounded-full bg-board-rule" aria-hidden>
        <div
          className={cn('h-full origin-left rounded-full transition-[width] duration-300 ease-linear', urgent ? 'bg-flag-soft' : 'bg-brass')}
          style={{ width: `${progress * 100}%` }}
        />
      </div>
    </div>
  );
}
