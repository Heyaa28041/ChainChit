'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { BadgeCheck, FastForward, FlaskConical, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ConfirmDialog, ReasonDialog } from '@/components/ui/dialog';
import { Badge, escrowMeta } from '@/components/ui/badge';
import { Notice } from '@/components/ui/misc';
import { useToast } from '@/components/providers/toast-provider';
import { api, errorMessage } from '@/lib/api';
import { formatDateTime, formatINR } from '@/lib/format';
import { ruleLabel } from '@/lib/room';
import type { CycleDetail, FraudAlert } from '@/lib/types';

interface ForemanPanelProps {
  detail: CycleDetail;
  onChanged: () => void;
}

type Ruling = { alert: FraudAlert; action: 'OVERRIDDEN' | 'DISQUALIFIED' };

/** Foreman-only controls for the room: rule on held bids, close early, pay out, run demo scenarios. */
export function ForemanPanel({ detail, onChanged }: ForemanPanelProps) {
  const { cycle, alerts, winner } = detail;
  const toast = useToast();
  const router = useRouter();
  const [ruling, setRuling] = useState<Ruling | null>(null);
  const [confirmPay, setConfirmPay] = useState(false);
  const [confirmClose, setConfirmClose] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);

  const open = alerts.filter((a) => !a.resolved);
  const resolved = alerts.filter((a) => a.resolved);
  const escrow = escrowMeta(cycle.escrowStatus);
  const canPay = cycle.status === 'BIDDING_CLOSED' && !!winner && open.length === 0;

  async function rule(reason: string) {
    if (!ruling) return;
    try {
      await api('/api/fraud/override', { method: 'POST', body: { alertId: ruling.alert.id, action: ruling.action, reason } });
      toast.push({
        tone: 'success',
        title: ruling.action === 'OVERRIDDEN' ? 'Bid cleared' : 'Bid disqualified',
        body: `${ruling.alert.memberName}’s bid was ruled on and the decision is in the audit ledger.`,
      });
      setRuling(null);
      onChanged();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Couldn’t save the ruling', body: errorMessage(err) });
      setRuling(null);
    }
  }

  async function pay() {
    try {
      const res = await api<{ receiptId: string }>(`/api/cycles/${cycle.id}/settle`, { method: 'POST' });
      toast.push({ tone: 'success', title: 'Prize paid out', body: `Receipt ${res.receiptId}` });
      router.push(`/receipts/${res.receiptId}`);
      setConfirmPay(false);
      onChanged();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Payout didn’t go through', body: errorMessage(err) });
      setConfirmPay(false);
    }
  }

  async function closeNow() {
    try {
      await api(`/api/cycles/${cycle.id}/close`, { method: 'POST' });
      setConfirmClose(false);
      onChanged();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Couldn’t close bidding', body: errorMessage(err) });
      setConfirmClose(false);
    }
  }

  async function simulate(mode: 'concurrent_bids' | 'fraud_underbid' | 'reset_cycle', label: string) {
    setBusy(mode);
    try {
      await api(`/api/cycles/${cycle.id}/simulate`, { method: 'POST', body: { mode } });
      toast.push({ tone: 'info', title: label });
      onChanged();
    } catch (err) {
      toast.push({ tone: 'error', title: 'Scenario failed', body: errorMessage(err) });
    } finally {
      setBusy(null);
    }
  }

  return (
    <section className="rounded-2xl border border-rule bg-sheet" aria-labelledby="desk-title">
      <header className="flex flex-wrap items-center justify-between gap-3 px-5 pt-5">
        <h2 id="desk-title" className="text-xl">
          Foreman controls
        </h2>
        <Badge tone={escrow.tone} dot>
          {escrow.label}
        </Badge>
      </header>

      <div className="space-y-5 px-5 pb-5 pt-4">
        {cycle.status === 'BIDDING_OPEN' && (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="max-w-sm text-sm text-ink-2">Bidding ends on its own when the clock runs out. Close it now to name the winner early.</p>
            <Button variant="secondary" onClick={() => setConfirmClose(true)}>
              <FastForward className="size-4" aria-hidden /> Close bidding now
            </Button>
          </div>
        )}

        {cycle.status === 'BIDDING_CLOSED' && (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="max-w-sm text-sm text-ink-2">
              {winner
                ? canPay
                  ? `Pay ${formatINR(cycle.payoutAmount)} to ${winner.name} and release the escrow.`
                  : 'Rule on every held bid before paying out. A cleared bid may change the winner.'
                : 'There is no winner to pay for this cycle.'}
            </p>
            <Button disabled={!canPay} onClick={() => setConfirmPay(true)}>
              <BadgeCheck className="size-4" aria-hidden /> Pay out prize
            </Button>
          </div>
        )}

        {cycle.status === 'SETTLED' && (
          <Notice tone="ok" icon={<BadgeCheck className="size-4 text-ok" />} title="Paid out">
            Settled {formatDateTime(cycle.settledAt)}. The signed receipt is in the audit ledger and on the member’s dashboard.
          </Notice>
        )}

        <div>
          <h3 className="text-base">Held for review</h3>
          {open.length === 0 ? (
            <p className="mt-1.5 text-sm text-ink-2">No bids are waiting on a ruling.</p>
          ) : (
            <ul className="mt-3 space-y-3">
              {open.map((alert) => (
                <li key={alert.id} className="rounded-xl border border-flag/30 bg-flag-wash/60 p-4">
                  <p className="flex items-center gap-2 text-sm font-medium text-flag">
                    <ShieldAlert className="size-4" aria-hidden /> {ruleLabel(alert.ruleViolated)}
                  </p>
                  <p className="mt-1 text-sm text-ink">
                    {alert.memberName} · <span className="num">{alert.details}</span>
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" variant="secondary" onClick={() => setRuling({ alert, action: 'OVERRIDDEN' })}>
                      Clear this bid
                    </Button>
                    <Button size="sm" variant="danger" onClick={() => setRuling({ alert, action: 'DISQUALIFIED' })}>
                      Disqualify
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
          {resolved.length > 0 && (
            <p className="mt-3 text-[13px] text-ink-3">
              {resolved.length} earlier {resolved.length === 1 ? 'ruling' : 'rulings'} on this cycle, all in the audit ledger.
            </p>
          )}
        </div>

        <details className="rounded-xl border border-rule bg-paper/60">
          <summary className="flex items-center gap-2 px-4 py-3 text-sm font-medium text-ink-2">
            <FlaskConical className="size-4" aria-hidden /> Demo scenarios
          </summary>
          <div className="flex flex-wrap gap-2 px-4 pb-4">
            <Button size="sm" variant="secondary" loading={busy === 'concurrent_bids'} onClick={() => simulate('concurrent_bids', 'Three members bid at once')}>
              Three bids at once
            </Button>
            <Button size="sm" variant="secondary" loading={busy === 'fraud_underbid'} onClick={() => simulate('fraud_underbid', 'An extreme underbid was sent in')}>
              Extreme underbid
            </Button>
            <Button size="sm" variant="secondary" loading={busy === 'reset_cycle'} onClick={() => simulate('reset_cycle', 'Cycle reset with a fresh window')}>
              Reset cycle
            </Button>
          </div>
        </details>
      </div>

      <ReasonDialog
        open={!!ruling}
        title={ruling?.action === 'OVERRIDDEN' ? 'Clear this bid?' : 'Disqualify this bid?'}
        description={
          ruling?.action === 'OVERRIDDEN'
            ? 'The bid will count again and can win if it is the lowest.'
            : 'The bid is removed from the auction for good.'
        }
        label="Reason for the ledger"
        required
        confirmLabel={ruling?.action === 'OVERRIDDEN' ? 'Clear bid' : 'Disqualify bid'}
        tone={ruling?.action === 'DISQUALIFIED' ? 'danger' : 'primary'}
        onSubmit={rule}
        onClose={() => setRuling(null)}
      />
      <ConfirmDialog
        open={confirmPay}
        title="Pay out this prize?"
        description={`${formatINR(cycle.payoutAmount)} will be released to ${winner?.name ?? 'the winner'}. This can’t be undone.`}
        confirmLabel="Pay out"
        onConfirm={pay}
        onClose={() => setConfirmPay(false)}
      />
      <ConfirmDialog
        open={confirmClose}
        title="Close bidding now?"
        description="No more bids will be accepted and the winner is named immediately."
        confirmLabel="Close bidding"
        onConfirm={closeNow}
        onClose={() => setConfirmClose(false)}
      />
    </section>
  );
}
