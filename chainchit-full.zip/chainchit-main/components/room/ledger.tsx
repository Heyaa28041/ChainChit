'use client';

import { ShieldAlert, Trophy, XCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { formatINR, formatTime } from '@/lib/format';
import { cn } from '@/lib/cn';
import { leadingBid } from '@/lib/room';
import type { Bid } from '@/lib/types';

interface LedgerProps {
  bids: Bid[];
  meId?: string;
  freshBidIds: ReadonlySet<string>;
  winningBidId: string | null;
}

/** Every bid placed in the room, lowest first, so the order of the table is the order of the auction. */
export function Ledger({ bids, meId, freshBidIds, winningBidId }: LedgerProps) {
  const lead = leadingBid(bids);

  return (
    <section className="rounded-2xl border border-rule bg-sheet" aria-labelledby="ledger-title">
      <header className="flex items-baseline justify-between gap-4 px-5 pt-5">
        <h2 id="ledger-title" className="text-xl">
          Bids so far
        </h2>
        <span className="num text-sm text-ink-3">{bids.length === 1 ? '1 bid' : `${bids.length} bids`}</span>
      </header>

      {bids.length === 0 ? (
        <p className="px-5 pb-6 pt-3 text-sm text-ink-2">Nothing yet. Bids appear here the moment they are placed, lowest first.</p>
      ) : (
        <ol className="scroll-thin mt-3 max-h-[28rem] divide-y divide-rule overflow-y-auto pb-2">
          {bids.map((bid) => {
            const flagged = bid.status === 'FLAGGED_SUSPICIOUS';
            const rejected = bid.status === 'REJECTED';
            const isLead = lead?.id === bid.id;
            const isWinner = bid.id === winningBidId || bid.status === 'WINNING_BID';
            return (
              <li
                key={bid.id}
                className={cn(
                  'flex items-center gap-3 px-5 py-3',
                  freshBidIds.has(bid.id) && 'animate-row-in',
                  rejected && 'opacity-60'
                )}
              >
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-x-2 text-sm">
                    <span className={cn('truncate font-medium', bid.memberId === meId && 'text-pine')}>
                      {bid.memberId === meId ? 'You' : bid.memberName}
                    </span>
                    <span className="num text-[13px] text-ink-3">{formatTime(bid.timestamp)}</span>
                  </p>
                  {flagged && bid.fraudReason && <p className="mt-0.5 text-[13px] text-flag">{bid.fraudReason}</p>}
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  {isWinner ? (
                    <Badge tone="brass">
                      <Trophy className="size-3" aria-hidden /> Winner
                    </Badge>
                  ) : isLead ? (
                    <Badge tone="ok">Leading</Badge>
                  ) : flagged ? (
                    <Badge tone="flag">
                      <ShieldAlert className="size-3" aria-hidden /> Held
                    </Badge>
                  ) : rejected ? (
                    <Badge tone="neutral">
                      <XCircle className="size-3" aria-hidden /> Disqualified
                    </Badge>
                  ) : null}
                  <span className={cn('num w-24 text-right font-display text-lg font-semibold', flagged || rejected ? 'text-ink-3 line-through decoration-1' : 'text-ink')}>
                    {formatINR(bid.bidAmount)}
                  </span>
                </div>
              </li>
            );
          })}
        </ol>
      )}
    </section>
  );
}
