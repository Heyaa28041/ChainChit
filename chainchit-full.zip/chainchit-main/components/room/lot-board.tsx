'use client';

import { Gavel, ShieldAlert } from 'lucide-react';
import { BellChart } from './bell-chart';
import { Countdown } from './countdown';
import { RollingNumber } from './rolling-number';
import { formatINR } from '@/lib/format';
import { leadingBid } from '@/lib/room';
import type { CycleDetail } from '@/lib/types';

interface LotBoardProps {
  detail: CycleDetail;
  meId?: string;
  skewMs: number;
  onExpire: () => void;
}

/** The live auction board: the lowest valid bid, the clock and the fraud curve in one dark slab. */
export function LotBoard({ detail, meId, skewMs, onExpire }: LotBoardProps) {
  const { cycle, group, winner, bids, enrolledMembers, stats } = detail;
  const leading = leadingBid(bids);
  const open = cycle.status === 'BIDDING_OPEN';

  let label = 'Lowest valid bid';
  let figure: React.ReactNode;
  let caption: React.ReactNode;

  if (cycle.status === 'DISPUTED') {
    label = 'Outcome';
    figure = <span className="font-display text-[clamp(3rem,8vw,5.5rem)] font-semibold leading-none text-flag-soft">Held</span>;
    caption = 'Every bid was flagged by the fraud check, so no winner can be named until the foreman rules on them.';
  } else if (cycle.status === 'BIDDING_CLOSED' || cycle.status === 'SETTLED') {
    if (cycle.payoutAmount !== null && winner) {
      label = cycle.status === 'SETTLED' ? 'Prize paid out' : 'Awarded at';
      figure = <RollingNumber value={cycle.payoutAmount} className="font-display text-[clamp(3.5rem,9vw,6.5rem)] font-semibold leading-none text-brass" />;
      caption = (
        <>
          <strong className="font-medium text-board-ink">{winner.name}</strong> wins · {formatINR(group.chitValue - cycle.payoutAmount)} goes back
          to the group as dividend
        </>
      );
    } else {
      label = 'Outcome';
      figure = <span className="font-display text-[clamp(3rem,8vw,5.5rem)] font-semibold leading-none text-board-ink-2">No bids</span>;
      caption = 'The window closed without a bid, so there is no winner for this cycle.';
    }
  } else if (leading) {
    figure = <RollingNumber value={leading.bidAmount} className="font-display text-[clamp(3.5rem,9vw,6.5rem)] font-semibold leading-none text-brass" />;
    caption = (
      <>
        <strong className="font-medium text-board-ink">{leading.memberId === meId ? 'You' : leading.memberName}</strong>{' '}
        {leading.memberId === meId ? 'are' : 'is'} ahead · {formatINR(group.chitValue - leading.bidAmount)} below the pool
      </>
    );
  } else {
    figure = <span className="font-display text-[clamp(3rem,8vw,5.5rem)] font-semibold leading-none text-board-ink-2">No bid yet</span>;
    caption = `The pool is ${formatINR(group.chitValue)}. The first valid bid sets the pace and every bid after it must go lower to lead.`;
  }

  const flaggedCount = bids.filter((b) => b.status === 'FLAGGED_SUSPICIOUS').length;

  return (
    <section className="on-board overflow-hidden rounded-2xl bg-board text-board-ink" aria-label="Auction board">
      <div className="grid gap-8 p-6 sm:p-8 lg:grid-cols-[1fr_auto] lg:items-start">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
            <Gavel className="size-5 text-brass" aria-hidden />
            <h1 className="font-display text-2xl text-board-ink">{group.name}</h1>
            <span className="rounded-full bg-board-2 px-2.5 py-0.5 text-[13px] text-board-ink-2 num">
              Cycle {cycle.cycleNumber} of {group.numberOfMembers}
            </span>
            {open && (
              <span className="flex items-center gap-1.5 rounded-full bg-brass/15 px-2.5 py-0.5 text-[13px] font-medium text-brass">
                <span className="size-1.5 animate-pulse rounded-full bg-brass" aria-hidden />
                Bidding open
              </span>
            )}
          </div>

          <p className="mt-8 text-sm text-board-ink-2">{label}</p>
          <div className="mt-1" aria-live="polite">
            {figure}
          </div>
          <p className="mt-4 max-w-xl text-[15px] text-board-ink-2">{caption}</p>

          <dl className="mt-6 flex flex-wrap gap-x-8 gap-y-3 text-sm">
            <div>
              <dt className="text-board-ink-3">Pool</dt>
              <dd className="num font-medium text-board-ink">{formatINR(group.chitValue)}</dd>
            </div>
            <div>
              <dt className="text-board-ink-3">Members enrolled</dt>
              <dd className="num font-medium text-board-ink">
                {enrolledMembers.length} of {group.numberOfMembers}
              </dd>
            </div>
            <div>
              <dt className="text-board-ink-3">Bids</dt>
              <dd className="num font-medium text-board-ink">{bids.length}</dd>
            </div>
            {flaggedCount > 0 && (
              <div>
                <dt className="text-board-ink-3">Held by fraud check</dt>
                <dd className="num flex items-center gap-1 font-medium text-flag-soft">
                  <ShieldAlert className="size-3.5" aria-hidden />
                  {flaggedCount}
                </dd>
              </div>
            )}
          </dl>
        </div>

        <Countdown
          endTime={cycle.biddingEndTime}
          durationSeconds={cycle.biddingDurationSeconds}
          status={cycle.status}
          skewMs={skewMs}
          onExpire={onExpire}
        />
      </div>

      <div className="border-t border-board-rule px-3 pb-3 pt-5 sm:px-6">
        <BellChart
          mean={stats.mean}
          sd={stats.stdDev}
          thresholdZ={stats.thresholdZ}
          chitValue={group.chitValue}
          bids={bids}
          leadingBidId={leading?.id ?? null}
          meId={meId}
        />
        <p className="px-1 pb-1 pt-1 text-[13px] text-board-ink-3">
          The curve is {stats.source === 'history' ? `built from ${stats.sampleSize} clean bids in this group` : "this group's starting estimate"}. A bid
          more than {stats.thresholdZ}σ under the average falls in the hatched zone and is held until the foreman rules on it.
        </p>
      </div>
    </section>
  );
}
