'use client';

import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/cn';
import { formatINR } from '@/lib/format';

/**
 * Counts to a new rupee value. In a reverse auction the figure only ever falls,
 * so a drop gets a brief brass flash — the one piece of motion the room allows itself.
 */
export function RollingNumber({ value, className }: { value: number; className?: string }) {
  const [display, setDisplay] = useState(value);
  const [flashKey, setFlashKey] = useState(0);
  const shown = useRef(value);

  useEffect(() => {
    const from = shown.current;
    if (from === value) return;

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const duration = reduce ? 0 : 520;
    const start = performance.now();
    let raf = 0;
    let flashed = false;

    const tick = (now: number) => {
      if (!flashed) {
        flashed = true;
        setFlashKey((k) => k + 1);
      }
      const p = duration === 0 ? 1 : Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      const next = Math.round(from + (value - from) * eased);
      shown.current = next;
      setDisplay(next);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);

  return (
    <span key={flashKey} className={cn('num inline-block', flashKey > 0 && 'animate-flash', className)}>
      {formatINR(display)}
    </span>
  );
}
