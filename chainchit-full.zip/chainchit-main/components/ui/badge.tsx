import { cn } from '@/lib/cn';

export type Tone = 'neutral' | 'ok' | 'flag' | 'brass' | 'info' | 'pine';

const tones: Record<Tone, string> = {
  neutral: 'bg-wash text-ink-2',
  ok: 'bg-ok-wash text-ok',
  flag: 'bg-flag-wash text-flag',
  brass: 'bg-brass-wash text-brass-ink',
  info: 'bg-info-wash text-info',
  pine: 'bg-pine-wash text-pine',
};

export function Badge({
  tone = 'neutral',
  className,
  children,
  dot = false,
}: {
  tone?: Tone;
  className?: string;
  children: React.ReactNode;
  dot?: boolean;
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium',
        tones[tone],
        className
      )}
    >
      {dot && <span className="size-1.5 rounded-full bg-current" aria-hidden />}
      {children}
    </span>
  );
}

export function kycTone(status: string): Tone {
  if (status === 'VERIFIED') return 'ok';
  if (status === 'REJECTED') return 'flag';
  if (status === 'UNDER_REVIEW') return 'info';
  return 'brass';
}

export function kycLabel(status: string): string {
  if (status === 'VERIFIED') return 'KYC verified';
  if (status === 'REJECTED') return 'KYC rejected';
  if (status === 'UNDER_REVIEW') return 'KYC under review';
  return 'KYC not submitted';
}

export function cycleStatusMeta(status: string): { label: string; tone: Tone } {
  switch (status) {
    case 'BIDDING_OPEN':
      return { label: 'Bidding open', tone: 'ok' };
    case 'BIDDING_CLOSED':
      return { label: 'Awaiting payout', tone: 'brass' };
    case 'SETTLED':
      return { label: 'Settled', tone: 'info' };
    case 'DISPUTED':
      return { label: 'Disputed', tone: 'flag' };
    default:
      return { label: 'Scheduled', tone: 'neutral' };
  }
}

export function escrowMeta(status: string): { label: string; tone: Tone } {
  switch (status) {
    case 'RELEASED':
      return { label: 'Escrow released', tone: 'ok' };
    case 'HELD_FOR_REVIEW':
      return { label: 'Escrow held for review', tone: 'flag' };
    default:
      return { label: 'Escrow locked', tone: 'brass' };
  }
}
