'use client';

import { useEffect, useRef, useState } from 'react';
import { Button } from './button';
import { Textarea } from './field';

interface DialogProps {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children?: React.ReactNode;
  footer: React.ReactNode;
}

/** Native <dialog>: focus trap, Esc to close and backdrop come from the browser. */
export function Dialog({ open, onClose, title, description, children, footer }: DialogProps) {
  const ref = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (open && !el.open) el.showModal();
    if (!open && el.open) el.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      onClose={onClose}
      onClick={(e) => {
        if (e.target === ref.current) onClose();
      }}
      aria-labelledby="dialog-title"
    >
      {open && (
        <div className="p-6">
          <h2 id="dialog-title" className="text-xl">
            {title}
          </h2>
          {description && <p className="mt-2 text-sm text-ink-2">{description}</p>}
          {children && <div className="mt-4">{children}</div>}
          <div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">{footer}</div>
        </div>
      )}
    </dialog>
  );
}

export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel,
  tone = 'primary',
  onConfirm,
  onClose,
}: {
  open: boolean;
  title: string;
  description: string;
  confirmLabel: string;
  tone?: 'primary' | 'danger';
  onConfirm: () => Promise<void> | void;
  onClose: () => void;
}) {
  const [busy, setBusy] = useState(false);
  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={title}
      description={description}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={busy}>
            Cancel
          </Button>
          <Button
            variant={tone === 'danger' ? 'danger' : 'primary'}
            loading={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await onConfirm();
              } finally {
                setBusy(false);
                onClose();
              }
            }}
          >
            {confirmLabel}
          </Button>
        </>
      }
    />
  );
}

/** Ask for a written reason (mandatory or optional) before a recorded action. */
export function ReasonDialog({
  open,
  title,
  description,
  label,
  initialValue = '',
  required = true,
  confirmLabel,
  tone = 'primary',
  onSubmit,
  onClose,
}: {
  open: boolean;
  title: string;
  description: string;
  label: string;
  initialValue?: string;
  required?: boolean;
  confirmLabel: string;
  tone?: 'primary' | 'danger';
  onSubmit: (reason: string) => Promise<void> | void;
  onClose: () => void;
}) {
  const [value, setValue] = useState(initialValue);
  const [busy, setBusy] = useState(false);
  const [prevOpen, setPrevOpen] = useState(open);

  // Reset the draft each time the dialog opens (adjust state during render, not in an effect).
  if (open !== prevOpen) {
    setPrevOpen(open);
    if (open) setValue(initialValue);
  }

  const valid = !required || value.trim().length >= 3;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={title}
      description={description}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={busy}>
            Cancel
          </Button>
          <Button
            variant={tone === 'danger' ? 'danger' : 'primary'}
            disabled={!valid}
            loading={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await onSubmit(value.trim());
              } finally {
                setBusy(false);
                onClose();
              }
            }}
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      <label htmlFor="reason-input" className="mb-1.5 block text-[13px] font-medium text-ink-2">
        {label}
      </label>
      <Textarea
        id="reason-input"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        autoFocus
        maxLength={280}
      />
      {required && !valid && (
        <p className="mt-1.5 text-[13px] text-ink-3">Write at least a few words — this goes into the audit log.</p>
      )}
    </Dialog>
  );
}
