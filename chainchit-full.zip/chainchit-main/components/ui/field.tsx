import { useId } from 'react';
import { cn } from '@/lib/cn';

export const inputStyles =
  'block w-full rounded-lg border border-rule-2 bg-sheet px-3.5 text-[15px] text-ink placeholder:text-ink-3/70 transition-colors hover:border-ink-3 focus:border-pine focus:outline-none focus:ring-2 focus:ring-pine/20 disabled:cursor-not-allowed disabled:bg-wash disabled:text-ink-3';

export function Input({
  className,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input className={cn(inputStyles, 'h-11', className)} {...props} />;
}

export function Textarea({
  className,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={cn(inputStyles, 'min-h-24 py-2.5', className)} {...props} />;
}

export function Select({
  className,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className={cn(inputStyles, 'h-11 pr-8', className)} {...props} />;
}

/** Label + control + hint/error. Pass a render function to receive the generated id. */
export function Field({
  label,
  hint,
  error,
  children,
  className,
}: {
  label: string;
  hint?: string;
  error?: string | null;
  children: (id: string, describedBy: string | undefined) => React.ReactNode;
  className?: string;
}) {
  const id = useId();
  const hintId = hint || error ? `${id}-hint` : undefined;
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-[13px] font-medium text-ink-2">
        {label}
      </label>
      {children(id, hintId)}
      {(hint || error) && (
        <p
          id={hintId}
          className={cn('mt-1.5 text-[13px]', error ? 'text-flag' : 'text-ink-3')}
        >
          {error || hint}
        </p>
      )}
    </div>
  );
}
