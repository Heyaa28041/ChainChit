import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/cn';

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={cn('size-5 animate-spin text-ink-3', className)} aria-label="Loading" />;
}

export function PageLoader({ label = 'Loading' }: { label?: string }) {
  return (
    <div className="flex min-h-[50vh] items-center justify-center gap-3 text-sm text-ink-3" role="status">
      <Spinner />
      <span>{label}</span>
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('animate-pulse rounded-lg bg-wash', className)} aria-hidden />;
}

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-2xl">
        <h1 className="text-3xl sm:text-4xl">{title}</h1>
        {description && <p className="mt-2 text-[15px] text-ink-2">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  children,
  action,
  className,
}: {
  icon?: React.ReactNode;
  title: string;
  children?: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        'flex flex-col items-center rounded-xl border border-dashed border-rule-2 px-6 py-12 text-center',
        className
      )}
    >
      {icon && <div className="mb-3 text-ink-3">{icon}</div>}
      <h3 className="text-lg">{title}</h3>
      {children && <p className="mt-1.5 max-w-md text-sm text-ink-2">{children}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Notice({
  tone = 'info',
  icon,
  title,
  children,
  className,
}: {
  tone?: 'info' | 'brass' | 'flag' | 'ok';
  icon?: React.ReactNode;
  title?: string;
  children: React.ReactNode;
  className?: string;
}) {
  const styles = {
    info: 'border-info/30 bg-info-wash text-ink',
    brass: 'border-brass/60 bg-brass-wash text-ink',
    flag: 'border-flag/40 bg-flag-wash text-ink',
    ok: 'border-ok/30 bg-ok-wash text-ink',
  }[tone];
  return (
    <div className={cn('flex gap-3 rounded-xl border px-4 py-3 text-sm', styles, className)} role={tone === 'flag' ? 'alert' : undefined}>
      {icon && <div className="mt-0.5 shrink-0">{icon}</div>}
      <div className="min-w-0">
        {title && <p className="font-medium">{title}</p>}
        <div className={cn(title && 'mt-0.5 text-ink-2')}>{children}</div>
      </div>
    </div>
  );
}
