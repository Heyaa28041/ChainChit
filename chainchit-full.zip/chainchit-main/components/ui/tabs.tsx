'use client';

import { cn } from '@/lib/cn';

export function Tabs<T extends string>({
  tabs,
  value,
  onChange,
  label,
}: {
  tabs: { id: T; label: string; count?: number }[];
  value: T;
  onChange: (id: T) => void;
  label: string;
}) {
  return (
    <div role="tablist" aria-label={label} className="no-scrollbar flex gap-1 overflow-x-auto border-b border-rule">
      {tabs.map((t) => (
        <button
          key={t.id}
          role="tab"
          aria-selected={value === t.id}
          onClick={() => onChange(t.id)}
          className={cn(
            '-mb-px flex shrink-0 items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium transition-colors',
            value === t.id ? 'border-pine text-ink' : 'border-transparent text-ink-3 hover:text-ink'
          )}
        >
          {t.label}
          {!!t.count && <span className="num rounded-full bg-wash px-2 text-xs text-ink-2">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

export function Stat({ label, value, hint, tone }: { label: string; value: React.ReactNode; hint?: string; tone?: 'flag' | 'ok' }) {
  return (
    <div className="rounded-xl border border-rule bg-sheet p-4">
      <p className="text-[13px] text-ink-3">{label}</p>
      <p className={cn('num mt-1 font-display text-2xl font-semibold', tone === 'flag' && 'text-flag', tone === 'ok' && 'text-ok')}>{value}</p>
      {hint && <p className="mt-0.5 text-[13px] text-ink-3">{hint}</p>}
    </div>
  );
}

/** Responsive table: horizontal scroll on phones instead of breaking the layout. */
export function DataTable({ head, children, empty }: { head: string[]; children: React.ReactNode; empty?: string }) {
  const rows = Array.isArray(children) ? children.length : children ? 1 : 0;
  if (!rows && empty) return <p className="rounded-xl border border-dashed border-rule-2 px-4 py-8 text-center text-sm text-ink-3">{empty}</p>;
  return (
    <div className="scroll-thin overflow-x-auto rounded-xl border border-rule bg-sheet">
      <table className="w-full min-w-[32rem] text-left text-sm">
        <thead className="border-b border-rule bg-paper text-[13px] text-ink-3">
          <tr>{head.map((h) => <th key={h} className="px-4 py-2.5 font-medium">{h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-rule">{children}</tbody>
      </table>
    </div>
  );
}
