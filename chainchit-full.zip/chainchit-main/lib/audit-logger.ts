import { db } from './db';
import { auditLogs, cycles, bids, fraudAlerts } from './db/schema';
import { eq } from 'drizzle-orm';
import { asc, desc, sql } from 'drizzle-orm';
import crypto from 'crypto';
import { signMessage, verifySignature, signerKeyId, publicKeyPem } from './server/crypto';

export const GENESIS_HASH = '0'.repeat(64);

export interface AuditActionParams {
  actorId?: string | null;
  actorRole: string;
  action: string;
  entityType: string;
  entityId: string;
  groupId?: string | null;
  payload: Record<string, any>;
}

export function generateEntryHash(previousHash: string, dataString: string): string {
  return crypto.createHash('sha256').update(previousHash + dataString).digest('hex');
}

/** What an entry's hash covers. Includes the sequence number so entries cannot be re-ordered. */
function hashInput(e: {
  sequence: number; actorId: string | null; actorRole: string; action: string;
  entityType: string; entityId: string; groupId: string | null; payloadJson: string;
}) {
  return JSON.stringify({
    sequence: e.sequence,
    actorId: e.actorId,
    actorRole: e.actorRole,
    action: e.action,
    entityType: e.entityType,
    entityId: e.entityId,
    groupId: e.groupId,
    payloadJson: e.payloadJson,
  });
}

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

/**
 * Appends a tamper-evident entry: SHA-256 chained to the previous entry and signed with Ed25519.
 * A transaction-scoped advisory lock serialises writers so the chain can never fork.
 * Pass `tx` to make the entry commit atomically with the business change it records.
 */
/** Best-effort lookup so per-group exports can find entries written by older call sites. */
async function resolveGroupId(t: Tx | typeof db, p: AuditActionParams): Promise<string | null> {
  if (p.groupId !== undefined) return p.groupId;
  const cycleLookup = async (id: unknown) => {
    if (typeof id !== 'string') return null;
    const [c] = await t.select({ g: cycles.groupId }).from(cycles).where(eq(cycles.id, id)).limit(1);
    return c?.g ?? null;
  };
  if (p.entityType === 'CHIT_GROUP') return p.entityId;
  if (p.entityType === 'CYCLE') return cycleLookup(p.entityId);
  if (p.entityType === 'BID') {
    const [b] = await t.select({ c: bids.cycleId }).from(bids).where(eq(bids.id, p.entityId)).limit(1);
    return b ? cycleLookup(b.c) : cycleLookup(p.payload.cycleId);
  }
  if (p.entityType === 'FRAUD_ALERT') {
    const [a] = await t.select({ c: fraudAlerts.cycleId }).from(fraudAlerts).where(eq(fraudAlerts.id, p.entityId)).limit(1);
    return a ? cycleLookup(a.c) : null;
  }
  return cycleLookup(p.payload.cycleId);
}

export async function logAuditEvent(params: AuditActionParams, tx?: Tx) {
  const run = async (t: Tx) => {
    params = { ...params, groupId: await resolveGroupId(t, params) };
    await t.execute(sql`select pg_advisory_xact_lock(727001)`);
    const [last] = await t.select({ sequence: auditLogs.sequence, entryHash: auditLogs.entryHash })
      .from(auditLogs).orderBy(desc(auditLogs.sequence)).limit(1);
    return append(t, params, last);
  };
  return tx ? run(tx) : db.transaction(run);
}

async function append(t: Tx, params: AuditActionParams, last?: { sequence: number; entryHash: string }) {
  // The serial is allocated by the insert; to hash it we claim the next value up front.
  const nextRes: any = await t.execute(sql`select nextval(pg_get_serial_sequence('audit_logs','sequence')) as n`);
  const sequence = Number((nextRes.rows ?? nextRes)[0].n);
  const previousHash = last?.entryHash ?? GENESIS_HASH;
  const row = {
    sequence,
    actorId: params.actorId ?? null,
    actorRole: params.actorRole,
    action: params.action,
    entityType: params.entityType,
    entityId: params.entityId,
    groupId: params.groupId ?? null,
    payloadJson: JSON.stringify(params.payload),
  };
  const entryHash = generateEntryHash(previousHash, hashInput(row));
  const [log] = await t.insert(auditLogs).values({
    ...row,
    previousHash,
    entryHash,
    signature: signMessage(entryHash),
    signerKeyId: signerKeyId(),
  }).returning();
  return log;
}

export interface IntegrityReport {
  valid: boolean;
  totalEntries: number;
  corruptedEntryId?: string;
  corruptedSequence?: number;
  reason?: 'BROKEN_CHAIN' | 'HASH_MISMATCH' | 'BAD_SIGNATURE';
  message: string;
  publicKeyPem: string;
}

/** Validates the whole chain: links, recomputed hashes, signatures (NFR13). */
let integrityCache: { at: number; report: IntegrityReport } | null = null;

/** `maxAgeMs` lets read-heavy dashboards reuse a recent verification; audit endpoints and exports always re-verify. */
export async function verifyAuditChainIntegrity(opts: { maxAgeMs?: number } = {}): Promise<IntegrityReport> {
  if (opts.maxAgeMs && integrityCache && Date.now() - integrityCache.at < opts.maxAgeMs) return integrityCache.report;
  const report = await verifyChain();
  integrityCache = { at: Date.now(), report };
  return report;
}

async function verifyChain(): Promise<IntegrityReport> {
  const all = await db.select().from(auditLogs).orderBy(asc(auditLogs.sequence));
  let expectedPrev = GENESIS_HASH;
  const fail = (log: (typeof all)[number], reason: IntegrityReport['reason'], message: string): IntegrityReport => ({
    valid: false, totalEntries: all.length, corruptedEntryId: log.id, corruptedSequence: log.sequence, reason, message, publicKeyPem: publicKeyPem(),
  });
  for (const log of all) {
    if (log.previousHash !== expectedPrev) {
      return fail(log, 'BROKEN_CHAIN', `Broken chain at entry #${log.sequence}: expected previous hash ${expectedPrev.slice(0, 8)}..., found ${log.previousHash?.slice(0, 8)}...`);
    }
    const recomputed = generateEntryHash(expectedPrev, hashInput(log));
    if (recomputed !== log.entryHash) {
      return fail(log, 'HASH_MISMATCH', `Tampering detected at entry #${log.sequence}: recomputed hash ${recomputed.slice(0, 8)}... does not match stored ${log.entryHash.slice(0, 8)}...`);
    }
    if (!verifySignature(log.entryHash, log.signature)) {
      return fail(log, 'BAD_SIGNATURE', `Signature at entry #${log.sequence} does not verify against the ledger key.`);
    }
    expectedPrev = log.entryHash;
  }
  return {
    valid: true,
    totalEntries: all.length,
    message: `All ${all.length} ledger entries verified: SHA-256 chain intact, Ed25519 signatures valid.`,
    publicKeyPem: publicKeyPem(),
  };
}
