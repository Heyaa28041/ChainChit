import { cookies } from 'next/headers';
import { db } from './db';
import { users } from './db/schema';
import { eq } from 'drizzle-orm';
import crypto from 'crypto';
import { createSessionToken, readSessionToken, SESSION_MAX_AGE_SECONDS } from './server/crypto';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: 'MEMBER' | 'FOREMAN' | 'OVERSIGHT_VIEWER';
  kycStatus: string;
  trustScore: number;
  memberCode: string | null;
}

export const SESSION_COOKIE_NAME = 'chainchit_session';

/** Sets the signed session cookie. */
export async function startSession(userId: string) {
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, createSessionToken(userId), {
    path: '/',
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: SESSION_MAX_AGE_SECONDS,
  });
}

const SESSION_COOKIE = 'chainchit_session';

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, combined: string): boolean {
  try {
    const [salt, key] = combined.split(':');
    if (!salt || !key) return false;
    const hash = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(key, 'hex'), Buffer.from(hash, 'hex'));
  } catch {
    return false;
  }
}

/**
 * Retrieves the currently authenticated user from secure session cookie
 */
export async function getCurrentUser(): Promise<AuthUser | null> {
  const cookieStore = await cookies();
  const sessionUserId = readSessionToken(cookieStore.get(SESSION_COOKIE)?.value);

  if (!sessionUserId) {
    return null;
  }

  const [user] = await db.select().from(users).where(eq(users.id, sessionUserId)).limit(1);
  if (!user) {
    return null;
  }

  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    kycStatus: user.kycStatus,
    trustScore: user.trustScore,
    memberCode: user.memberCode,
  };
}

/** Role gate used by every mutating route. Returns the user, or a ready-made error response. */
export async function requireRole(...roles: AuthUser['role'][]): Promise<{ user: AuthUser } | { error: Response }> {
  const user = await getCurrentUser();
  const json = (body: object, status: number) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
  if (!user) return { error: json({ error: 'Sign in required', code: 'UNAUTHENTICATED' }, 401) };
  if (!roles.includes(user.role)) return { error: json({ error: `Access denied. ${roles.join(' or ')} role required.`, code: 'FORBIDDEN' }, 403) };
  return { user };
}
