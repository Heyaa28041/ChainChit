import {
  pgTable, text, timestamp, integer, doublePrecision, boolean, uuid, pgEnum, uniqueIndex, index, serial,
} from 'drizzle-orm/pg-core';
import { relations, sql } from 'drizzle-orm';

export const roleEnum = pgEnum('role', ['MEMBER', 'FOREMAN', 'OVERSIGHT_VIEWER']);
export const cycleStatusEnum = pgEnum('cycle_status', [
  'SCHEDULED',
  'BIDDING_OPEN',
  'BIDDING_CLOSED',
  'SETTLED',
  'DISPUTED',
]);
export const bidStatusEnum = pgEnum('bid_status', [
  'ACCEPTED',
  'FLAGGED_SUSPICIOUS',
  'REJECTED',
  'WINNING_BID',
]);
export const escrowStatusEnum = pgEnum('escrow_status', ['LOCKED', 'RELEASED', 'HELD_FOR_REVIEW']);

export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  memberCode: text('member_code').unique(), // FT-01: human-readable ID such as M1001
  name: text('name').notNull(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  mobile: text('mobile').notNull(),
  govtId: text('govt_id').notNull(), // NFR02: AES-256-GCM encrypted at rest ("enc:v1:...")
  role: roleEnum('role').default('MEMBER').notNull(),
  kycStatus: text('kyc_status').default('PENDING').notNull(), // PENDING | UNDER_REVIEW | VERIFIED | REJECTED
  kycRejectionReason: text('kyc_rejection_reason'), // FR04
  trustScore: doublePrecision('trust_score').default(100.0).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const kycDocuments = pgTable('kyc_documents', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  docType: text('doc_type').notNull(), // AADHAAR | PAN
  fileName: text('file_name').notNull(),
  mimeType: text('mime_type').notNull(),
  sizeBytes: integer('size_bytes').notNull(),
  storageKey: text('storage_key').notNull(), // encrypted blob on disk
  sha256: text('sha256').notNull(), // digest of the plaintext, for integrity checks
  uploadedAt: timestamp('uploaded_at').defaultNow().notNull(),
});

export const chitGroups = pgTable('chit_groups', {
  id: uuid('id').defaultRandom().primaryKey(),
  code: text('code').unique(), // FR08: unique group ID such as G001
  name: text('name').notNull(),
  chitValue: doublePrecision('chit_value').notNull(),
  numberOfMembers: integer('number_of_members').notNull(),
  cycleDurationDays: integer('cycle_duration_days').default(30).notNull(),
  totalCycles: integer('total_cycles').notNull().default(0), // FR11
  minMembers: integer('min_members').notNull().default(2), // FR10
  startDate: timestamp('start_date').defaultNow().notNull(), // FR11
  status: text('status').notNull().default('ACTIVE'), // ACTIVE | COMPLETED (FR09)
  biddingWindowSeconds: integer('bidding_window_seconds').notNull().default(180), // FR17
  gracePeriodDays: integer('grace_period_days').notNull().default(5), // FR15
  reminderLeadDays: integer('reminder_lead_days').notNull().default(3), // FR14
  disputeWindowDays: integer('dispute_window_days').notNull().default(7), // FR31
  allowRepeatWinners: boolean('allow_repeat_winners').notNull().default(false),
  winFreqWindow: integer('win_freq_window').notNull().default(5), // FR22: look-back window (cycles)
  winFreqMinWins: integer('win_freq_min_wins').notNull().default(3), // FR22: wins in the window that trigger review
  foremanId: uuid('foreman_id').references(() => users.id).notNull(),
  historicalMeanBid: doublePrecision('historical_mean_bid').default(85000.0).notNull(),
  historicalSdBid: doublePrecision('historical_sd_bid').default(4000.0).notNull(),
  fraudThresholdZ: doublePrecision('fraud_threshold_z').default(2.5).notNull(), // NFR11: editable at runtime
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const groupMembers = pgTable('group_members', {
  id: uuid('id').defaultRandom().primaryKey(),
  groupId: uuid('group_id').references(() => chitGroups.id, { onDelete: 'cascade' }).notNull(),
  memberId: uuid('member_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  delinquent: boolean('delinquent').notNull().default(false), // FR15
  enrolledAt: timestamp('enrolled_at').defaultNow().notNull(),
}, (t) => [uniqueIndex('group_member_unique').on(t.groupId, t.memberId)]);

export const cycles = pgTable('cycles', {
  id: uuid('id').defaultRandom().primaryKey(),
  groupId: uuid('group_id').references(() => chitGroups.id, { onDelete: 'cascade' }).notNull(),
  cycleNumber: integer('cycle_number').notNull(),
  status: cycleStatusEnum('status').default('SCHEDULED').notNull(),
  startDate: timestamp('start_date'), // FR11 schedule
  endDate: timestamp('end_date'), // FR11 schedule
  dueDate: timestamp('due_date'), // contribution due date for this cycle
  biddingStartTime: timestamp('bidding_start_time'),
  biddingEndTime: timestamp('bidding_end_time'),
  biddingDurationSeconds: integer('bidding_duration_seconds').default(120).notNull(),
  winningBidId: uuid('winning_bid_id'),
  winnerMemberId: uuid('winner_member_id').references(() => users.id),
  payoutAmount: doublePrecision('payout_amount'),
  escrowStatus: escrowStatusEnum('escrow_status').default('LOCKED').notNull(),
  settledAt: timestamp('settled_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (t) => [uniqueIndex('cycle_group_number_unique').on(t.groupId, t.cycleNumber)]);

export const bids = pgTable('bids', {
  id: uuid('id').defaultRandom().primaryKey(),
  cycleId: uuid('cycle_id').references(() => cycles.id, { onDelete: 'cascade' }).notNull(),
  memberId: uuid('member_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  bidAmount: doublePrecision('bid_amount').notNull(),
  timestamp: timestamp('timestamp').defaultNow().notNull(),
  status: bidStatusEnum('status').default('ACCEPTED').notNull(),
  zScore: doublePrecision('z_score').default(0.0).notNull(),
  isAnomaly: boolean('is_anomaly').default(false).notNull(),
  fraudReason: text('fraud_reason'),
});

export const fraudAlerts = pgTable('fraud_alerts', {
  id: uuid('id').defaultRandom().primaryKey(),
  bidId: uuid('bid_id').references(() => bids.id, { onDelete: 'cascade' }).notNull(),
  cycleId: uuid('cycle_id').references(() => cycles.id, { onDelete: 'cascade' }).notNull(),
  memberId: uuid('member_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  ruleViolated: text('rule_violated').notNull(), // UNDERBID_DEVIATION | COLLUSION_WIN_FREQUENCY | ALREADY_WON
  severity: text('severity').default('HIGH').notNull(),
  details: text('details').notNull(),
  resolved: boolean('resolved').default(false).notNull(),
  resolutionAction: text('resolution_action'), // OVERRIDDEN | DISQUALIFIED
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

/** FR12/FR13: one row per payment attempt. Only CONFIRMED rows are in escrow. */
export const contributions = pgTable('contributions', {
  id: uuid('id').defaultRandom().primaryKey(),
  cycleId: uuid('cycle_id').references(() => cycles.id, { onDelete: 'cascade' }).notNull(),
  memberId: uuid('member_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  amount: doublePrecision('amount').notNull(),
  paymentMode: text('payment_mode').notNull().default('UPI'),
  status: text('status').notNull().default('CONFIRMED'), // CONFIRMED | DECLINED
  escrowStatus: text('escrow_status').notNull().default('NONE'), // NONE | LOCKED | RELEASED
  paymentRef: text('payment_ref'),
  paidAt: timestamp('paid_at').defaultNow().notNull(),
}, (t) => [
  // a member can have at most one confirmed contribution per cycle (declined attempts may be retried)
  uniqueIndex('contribution_confirmed_unique').on(t.cycleId, t.memberId).where(sql`${t.status} = 'CONFIRMED'`),
]);

/** FR27-FR30: exactly one payout per cycle (unique cycle_id). */
export const payouts = pgTable('payouts', {
  id: uuid('id').defaultRandom().primaryKey(),
  cycleId: uuid('cycle_id').references(() => cycles.id, { onDelete: 'cascade' }).notNull().unique(),
  winnerId: uuid('winner_id').references(() => users.id).notNull(),
  amount: doublePrecision('amount').notNull(),
  dividendPerMember: doublePrecision('dividend_per_member').notNull().default(0),
  receiptId: text('receipt_id').notNull().unique(),
  receiptJson: text('receipt_json').notNull(), // canonical JSON that was signed
  signature: text('signature').notNull(), // Ed25519, base64
  signerKeyId: text('signer_key_id').notNull(),
  payoutDate: timestamp('payout_date').defaultNow().notNull(),
});

export const disputes = pgTable('disputes', {
  id: uuid('id').defaultRandom().primaryKey(),
  code: text('code').unique(), // D001
  raisedBy: uuid('raised_by').references(() => users.id).notNull(),
  cycleId: uuid('cycle_id').references(() => cycles.id).notNull(),
  bidId: uuid('bid_id').references(() => bids.id),
  payoutId: uuid('payout_id').references(() => payouts.id),
  description: text('description').notNull(),
  status: text('status').notNull().default('OPEN'), // OPEN | RESOLVED | REJECTED | ESCALATED
  comments: text('comments'),
  evidenceJson: text('evidence_json').notNull(), // FR32: auto-attached history + fraud logs
  resolvedBy: uuid('resolved_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const notifications = pgTable('notifications', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  type: text('type').notNull(),
  message: text('message').notNull(),
  entityType: text('entity_type'),
  entityId: text('entity_id'),
  dedupeKey: text('dedupe_key'),
  readAt: timestamp('read_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (t) => [
  uniqueIndex('notification_dedupe').on(t.userId, t.dedupeKey),
  index('notification_user_idx').on(t.userId, t.createdAt),
]);

/** NFR12: maintenance may never overlap an active bidding session. */
export const maintenanceWindows = pgTable('maintenance_windows', {
  id: uuid('id').defaultRandom().primaryKey(),
  startsAt: timestamp('starts_at').notNull(),
  endsAt: timestamp('ends_at').notNull(),
  reason: text('reason').notNull(),
  createdBy: uuid('created_by').references(() => users.id).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

/**
 * Append-only, SHA-256 hash-chained and Ed25519-signed ledger (NFR09, NFR13).
 * Rows are immutable: a database trigger rejects UPDATE, DELETE and TRUNCATE (see lib/db/triggers.sql).
 */
export const auditLogs = pgTable('audit_logs', {
  id: uuid('id').defaultRandom().primaryKey(),
  sequence: serial('sequence').notNull().unique(), // position in the hash chain
  actorId: uuid('actor_id').references(() => users.id),
  actorRole: text('actor_role').notNull(),
  action: text('action').notNull(),
  entityType: text('entity_type').notNull(),
  entityId: text('entity_id').notNull(),
  groupId: text('group_id'), // lets per-group exports select their entries
  payloadJson: text('payload_json').notNull(),
  previousHash: text('previous_hash'),
  entryHash: text('entry_hash').notNull(),
  signature: text('signature').notNull(), // Ed25519 over entryHash, base64
  signerKeyId: text('signer_key_id').notNull(),
  timestamp: timestamp('timestamp').defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  bids: many(bids),
  memberships: many(groupMembers),
  fraudAlerts: many(fraudAlerts),
  auditLogs: many(auditLogs),
}));

export const chitGroupsRelations = relations(chitGroups, ({ one, many }) => ({
  foreman: one(users, { fields: [chitGroups.foremanId], references: [users.id] }),
  members: many(groupMembers),
  cycles: many(cycles),
}));

export const cyclesRelations = relations(cycles, ({ one, many }) => ({
  group: one(chitGroups, { fields: [cycles.groupId], references: [chitGroups.id] }),
  winner: one(users, { fields: [cycles.winnerMemberId], references: [users.id] }),
  bids: many(bids),
  fraudAlerts: many(fraudAlerts),
}));

export const bidsRelations = relations(bids, ({ one }) => ({
  cycle: one(cycles, { fields: [bids.cycleId], references: [cycles.id] }),
  member: one(users, { fields: [bids.memberId], references: [users.id] }),
}));

export const fraudAlertsRelations = relations(fraudAlerts, ({ one }) => ({
  bid: one(bids, { fields: [fraudAlerts.bidId], references: [bids.id] }),
  cycle: one(cycles, { fields: [fraudAlerts.cycleId], references: [cycles.id] }),
  member: one(users, { fields: [fraudAlerts.memberId], references: [users.id] }),
}));
