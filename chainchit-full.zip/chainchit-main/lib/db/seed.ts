import { db, pool } from './index';
import { users } from './schema';
import { hashPassword } from '../auth';
import { logAuditEvent } from '../audit-logger';
import { encryptField } from '../server/crypto';
import { nextMemberCode } from '../server/codes';
import { sql } from 'drizzle-orm';

/**
 * Seeds the three role accounts. Run `npm run db:setup -- --reset` first for a clean database
 * (the ledger is append-only, so seeding never deletes it).
 */
export async function seedDatabase() {
  const existing = await db.select({ id: users.id }).from(users).limit(1);
  if (existing.length) {
    console.log('Users already exist; leaving the ledger untouched. Use `npm run db:reset` for a clean start.');
    return;
  }
  const password = process.env.SEED_PASSWORD || 'Password@123';
  const accounts = [
    { name: 'Rajesh (Foreman)', email: 'foreman@chainchit.io', role: 'FOREMAN' as const, mobile: '9876543210', govtId: 'PAN-FRM-001' },
    { name: 'Meera (Oversight)', email: 'oversight@chainchit.io', role: 'OVERSIGHT_VIEWER' as const, mobile: '9876543211', govtId: 'PAN-OVS-001' },
  ];
  await db.transaction(async (tx) => {
    for (const a of accounts) {
      const memberCode = await nextMemberCode(tx);
      const [u] = await tx.insert(users).values({ ...a, memberCode, govtId: encryptField(a.govtId), passwordHash: hashPassword(password), kycStatus: 'VERIFIED' }).returning();
      await logAuditEvent({ actorId: u.id, actorRole: u.role, action: 'USER_ONBOARDED', entityType: 'USER', entityId: u.id, payload: { memberCode, role: u.role, email: u.email, seed: true } }, tx);
    }
    await logAuditEvent({ actorRole: 'SYSTEM', action: 'SYSTEM_INITIALIZED', entityType: 'SYSTEM', entityId: 'genesis', payload: { message: 'ChainChit ledger initialised' } }, tx);
  });
  console.log('Seeded: foreman@chainchit.io and oversight@chainchit.io (password from SEED_PASSWORD, default Password@123).');
  console.log('Members register themselves via /register.');
}

if (require.main === module) {
  seedDatabase().then(() => pool.end()).catch((err) => { console.error('Seed error:', err); process.exit(1); });
}
