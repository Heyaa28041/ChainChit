-- NFR13 / NFT-16 / NFT-17: the ledger is append-only. Nothing, not even the application role, may rewrite it.
CREATE OR REPLACE FUNCTION chainchit_block_ledger_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'audit_logs is append-only: % is not permitted', TG_OP USING ERRCODE = '55000';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS audit_logs_no_update ON audit_logs;
CREATE TRIGGER audit_logs_no_update BEFORE UPDATE OR DELETE ON audit_logs
  FOR EACH ROW EXECUTE FUNCTION chainchit_block_ledger_mutation();
DROP TRIGGER IF EXISTS audit_logs_no_truncate ON audit_logs;
CREATE TRIGGER audit_logs_no_truncate BEFORE TRUNCATE ON audit_logs
  FOR EACH STATEMENT EXECUTE FUNCTION chainchit_block_ledger_mutation();

-- FR16: escrowed contributions can only be released from inside the payout transaction,
-- which sets chainchit.payout = 'on' for that transaction only.
CREATE OR REPLACE FUNCTION chainchit_guard_escrow() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' AND OLD.escrow_status = 'LOCKED' THEN
    RAISE EXCEPTION 'escrowed contributions cannot be deleted' USING ERRCODE = '55000';
  END IF;
  IF TG_OP = 'UPDATE' AND OLD.escrow_status = 'LOCKED' AND NEW.escrow_status <> 'LOCKED'
     AND coalesce(current_setting('chainchit.payout', true), '') <> 'on' THEN
    RAISE EXCEPTION 'escrow can only be released through the payout contract' USING ERRCODE = '55000';
  END IF;
  IF TG_OP = 'UPDATE' AND OLD.escrow_status = 'LOCKED' AND (NEW.amount <> OLD.amount OR NEW.member_id <> OLD.member_id OR NEW.cycle_id <> OLD.cycle_id) THEN
    RAISE EXCEPTION 'escrowed contributions are immutable' USING ERRCODE = '55000';
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS contributions_escrow_guard ON contributions;
CREATE TRIGGER contributions_escrow_guard BEFORE UPDATE OR DELETE ON contributions
  FOR EACH ROW EXECUTE FUNCTION chainchit_guard_escrow();

-- FR30: payouts are never rewritten once issued.
CREATE OR REPLACE FUNCTION chainchit_block_payout_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'payouts are immutable once issued' USING ERRCODE = '55000';
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS payouts_immutable ON payouts;
CREATE TRIGGER payouts_immutable BEFORE UPDATE OR DELETE ON payouts
  FOR EACH ROW EXECUTE FUNCTION chainchit_block_payout_mutation();
