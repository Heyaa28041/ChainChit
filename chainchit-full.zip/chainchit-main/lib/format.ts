const inr = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 });

/** ₹1,00,000 */
export function formatINR(n: number | null | undefined): string {
  if (n === null || n === undefined || Number.isNaN(n)) return '—';
  return `₹${inr.format(Math.round(n))}`;
}

/** ₹82.5k / ₹1L — for chart labels */
export function formatINRShort(n: number): string {
  const abs = Math.abs(n);
  if (abs >= 100000) {
    const v = n / 100000;
    return `₹${Number.isInteger(v) ? v : v.toFixed(2).replace(/0$/, '')}L`;
  }
  if (abs >= 1000) {
    const v = n / 1000;
    return `₹${Number.isInteger(v) ? v : v.toFixed(1)}k`;
  }
  return `₹${Math.round(n)}`;
}

/** 125 → "02:05" */
export function formatClock(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

export function formatTime(value: string | Date | null | undefined): string {
  if (!value) return '—';
  return new Date(value).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

export function formatDateTime(value: string | Date | null | undefined): string {
  if (!value) return '—';
  return new Date(value).toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDate(value: string | Date | null | undefined): string {
  if (!value) return '—';
  return new Date(value).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function shortHash(hash: string | null | undefined, len = 8): string {
  if (!hash) return '—';
  return `${hash.slice(0, len)}…${hash.slice(-4)}`;
}

export function initials(name: string): string {
  return name
    .replace(/\(.*?\)/g, '')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? '')
    .join('');
}

export function roleLabel(role: string): string {
  if (role === 'FOREMAN') return 'Foreman';
  if (role === 'OVERSIGHT_VIEWER') return 'Oversight';
  return 'Member';
}
