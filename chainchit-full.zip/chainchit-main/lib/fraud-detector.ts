import { db } from './db';
import { bids, cycles, users, chitGroups, fraudAlerts } from './db/schema';
import { eq, and, sql, desc, inArray } from 'drizzle-orm';

export interface FraudCheckResult {
  isAnomaly: boolean;
  zScore: number;
  mean: number;
  stdDev: number;
  ruleViolated?: 'UNDERBID_DEVIATION' | 'COLLUSION_WIN_FREQUENCY' | 'ALREADY_WON';
  severity?: 'HIGH' | 'MEDIUM';
  details?: string;
}

export interface GroupBidStats {
  mean: number;
  stdDev: number;
  thresholdZ: number;
  /** how many clean historical bids the live figures are built from */
  sampleSize: number;
  /** 'history' once enough clean bids exist, otherwise the group's configured baseline */
  source: 'baseline' | 'history';
}

/**
 * The mean / standard deviation the fraud check measures bids against.
 * Shared by evaluateBidFraud and the cycle API so the UI always draws the same flag line the server enforces.
 */
export async function getGroupBidStats(groupId: string): Promise<GroupBidStats> {
  const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, groupId)).limit(1);
  if (!group) {
    throw new Error(`Group ${groupId} not found`);
  }

  const historicalBids = await db
    .select({ bidAmount: bids.bidAmount })
    .from(bids)
    .innerJoin(cycles, eq(bids.cycleId, cycles.id))
    .where(and(eq(cycles.groupId, groupId), eq(bids.status, 'ACCEPTED')));

  let mean = group.historicalMeanBid;
  let stdDev = group.historicalSdBid;
  let source: GroupBidStats['source'] = 'baseline';

  // With at least 4 historical clean bids, calculate dynamic mean & SD
  if (historicalBids.length >= 4) {
    const amounts = historicalBids.map((b) => b.bidAmount);
    const sum = amounts.reduce((acc, val) => acc + val, 0);
    mean = sum / amounts.length;
    const variance = amounts.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / amounts.length;
    stdDev = Math.sqrt(variance) || group.historicalSdBid;
    source = 'history';
  }

  return {
    mean,
    stdDev,
    thresholdZ: group.fraudThresholdZ || 2.5,
    sampleSize: historicalBids.length,
    source,
  };
}

export interface WinFrequency {
  wins: number;
  window: number; // number of most recent settled cycles looked at
  score: number; // wins / window, 0..1
  flagged: boolean;
}

/**
 * FR22: how often has this member won across the group's most recent settled cycles?
 * `score` is wins / cycles looked at; `flagged` once wins reach the group's configured minimum.
 */
export async function getWinFrequency(groupId: string, memberId: string): Promise<WinFrequency> {
  const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, groupId)).limit(1);
  if (!group) throw new Error(`Group ${groupId} not found`);
  const recent = await db
    .select({ winnerMemberId: cycles.winnerMemberId })
    .from(cycles)
    .where(and(eq(cycles.groupId, groupId), eq(cycles.status, 'SETTLED')))
    .orderBy(desc(cycles.cycleNumber))
    .limit(group.winFreqWindow);
  const wins = recent.filter((c) => c.winnerMemberId === memberId).length;
  const window = recent.length;
  return { wins, window, score: window ? wins / window : 0, flagged: wins >= group.winFreqMinWins };
}

/**
 * Evaluates a bid against statistical thresholds and collusion rules
 * Requirements: FR22, FR23, FR24, FR25
 */
export async function evaluateBidFraud(
  groupId: string,
  cycleId: string,
  memberId: string,
  bidAmount: number
): Promise<FraudCheckResult> {
  // 1. Fetch group configuration & baseline stats
  const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, groupId)).limit(1);
  if (!group) {
    throw new Error(`Group ${groupId} not found`);
  }

  // 2. Fetch member & past cycle stats
  const [member] = await db.select().from(users).where(eq(users.id, memberId)).limit(1);
  if (!member) {
    throw new Error(`Member ${memberId} not found`);
  }

  // Rule A: the classic chit-fund rule - one prize per member per group term - unless the group opts out.
  if (!group.allowRepeatWinners) {
    const pastWins = await db
      .select()
      .from(cycles)
      .where(and(eq(cycles.groupId, groupId), eq(cycles.winnerMemberId, memberId), eq(cycles.status, 'SETTLED')));

    if (pastWins.length > 0) {
      return {
        isAnomaly: true,
        zScore: 0,
        mean: group.historicalMeanBid,
        stdDev: group.historicalSdBid,
        ruleViolated: 'ALREADY_WON',
        severity: 'HIGH',
        details: `Member ${member.name} has already won Cycle #${pastWins[0].cycleNumber} in this group. Multiple prize collections violate chit fund equity.`,
      };
    }
  } else {
    // Rule B (FR22): repeated-winner pattern across recent cycles points at possible collusion.
    const freq = await getWinFrequency(groupId, memberId);
    if (freq.flagged) {
      return {
        isAnomaly: true,
        zScore: 0,
        mean: group.historicalMeanBid,
        stdDev: group.historicalSdBid,
        ruleViolated: 'COLLUSION_WIN_FREQUENCY',
        severity: 'HIGH',
        details: `Win-frequency review: ${member.name} won ${freq.wins} of the last ${freq.window} cycles (score ${freq.score.toFixed(2)}; review at ${group.winFreqMinWins}+ wins).`,
      };
    }
  }

  // 3. Statistical Underbid Deviation Check (FR23, FR24)
  const stats = await getGroupBidStats(groupId);
  const mean = stats.mean;
  const stdDev = stats.stdDev;

  // Z-Score for reverse auction:
  // How many standard deviations below the mean is this bid?
  // Z = (mean - bidAmount) / stdDev
  // Positive Z means the bid is lower than average (higher discount).
  const zScore = parseFloat(((mean - bidAmount) / (stdDev > 0 ? stdDev : 1)).toFixed(2));
  const threshold = stats.thresholdZ;

  if (zScore > threshold) {
    return {
      isAnomaly: true,
      zScore,
      mean,
      stdDev,
      ruleViolated: 'UNDERBID_DEVIATION',
      severity: 'HIGH',
      details: `Abnormal underbid detected: Bid of ₹${bidAmount.toLocaleString('en-IN')} is ${zScore} standard deviations below historical mean (₹${Math.round(mean).toLocaleString('en-IN')}, σ=₹${Math.round(stdDev).toLocaleString('en-IN')}). Threshold is ${threshold}σ.`,
    };
  }

  return {
    isAnomaly: false,
    zScore,
    mean,
    stdDev,
  };
}

/**
 * FR25: recalculate trust scores for the bidding members and the group's foreman at the end of a cycle.
 * Members: +5 for each clean bid, -25 for each bid that stayed flagged / was disqualified.
 * Foreman: +3 when the cycle closes with every alert adjudicated, -5 when alerts are still open.
 */
export async function updateTrustScores(cycleId: string) {
  const [cycle] = await db.select().from(cycles).where(eq(cycles.id, cycleId)).limit(1);
  if (!cycle) return;

  const cycleBids = await db.select().from(bids).where(eq(bids.cycleId, cycleId));

  // One adjustment per member per cycle, so bidding many times cannot farm points.
  const delta = new Map<string, number>();
  for (const b of cycleBids) {
    const clean = b.status === 'ACCEPTED' || b.status === 'WINNING_BID';
    const bad = b.status === 'FLAGGED_SUSPICIOUS' || b.status === 'REJECTED';
    const cur = delta.get(b.memberId) ?? 0;
    if (bad) delta.set(b.memberId, Math.min(cur, 0) - 25);
    else if (clean && cur >= 0) delta.set(b.memberId, 5);
  }
  for (const [memberId, d] of delta) {
    await db
      .update(users)
      .set({ trustScore: sql`LEAST(100.0, GREATEST(0.0, ${users.trustScore} + ${d}))` })
      .where(eq(users.id, memberId));
  }

  const [group] = await db.select().from(chitGroups).where(eq(chitGroups.id, cycle.groupId)).limit(1);
  if (group) {
    const open = await db
      .select({ id: fraudAlerts.id })
      .from(fraudAlerts)
      .where(and(eq(fraudAlerts.cycleId, cycleId), eq(fraudAlerts.resolved, false)));
    const d = open.length === 0 ? 3 : -5;
    await db
      .update(users)
      .set({ trustScore: sql`LEAST(100.0, GREATEST(0.0, ${users.trustScore} + ${d}))` })
      .where(eq(users.id, group.foremanId));
  }
}
