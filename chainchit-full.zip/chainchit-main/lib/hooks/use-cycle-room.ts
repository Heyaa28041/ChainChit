'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { api, ApiError } from '@/lib/api';
import type { Bid, CycleDetail } from '@/lib/types';

export type RoomEvent =
  | { kind: 'bid'; bid: Bid }
  | { kind: 'flag'; bid: Bid }
  | { kind: 'winner'; winnerName?: string; amount?: number }
  | { kind: 'settled' }
  | { kind: 'reset' }
  | { kind: 'disputed' }
  | { kind: 'closed' }
  | { kind: 'alert-resolved'; winnerChanged: boolean };

const RESYNC_EVENTS = [
  'WINNER_DETERMINED',
  'CYCLE_SETTLED',
  'CYCLE_RESET',
  'ALERT_RESOLVED',
  'CYCLE_DISPUTED',
  'CYCLE_CLOSED',
] as const;

function sortBids(bids: Bid[]): Bid[] {
  return [...bids].sort(
    (a, b) => a.bidAmount - b.bidAmount || Date.parse(a.timestamp) - Date.parse(b.timestamp)
  );
}

/**
 * Loads one auction room and keeps it live:
 *  - GET /api/cycles/:id for the full picture
 *  - SSE /api/cycles/:id/stream for new bids and state changes
 *  - re-sync after any SSE reconnect so no event is ever silently missed
 */
export function useCycleRoom(cycleId: string | null, onEvent?: (event: RoomEvent) => void) {
  const [detail, setDetail] = useState<CycleDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [connected, setConnected] = useState(false);
  const [freshBidIds, setFreshBidIds] = useState<ReadonlySet<string>>(new Set());
  /** serverNow − clientNow, so countdowns follow the server's clock, not the laptop's */
  const [skewMs, setSkewMs] = useState(0);

  const requestSeq = useRef(0);
  const onEventRef = useRef(onEvent);
  useEffect(() => {
    onEventRef.current = onEvent;
  });

  const markFresh = useCallback((id: string) => {
    setFreshBidIds((prev) => new Set(prev).add(id));
    window.setTimeout(() => {
      setFreshBidIds((prev) => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    }, 2600);
  }, []);

  const reload = useCallback(async () => {
    if (!cycleId) return;
    const seq = ++requestSeq.current;
    try {
      const data = await api<CycleDetail>(`/api/cycles/${cycleId}`);
      if (seq !== requestSeq.current) return; // a newer request superseded this one
      const { cycle } = data;
      if (cycle.status === 'BIDDING_OPEN' && cycle.biddingEndTime && cycle.secondsRemaining > 0) {
        const serverNow = Date.parse(cycle.biddingEndTime) - cycle.secondsRemaining * 1000 - 500;
        setSkewMs(serverNow - Date.now());
      }
      setDetail({ ...data, bids: sortBids(data.bids) });
      setNotFound(false);
    } catch (err) {
      if (seq !== requestSeq.current) return;
      if (err instanceof ApiError && err.status === 404) {
        setDetail(null);
        setNotFound(true);
      }
    } finally {
      if (seq === requestSeq.current) setLoading(false);
    }
  }, [cycleId]);

  /** Merge a bid into local state immediately (from the POST response or SSE). */
  const applyBid = useCallback(
    (bid: Bid) => {
      setDetail((prev) => {
        if (!prev || prev.bids.some((b) => b.id === bid.id)) return prev;
        return { ...prev, bids: sortBids([...prev.bids, bid]) };
      });
      markFresh(bid.id);
    },
    [markFresh]
  );

  // Initial load / room switch
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLoading(true);
    setDetail(null);
    setNotFound(false);
    void reload();
  }, [cycleId, reload]);

  // Live stream
  useEffect(() => {
    if (!cycleId) return;
    const es = new EventSource(`/api/cycles/${cycleId}/stream`);
    let hasOpened = false;

    es.onopen = () => {
      setConnected(true);
      if (hasOpened) void reload(); // reconnect: pull anything missed while offline
      hasOpened = true;
    };
    es.onerror = () => setConnected(false);

    es.addEventListener('NEW_BID', (e) => {
      try {
        const payload = JSON.parse((e as MessageEvent).data) as { bid: Bid };
        const bid = payload.bid;
        applyBid(bid);
        onEventRef.current?.({ kind: bid.status === 'FLAGGED_SUSPICIOUS' ? 'flag' : 'bid', bid });
      } catch {
        void reload();
      }
    });

    for (const name of RESYNC_EVENTS) {
      es.addEventListener(name, (e) => {
        let data: any = {};
        try {
          data = JSON.parse((e as MessageEvent).data);
        } catch {
          // ignore malformed payload; we resync below anyway
        }
        void reload();
        const cb = onEventRef.current;
        if (!cb) return;
        if (name === 'WINNER_DETERMINED') cb({ kind: 'winner', winnerName: data?.winner?.name, amount: data?.winningBid?.bidAmount ?? data?.payoutAmount });
        else if (name === 'CYCLE_SETTLED') cb({ kind: 'settled' });
        else if (name === 'CYCLE_RESET') cb({ kind: 'reset' });
        else if (name === 'CYCLE_DISPUTED') cb({ kind: 'disputed' });
        else if (name === 'CYCLE_CLOSED') cb({ kind: 'closed' });
        else if (name === 'ALERT_RESOLVED') cb({ kind: 'alert-resolved', winnerChanged: !!data?.winnerChanged });
      });
    }

    return () => {
      es.close();
      setConnected(false);
    };
  }, [cycleId, reload, applyBid]);

  return { detail, loading, notFound, connected, freshBidIds, skewMs, reload, applyBid };
}
