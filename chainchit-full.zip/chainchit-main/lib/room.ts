import type { Bid } from '@/lib/types';

/** A bid that still counts toward winning. */
export function isValidBid(bid: Bid): boolean {
  return bid.status === 'ACCEPTED' || bid.status === 'WINNING_BID';
}

/** Bids arrive sorted lowest-first, so the first valid one leads the reverse auction. */
export function leadingBid(bids: Bid[]): Bid | null {
  return bids.find(isValidBid) ?? null;
}

export const RULE_LABELS: Record<string, string> = {
  UNDERBID_DEVIATION: 'Underbid beyond the flag line',
  ALREADY_WON: 'Member already won in this group',
  COLLUSION_WIN_FREQUENCY: 'Repeated winning pattern',
};

export function ruleLabel(rule: string): string {
  return RULE_LABELS[rule] ?? rule.replace(/_/g, ' ').toLowerCase().replace(/^\w/, (c) => c.toUpperCase());
}
