/** Pure scheduling rules (FR11, FR14, FR15). No database access, so they are cheap to unit test. */

const DAY_MS = 24 * 60 * 60 * 1000;

/** Every member pays an equal share of the pool each cycle. */
export function contributionAmount(chitValue: number, numberOfMembers: number): number {
  return Math.round((chitValue / numberOfMembers) * 100) / 100;
}

export interface ScheduledCycle {
  cycleNumber: number;
  startDate: Date;
  endDate: Date;
  dueDate: Date;
}

/** FR11: one entry per cycle. Cycle n runs [start + (n-1)*d, start + n*d); contributions fall due on its first day. */
export function buildSchedule(startDate: Date, totalCycles: number, cycleDurationDays: number): ScheduledCycle[] {
  return Array.from({ length: totalCycles }, (_, i) => {
    const start = new Date(startDate.getTime() + i * cycleDurationDays * DAY_MS);
    return {
      cycleNumber: i + 1,
      startDate: start,
      endDate: new Date(start.getTime() + cycleDurationDays * DAY_MS),
      dueDate: start,
    };
  });
}

export type DueState = 'NOT_DUE' | 'REMINDER_DUE' | 'DUE' | 'LATE' | 'DELINQUENT';

/**
 * Where an unpaid contribution stands at `now`:
 *  - REMINDER_DUE  inside the reminder lead window before the due date (FR14)
 *  - LATE          past the due date but inside the grace period
 *  - DELINQUENT    past due date + grace period (FR15)
 */
export function dueState(now: Date, dueDate: Date, graceDays: number, reminderLeadDays: number): DueState {
  const t = now.getTime();
  const due = dueDate.getTime();
  if (t > due + graceDays * DAY_MS) return 'DELINQUENT';
  if (t > due) return 'LATE';
  if (t >= due - reminderLeadDays * DAY_MS) return 'REMINDER_DUE';
  return 'NOT_DUE';
}

/** Pool split when the winner takes `bidAmount`: the discount is shared equally as dividend (reverse auction). */
export function settlementSplit(chitValue: number, bidAmount: number, numberOfMembers: number) {
  const discount = Math.max(0, chitValue - bidAmount);
  return { discount, dividendPerMember: Math.round((discount / numberOfMembers) * 100) / 100 };
}
