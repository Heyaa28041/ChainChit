import { sql } from 'drizzle-orm';
import { db } from '@/lib/db';

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

/** Next human-readable ID (M1001, G001). Caller must be inside a transaction; an advisory lock serialises allocation. */
export async function nextMemberCode(tx: Tx): Promise<string> {
  await tx.execute(sql`select pg_advisory_xact_lock(727002)`);
  const r: any = await tx.execute(sql`select coalesce(max(substring(member_code from 2)::int), 1000) + 1 as n from users where member_code ~ '^M[0-9]+$'`);
  return `M${(r.rows ?? r)[0].n}`;
}

export async function nextGroupCode(tx: Tx): Promise<string> {
  await tx.execute(sql`select pg_advisory_xact_lock(727003)`);
  const r: any = await tx.execute(sql`select coalesce(max(substring(code from 2)::int), 0) + 1 as n from chit_groups where code ~ '^G[0-9]+$'`);
  return `G${String((r.rows ?? r)[0].n).padStart(3, '0')}`;
}
