import { db } from '@/lib/db';
import { cycles, chitGroups, groupMembers, contributions, users } from '@/lib/db/schema';
import { and, eq } from 'drizzle-orm';
import { logAuditEvent } from '@/lib/audit-logger';
import { contributionAmount } from '@/lib/schedule';
import crypto from 'crypto';

export type ContributionResult =
  | { ok: true; contribution: typeof contributions.$inferSelect }
  | { ok: false; status: number; code: string; error: string };

const fail = (status: number, code: string, error: string): ContributionResult => ({ ok: false, status, code, error });

/**
 * FR12 / FR13: record a member's monthly contribution and lock it in escrow.
 * Payment is simulated (out of scope: real gateways). `simulateDecline` stands in for a failed payment.
 */
export async function makeContribution(
  member: { id: string; role: string },
  input: { cycleId: string; amount?: number; mode?: string; simulateDecline?: boolean },
): Promise<ContributionResult> {
  return db.transaction(async (tx) => {
    const [cycle] = await tx.select().from(cycles).where(eq(cycles.id, input.cycleId)).limit(1);
    if (!cycle) return fail(404, 'NOT_FOUND', 'Cycle not found');
    if (cycle.status === 'SETTLED') return fail(409, 'CYCLE_SETTLED', 'This cycle is already settled');

    const [user] = await tx.select().from(users).where(eq(users.id, member.id)).limit(1);
    if (user.kycStatus !== 'VERIFIED') return fail(403, 'KYC_NOT_VERIFIED', 'KYC not verified');

    const [enrolled] = await tx.select().from(groupMembers)
      .where(and(eq(groupMembers.groupId, cycle.groupId), eq(groupMembers.memberId, member.id))).limit(1);
    if (!enrolled) return fail(403, 'NOT_ENROLLED', 'Member is not enrolled in this chit group');

    const [group] = await tx.select().from(chitGroups).where(eq(chitGroups.id, cycle.groupId)).limit(1);
    const [already] = await tx.select({ id: contributions.id }).from(contributions)
      .where(and(eq(contributions.cycleId, cycle.id), eq(contributions.memberId, member.id), eq(contributions.status, 'CONFIRMED'))).limit(1);
    if (already) return fail(409, 'ALREADY_PAID', 'You have already contributed for this cycle');

    const due = contributionAmount(group.chitValue, group.numberOfMembers);
    if (input.amount != null && Math.abs(input.amount - due) > 0.005) {
      return fail(400, 'AMOUNT_MISMATCH', `The contribution for this group is ₹${due.toLocaleString('en-IN')}`);
    }

    const mode = input.mode || 'UPI';

    if (input.simulateDecline) {
      // FT-23: no escrow lock and no ledger entry. The attempt is kept off-ledger for the member's history.
      const [declined] = await tx.insert(contributions).values({
        cycleId: cycle.id, memberId: member.id, amount: due, paymentMode: mode, status: 'DECLINED', escrowStatus: 'NONE',
      }).returning();
      return { ...fail(402, 'PAYMENT_DECLINED', 'Payment failed. No funds were locked; please try again.'), contribution: declined } as ContributionResult;
    }

    const paymentRef = `PAY-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
    const [row] = await tx.insert(contributions).values({
      cycleId: cycle.id, memberId: member.id, amount: due, paymentMode: mode, status: 'CONFIRMED', escrowStatus: 'LOCKED', paymentRef,
    }).returning();

    // Payment confirmed -> funds are locked in escrow in the same step (FR13).
    await logAuditEvent({
      actorId: member.id,
      actorRole: member.role,
      action: 'CONTRIBUTION_ESCROW_LOCKED',
      entityType: 'CONTRIBUTION',
      entityId: row.id,
      groupId: group.id,
      payload: { cycleId: cycle.id, cycleNumber: cycle.cycleNumber, amount: due, mode, paymentRef, escrowStatus: 'LOCKED' },
    }, tx);

    // Clear the delinquent flag once nothing overdue remains.
    if (enrolled.delinquent) {
      const overdue = await tx.select().from(cycles).where(and(eq(cycles.groupId, group.id)));
      const paid = await tx.select().from(contributions).where(and(eq(contributions.memberId, member.id), eq(contributions.status, 'CONFIRMED')));
      const paidCycles = new Set(paid.map((p) => p.cycleId));
      const grace = group.gracePeriodDays * 86400000;
      const stillLate = overdue.some((c) => c.status !== 'SETTLED' && c.dueDate && !paidCycles.has(c.id) && Date.now() > c.dueDate.getTime() + grace);
      if (!stillLate) await tx.update(groupMembers).set({ delinquent: false }).where(eq(groupMembers.id, enrolled.id));
    }
    return { ok: true, contribution: row };
  });
}
