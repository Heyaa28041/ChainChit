import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

/**
 * Key management. Production deployments supply keys through the environment;
 * for local development they are generated once and persisted under .data/keys (git-ignored).
 */
const DATA_DIR = process.env.CHAINCHIT_DATA_DIR || path.join(process.cwd(), '.data');
const KEY_DIR = path.join(DATA_DIR, 'keys');

function ensureDir(dir: string) {
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
}

function persistedSecret(name: string, bytes: number, envVar: string): Buffer {
  const fromEnv = process.env[envVar];
  if (fromEnv) {
    const buf = /^[0-9a-f]+$/i.test(fromEnv) && fromEnv.length === bytes * 2 ? Buffer.from(fromEnv, 'hex') : crypto.createHash('sha256').update(fromEnv).digest().subarray(0, bytes);
    return buf;
  }
  ensureDir(KEY_DIR);
  const file = path.join(KEY_DIR, name);
  if (fs.existsSync(file)) return Buffer.from(fs.readFileSync(file, 'utf8').trim(), 'hex');
  const fresh = crypto.randomBytes(bytes);
  try {
    fs.writeFileSync(file, fresh.toString('hex'), { mode: 0o600, flag: 'wx' });
  } catch {
    return Buffer.from(fs.readFileSync(file, 'utf8').trim(), 'hex'); // lost a race with another worker
  }
  return fresh;
}

/* ------------------------------ AES-256-GCM (NFR02) ------------------------------ */

let cachedDataKey: Buffer | null = null;
function dataKey(): Buffer {
  return (cachedDataKey ??= persistedSecret('data.key', 32, 'CHAINCHIT_DATA_KEY'));
}

export function encryptBuffer(plain: Buffer): Buffer {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', dataKey(), iv);
  const enc = Buffer.concat([cipher.update(plain), cipher.final()]);
  return Buffer.concat([Buffer.from([1]), iv, cipher.getAuthTag(), enc]); // v1 | iv | tag | ciphertext
}

export function decryptBuffer(blob: Buffer): Buffer {
  if (blob[0] !== 1) throw new Error('Unsupported encrypted blob version');
  const iv = blob.subarray(1, 13);
  const tag = blob.subarray(13, 29);
  const decipher = crypto.createDecipheriv('aes-256-gcm', dataKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(blob.subarray(29)), decipher.final()]);
}

export function encryptField(value: string): string {
  return 'enc:v1:' + encryptBuffer(Buffer.from(value, 'utf8')).toString('base64');
}

export function decryptField(value: string): string {
  if (!value.startsWith('enc:v1:')) return value; // legacy plaintext rows
  return decryptBuffer(Buffer.from(value.slice(7), 'base64')).toString('utf8');
}

export function maskGovtId(plain: string): string {
  return plain.length <= 4 ? '****' : '*'.repeat(plain.length - 4) + plain.slice(-4);
}

/* ------------------------------ Ed25519 signing ------------------------------ */

let cachedKeys: { priv: crypto.KeyObject; pub: crypto.KeyObject; keyId: string; publicPem: string } | null = null;

function signingKeys() {
  if (cachedKeys) return cachedKeys;
  let privPem = process.env.CHAINCHIT_SIGNING_KEY_PEM;
  if (!privPem) {
    ensureDir(KEY_DIR);
    const file = path.join(KEY_DIR, 'ed25519.pem');
    if (fs.existsSync(file)) {
      privPem = fs.readFileSync(file, 'utf8');
    } else {
      const { privateKey } = crypto.generateKeyPairSync('ed25519');
      privPem = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
      try {
        fs.writeFileSync(file, privPem, { mode: 0o600, flag: 'wx' });
      } catch {
        privPem = fs.readFileSync(file, 'utf8');
      }
    }
  }
  const priv = crypto.createPrivateKey(privPem);
  const pub = crypto.createPublicKey(priv);
  const publicPem = pub.export({ type: 'spki', format: 'pem' }).toString();
  const keyId = crypto.createHash('sha256').update(publicPem).digest('hex').slice(0, 16);
  return (cachedKeys = { priv, pub, keyId, publicPem });
}

export const signerKeyId = () => signingKeys().keyId;
export const publicKeyPem = () => signingKeys().publicPem;

export function signMessage(message: string | Buffer): string {
  return crypto.sign(null, Buffer.from(message), signingKeys().priv).toString('base64');
}

export function verifySignature(message: string | Buffer, signatureB64: string, publicPem?: string): boolean {
  try {
    const key = publicPem ? crypto.createPublicKey(publicPem) : signingKeys().pub;
    return crypto.verify(null, Buffer.from(message), key, Buffer.from(signatureB64, 'base64'));
  } catch {
    return false;
  }
}

/** Deterministic JSON (sorted keys) so a signature can be re-verified byte for byte. */
export function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(canonicalJson).join(',') + ']';
  const obj = value as Record<string, unknown>;
  return '{' + Object.keys(obj).sort().filter((k) => obj[k] !== undefined).map((k) => JSON.stringify(k) + ':' + canonicalJson(obj[k])).join(',') + '}';
}

export const sha256Hex = (data: string | Buffer) => crypto.createHash('sha256').update(data).digest('hex');

/* ------------------------------ Session tokens ------------------------------ */

let cachedSessionKey: Buffer | null = null;
const sessionKey = () => (cachedSessionKey ??= persistedSecret('session.key', 32, 'CHAINCHIT_SESSION_SECRET'));

const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;

/** `<userId>.<expiryMs>.<hmac>` - a bare user id in the cookie can no longer be forged. */
export function createSessionToken(userId: string): string {
  const exp = Date.now() + SESSION_TTL_MS;
  const body = `${userId}.${exp}`;
  const mac = crypto.createHmac('sha256', sessionKey()).update(body).digest('base64url');
  return `${body}.${mac}`;
}

export function readSessionToken(token: string | undefined): string | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [userId, exp, mac] = parts;
  const expected = crypto.createHmac('sha256', sessionKey()).update(`${userId}.${exp}`).digest('base64url');
  const a = Buffer.from(mac);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  if (!(Number(exp) > Date.now())) return null;
  return userId;
}

export const SESSION_MAX_AGE_SECONDS = SESSION_TTL_MS / 1000;
