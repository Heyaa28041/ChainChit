import { db } from '@/lib/db';
import { auditLogs, bids, contributions, cycles, fraudAlerts, payouts, users } from '@/lib/db/schema';
import { and, asc, eq } from 'drizzle-orm';
import { canonicalJson, sha256Hex } from './crypto';

/**
 * FR32: snapshot of everything relevant to a dispute, taken at the moment it is raised:
 * the transaction history (bids, the disputant's contributions, the payout) and the fraud-check logs.
 */
export async function buildDisputeEvidence(p: { cycleId: string; bidId?: string | null; payoutId?: string | null; raisedBy: string }) {
  const [cycle] = await db.select().from(cycles).where(eq(cycles.id, p.cycleId)).limit(1);
  const cycleBids = await db
    .select({ id: bids.id, memberId: bids.memberId, memberName: users.name, bidAmount: bids.bidAmount, timestamp: bids.timestamp, status: bids.status, zScore: bids.zScore, isAnomaly: bids.isAnomaly, fraudReason: bids.fraudReason })
    .from(bids).innerJoin(users, eq(bids.memberId, users.id)).where(eq(bids.cycleId, p.cycleId)).orderBy(asc(bids.bidAmount), asc(bids.timestamp));
  const alerts = await db.select().from(fraudAlerts).where(eq(fraudAlerts.cycleId, p.cycleId));
  const myContributions = await db.select().from(contributions).where(and(eq(contributions.cycleId, p.cycleId), eq(contributions.memberId, p.raisedBy)));
  const [payout] = await db.select().from(payouts).where(eq(payouts.cycleId, p.cycleId)).limit(1);

  const ids = new Set([p.cycleId, p.bidId, p.payoutId, payout?.id, ...cycleBids.map((b) => b.id), ...alerts.map((a) => a.id)].filter(Boolean) as string[]);
  const ledger = (await db.select().from(auditLogs).where(eq(auditLogs.groupId, cycle.groupId)).orderBy(asc(auditLogs.sequence)))
    .filter((l) => ids.has(l.entityId) || ids.has(JSON.parse(l.payloadJson)?.cycleId))
    .map((l) => ({ sequence: l.sequence, timestamp: l.timestamp, action: l.action, entityType: l.entityType, entityId: l.entityId, actorRole: l.actorRole, payload: JSON.parse(l.payloadJson), entryHash: l.entryHash }));

  const evidence = {
    capturedAt: new Date().toISOString(),
    cycle: { id: cycle.id, number: cycle.cycleNumber, status: cycle.status, winnerMemberId: cycle.winnerMemberId, payoutAmount: cycle.payoutAmount, escrowStatus: cycle.escrowStatus, settledAt: cycle.settledAt },
    transactionHistory: { bids: cycleBids, disputantContributions: myContributions, payout: payout ? { id: payout.id, amount: payout.amount, receiptId: payout.receiptId, payoutDate: payout.payoutDate, signature: payout.signature } : null },
    fraudCheckLogs: { alerts, bidZScores: cycleBids.map((b) => ({ bidId: b.id, zScore: b.zScore, isAnomaly: b.isAnomaly, status: b.status, reason: b.fraudReason })) },
    ledgerEntries: ledger,
  };
  return { evidence, json: JSON.stringify(evidence), sha256: sha256Hex(canonicalJson(evidence)) };
}
