import { db } from '@/lib/db';
import { auditLogs, users, chitGroups } from '@/lib/db/schema';
import { asc, eq } from 'drizzle-orm';
import { sha256Hex, signMessage, signerKeyId, publicKeyPem, verifySignature } from './crypto';
import { buildPdf } from './pdf';
import { verifyAuditChainIntegrity } from '@/lib/audit-logger';

export const CSV_COLUMNS = [
  'Sequence', 'Timestamp', 'ActorId', 'ActorName', 'ActorRole', 'Action', 'EntityType', 'EntityId', 'GroupId', 'Payload', 'PreviousHash', 'EntryHash', 'EntrySignature',
] as const;

const csvCell = (v: unknown) => {
  let s = v == null ? '' : String(v);
  // Neutralise spreadsheet formula injection from user-controlled text.
  if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s)) s = "'" + s;
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export async function collectLedger(groupId?: string) {
  const rows = await db
    .select({ log: auditLogs, actorName: users.name })
    .from(auditLogs)
    .leftJoin(users, eq(auditLogs.actorId, users.id))
    .orderBy(asc(auditLogs.sequence));
  return rows.filter((r) => !groupId || r.log.groupId === groupId);
}

export interface SignedExport {
  body: Buffer;
  contentType: string;
  filename: string;
  sha256: string;
  signature: string;
}

function attestation(body: string, meta: { scope: string; exportedBy: string; exportedAt: string; entries: number; chainValid: boolean }) {
  const digest = sha256Hex(body);
  const signature = signMessage(digest);
  return { digest, signature, lines: [
    `# scope=${meta.scope}`,
    `# entries=${meta.entries}`,
    `# exported_by=${meta.exportedBy}`,
    `# exported_at=${meta.exportedAt}`,
    `# ledger_chain_valid=${meta.chainValid}`,
    `# body_sha256=${digest}`,
    `# signature_ed25519=${signature}`,
    `# signer_key_id=${signerKeyId()}`,
  ] };
}

/** FR34 / NFR15: signed CSV (or PDF) of a group's ledger, or of the whole ledger when groupId is omitted. */
export async function buildSignedExport(opts: { groupId?: string; format: 'csv' | 'pdf'; exportedBy: string }): Promise<SignedExport> {
  const [group] = opts.groupId ? await db.select().from(chitGroups).where(eq(chitGroups.id, opts.groupId)).limit(1) : [];
  const scope = group ? `${group.code} ${group.name}` : 'ALL GROUPS';
  const rows = await collectLedger(opts.groupId);
  const integrity = await verifyAuditChainIntegrity();
  const exportedAt = new Date().toISOString();
  const stem = `chainchit_${group?.code ?? 'ledger'}_${exportedAt.slice(0, 10)}`;

  if (opts.format === 'csv') {
    const body = [
      CSV_COLUMNS.join(','),
      ...rows.map(({ log, actorName }) => [
        log.sequence, log.timestamp.toISOString(), log.actorId, actorName ?? (log.actorRole === 'SYSTEM' ? 'System' : ''), log.actorRole,
        log.action, log.entityType, log.entityId, log.groupId, log.payloadJson, log.previousHash, log.entryHash, log.signature,
      ].map(csvCell).join(',')),
    ].join('\r\n') + '\r\n';
    const att = attestation(body, { scope, exportedBy: opts.exportedBy, exportedAt, entries: rows.length, chainValid: integrity.valid });
    return {
      body: Buffer.from('﻿' + body + att.lines.join('\r\n') + '\r\n', 'utf8'), // BOM so Excel reads ₹ and names correctly
      contentType: 'text/csv; charset=utf-8', filename: `${stem}.csv`, sha256: att.digest, signature: att.signature,
    };
  }

  const bodyLines = [
    'CHAINCHIT - SIGNED TRANSACTION LOG',
    `Scope: ${scope}`,
    ...(group ? [`Chit value: Rs. ${group.chitValue.toLocaleString('en-IN')}   Members: ${group.numberOfMembers}   Cycles: ${group.totalCycles}   Status: ${group.status}`] : []),
    `Exported by: ${opts.exportedBy}`,
    `Exported at: ${exportedAt}`,
    `Entries: ${rows.length}`,
    `Ledger chain: ${integrity.valid ? 'VERIFIED' : 'BROKEN - ' + integrity.message}`,
    '='.repeat(118),
    ...rows.flatMap(({ log, actorName }) => [
      `#${log.sequence}  ${log.timestamp.toISOString()}  ${log.action}  [${log.actorRole}${actorName ? ' ' + actorName : ''}]`,
      `    ${log.entityType} ${log.entityId}`,
      `    ${log.payloadJson}`,
      `    hash ${log.entryHash}`,
      '',
    ]),
  ];
  const body = bodyLines.join('\n');
  const att = attestation(body, { scope, exportedBy: opts.exportedBy, exportedAt, entries: rows.length, chainValid: integrity.valid });
  const pdf = buildPdf(`ChainChit signed transaction log - ${scope}`, [...bodyLines, '='.repeat(118), 'CRYPTOGRAPHIC ATTESTATION (Ed25519 over the SHA-256 of the log text above)', ...att.lines.map((l) => l.replace(/^# /, ''))]);
  return { body: pdf, contentType: 'application/pdf', filename: `${stem}.pdf`, sha256: att.digest, signature: att.signature };
}

/** Re-verifies a CSV produced by buildSignedExport (body digest + signature). */
export function verifySignedCsv(csv: string, publicPem?: string) {
  const text = csv.replace(/^﻿/, '');
  const idx = text.lastIndexOf('# scope=');
  if (idx < 0) return { valid: false, reason: 'No attestation block found' };
  const body = text.slice(0, idx);
  const attLines = Object.fromEntries(text.slice(idx).split(/\r?\n/).filter((l) => l.startsWith('# ')).map((l) => { const [k, ...v] = l.slice(2).split('='); return [k, v.join('=')]; }));
  const digest = sha256Hex(body);
  if (digest !== attLines.body_sha256) return { valid: false, reason: 'Content has been modified: digest mismatch', digest };
  if (!verifySignature(digest, attLines.signature_ed25519 ?? '', publicPem)) return { valid: false, reason: 'Signature does not verify', digest };
  return { valid: true, digest, signerKeyId: attLines.signer_key_id, entries: Number(attLines.entries), publicKeyPem: publicKeyPem() };
}
