import path from 'path';
export const KYC_DIR = path.join(process.env.CHAINCHIT_DATA_DIR || path.join(process.cwd(), '.data'), 'kyc');
