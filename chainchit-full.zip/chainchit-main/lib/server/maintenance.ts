import { db } from '@/lib/db';
import { cycles, maintenanceWindows } from '@/lib/db/schema';
import { and, eq, gt, lt } from 'drizzle-orm';

/** NFR12: is any bidding window (open now, or scheduled to be open) overlapping [start, end]? */
export async function activeBiddingOverlap(start: Date, end: Date) {
  const rows = await db.select().from(cycles).where(eq(cycles.status, 'BIDDING_OPEN'));
  return rows.filter((c) => {
    const s = c.biddingStartTime?.getTime() ?? 0;
    const e = c.biddingEndTime?.getTime() ?? Number.MAX_SAFE_INTEGER;
    return s < end.getTime() && e > start.getTime();
  });
}

/** Bidding may not open inside a maintenance window. */
export async function maintenanceOverlap(start: Date, end: Date) {
  return db.select().from(maintenanceWindows).where(and(lt(maintenanceWindows.startsAt, end), gt(maintenanceWindows.endsAt, start)));
}
