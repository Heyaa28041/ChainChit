import { db } from '@/lib/db';
import { notifications, users, chitGroups } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { sseBroker } from '@/lib/sse-broker';

export interface NotifyInput {
  userId: string;
  type: string;
  message: string;
  entityType?: string;
  entityId?: string;
  /** When set, the same (user, key) is only ever delivered once. */
  dedupeKey?: string;
}

/** Inserts a notification; returns false when it was a duplicate. */
export async function notify(n: NotifyInput): Promise<boolean> {
  const rows = await db
    .insert(notifications)
    .values({ userId: n.userId, type: n.type, message: n.message, entityType: n.entityType, entityId: n.entityId, dedupeKey: n.dedupeKey })
    .onConflictDoNothing()
    .returning();
  if (rows[0]) sseBroker.broadcast(`user:${n.userId}`, 'NOTIFICATION', rows[0]);
  return rows.length > 0;
}

export async function notifyMany(userIds: string[], n: Omit<NotifyInput, 'userId'>) {
  const unique = [...new Set(userIds)];
  let delivered = 0;
  for (const userId of unique) if (await notify({ ...n, userId })) delivered++;
  return delivered;
}

export async function oversightViewerIds(): Promise<string[]> {
  const rows = await db.select({ id: users.id }).from(users).where(eq(users.role, 'OVERSIGHT_VIEWER'));
  return rows.map((r) => r.id);
}

/** FR26: tell the group's foreman and every oversight viewer immediately. */
export async function notifyFraudFlag(p: {
  groupId: string; cycleId: string; bidId: string; memberName: string; amount: number; rule?: string; details: string;
}) {
  const [group] = await db.select({ foremanId: chitGroups.foremanId, code: chitGroups.code }).from(chitGroups).where(eq(chitGroups.id, p.groupId)).limit(1);
  const recipients = [...(group ? [group.foremanId] : []), ...(await oversightViewerIds())];
  return notifyMany(recipients, {
    type: 'FRAUD_FLAG',
    message: `Bid flagged in ${group?.code ?? 'group'}: ${p.memberName} bid ₹${p.amount.toLocaleString('en-IN')}. ${p.details}`,
    entityType: 'BID',
    entityId: p.bidId,
    dedupeKey: `fraud:${p.bidId}`,
  });
}
