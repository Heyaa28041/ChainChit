/**
 * Minimal dependency-free PDF writer: A4 pages of monospaced text (Courier), valid xref table.
 * Enough for audit exports that open in any reader (NFR15); not a general layout engine.
 */
const PAGE_W = 595;
const PAGE_H = 842;
const MARGIN = 40;
const FONT = 7.5;
const LEAD = 10;
const CHAR_W = 0.6 * FONT; // Courier is 0.6em wide
export const PDF_COLS = Math.floor((PAGE_W - 2 * MARGIN) / CHAR_W);

/** Standard fonts only cover Latin-1; map what we expect and replace the rest. */
function latin1(s: string): string {
  return s
    .replace(/₹/g, 'Rs.')
    .replace(/[–—]/g, '-')
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/σ/g, 'sd')
    .replace(/[^\x09\x20-\x7e\xa0-\xff]/g, '?');
}

const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');

export function wrapLine(line: string, width = PDF_COLS): string[] {
  const out: string[] = [];
  let rest = latin1(line);
  while (rest.length > width) {
    out.push(rest.slice(0, width));
    rest = '  ' + rest.slice(width);
  }
  out.push(rest);
  return out;
}

export function buildPdf(title: string, lines: string[]): Buffer {
  const wrapped = lines.flatMap((l) => wrapLine(l));
  const perPage = Math.floor((PAGE_H - 2 * MARGIN) / LEAD);
  const pages: string[][] = [];
  for (let i = 0; i < wrapped.length; i += perPage) pages.push(wrapped.slice(i, i + perPage));
  if (pages.length === 0) pages.push([]);

  const objects: string[] = [];
  // 1 catalog, 2 pages, 3 font, then (page, content) pairs; 4 = info
  const pageObjNums = pages.map((_, i) => 5 + i * 2);
  objects[1] = `<< /Type /Catalog /Pages 2 0 R >>`;
  objects[2] = `<< /Type /Pages /Kids [${pageObjNums.map((n) => `${n} 0 R`).join(' ')}] /Count ${pages.length} >>`;
  objects[3] = `<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>`;
  objects[4] = `<< /Title (${esc(latin1(title))}) /Producer (ChainChit) >>`;
  pages.forEach((pageLines, i) => {
    const pageNo = 5 + i * 2;
    const footer = `Page ${i + 1} of ${pages.length}`;
    const body = [
      'BT', `/F1 ${FONT} Tf`, `${LEAD} TL`, `${MARGIN} ${PAGE_H - MARGIN} Td`,
      ...pageLines.map((l) => `(${esc(l)}) '`),
      'ET',
      'BT', `/F1 ${FONT} Tf`, `${MARGIN} ${MARGIN / 2} Td`, `(${esc(footer)}) Tj`, 'ET',
    ].join('\n');
    objects[pageNo] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 3 0 R >> >> /Contents ${pageNo + 1} 0 R >>`;
    objects[pageNo + 1] = `<< /Length ${Buffer.byteLength(body, 'latin1')} >>\nstream\n${body}\nendstream`;
  });

  let out = '%PDF-1.4\n%\xe2\xe3\xcf\xd3\n';
  const offsets: number[] = [];
  const total = objects.length;
  for (let n = 1; n < total; n++) {
    offsets[n] = Buffer.byteLength(out, 'latin1');
    out += `${n} 0 obj\n${objects[n]}\nendobj\n`;
  }
  const xref = Buffer.byteLength(out, 'latin1');
  out += `xref\n0 ${total}\n0000000000 65535 f \n`;
  for (let n = 1; n < total; n++) out += `${String(offsets[n]).padStart(10, '0')} 00000 n \n`;
  out += `trailer\n<< /Size ${total} /Root 1 0 R /Info 4 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(out, 'latin1');
}
