import { db } from '@/lib/db';
import { cycles, chitGroups, groupMembers, contributions, users } from '@/lib/db/schema';
import { and, eq, ne } from 'drizzle-orm';
import { dueState, contributionAmount } from '@/lib/schedule';
import { notify } from './notify';
import { logAuditEvent } from '@/lib/audit-logger';

export interface SweepReport {
  at: string;
  reminders: number;
  delinquent: number;
  cyclesChecked: number;
}

/**
 * FR14 + FR15. Idempotent: reminders are de-duplicated per (member, cycle) and a member is only
 * flagged (and the ledger written) the first time they cross the grace period.
 * `asOf` lets tests and demos advance the clock (FT-24, FT-25).
 */
export async function runSweep(asOf: Date = new Date()): Promise<SweepReport> {
  const open = await db
    .select({ cycle: cycles, group: chitGroups })
    .from(cycles)
    .innerJoin(chitGroups, eq(cycles.groupId, chitGroups.id))
    .where(and(ne(cycles.status, 'SETTLED'), eq(chitGroups.status, 'ACTIVE')));

  let reminders = 0;
  let delinquent = 0;

  for (const { cycle, group } of open) {
    if (!cycle.dueDate) continue;
    const roster = await db
      .select({ gm: groupMembers, user: users })
      .from(groupMembers)
      .innerJoin(users, eq(groupMembers.memberId, users.id))
      .where(eq(groupMembers.groupId, group.id));
    const paid = await db
      .select({ memberId: contributions.memberId })
      .from(contributions)
      .where(and(eq(contributions.cycleId, cycle.id), eq(contributions.status, 'CONFIRMED')));
    const paidSet = new Set(paid.map((p) => p.memberId));
    const amount = contributionAmount(group.chitValue, group.numberOfMembers);

    for (const { gm, user } of roster) {
      if (paidSet.has(user.id)) continue;
      const state = dueState(asOf, cycle.dueDate, group.gracePeriodDays, group.reminderLeadDays);

      if (state === 'REMINDER_DUE' || state === 'LATE') {
        const late = state === 'LATE';
        const sent = await notify({
          userId: user.id,
          type: late ? 'CONTRIBUTION_LATE' : 'CONTRIBUTION_REMINDER',
          message: late
            ? `Your ₹${amount.toLocaleString('en-IN')} contribution for ${group.code} cycle ${cycle.cycleNumber} is overdue. Pay within the grace period to avoid being flagged.`
            : `Reminder: your ₹${amount.toLocaleString('en-IN')} contribution for ${group.code} cycle ${cycle.cycleNumber} is due on ${cycle.dueDate.toISOString().slice(0, 10)}.`,
          entityType: 'CYCLE',
          entityId: cycle.id,
          dedupeKey: `${late ? 'late' : 'rem'}:${cycle.id}`,
        });
        if (sent) reminders++;
      }

      if (state === 'DELINQUENT') {
        if (!gm.delinquent) {
          await db.update(groupMembers).set({ delinquent: true }).where(eq(groupMembers.id, gm.id));
          await logAuditEvent({
            actorRole: 'SYSTEM',
            action: 'MEMBER_FLAGGED_DELINQUENT',
            entityType: 'USER',
            entityId: user.id,
            groupId: group.id,
            payload: { cycleId: cycle.id, cycleNumber: cycle.cycleNumber, dueDate: cycle.dueDate.toISOString(), graceDays: group.gracePeriodDays, asOf: asOf.toISOString() },
          });
          delinquent++;
        }
        await notify({
          userId: user.id, type: 'PAYMENT_DELINQUENT',
          message: `Your account is flagged: the contribution for ${group.code} cycle ${cycle.cycleNumber} is past the ${group.gracePeriodDays}-day grace period.`,
          entityType: 'CYCLE', entityId: cycle.id, dedupeKey: `delinq:${cycle.id}`,
        });
        await notify({
          userId: group.foremanId, type: 'MEMBER_DELINQUENT',
          message: `${user.name} (${user.memberCode ?? 'member'}) missed the ${group.code} cycle ${cycle.cycleNumber} payment and is past the grace period.`,
          entityType: 'USER', entityId: user.id, dedupeKey: `delinq:${cycle.id}:${user.id}`,
        });
      }
    }
  }
  return { at: asOf.toISOString(), reminders, delinquent, cyclesChecked: open.length };
}

let lastSweep = 0;
/** Cheap opportunistic trigger so dashboards stay fresh without an external cron. */
export async function maybeSweep(minIntervalMs = 60_000) {
  if (Date.now() - lastSweep < minIntervalMs) return;
  lastSweep = Date.now();
  try { await runSweep(); } catch (e) { console.error('sweep failed', e); }
}
