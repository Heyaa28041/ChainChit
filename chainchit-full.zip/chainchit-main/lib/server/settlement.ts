import { db } from '@/lib/db';
import { cycles, chitGroups, bids, fraudAlerts, contributions, payouts, users, groupMembers } from '@/lib/db/schema';
import { and, eq, sql } from 'drizzle-orm';
import crypto from 'crypto';
import { logAuditEvent } from '@/lib/audit-logger';
import { canonicalJson, signMessage, signerKeyId, publicKeyPem, verifySignature } from './crypto';
import { settlementSplit } from '@/lib/schedule';
import { updateTrustScores } from '@/lib/fraud-detector';
import { notify } from './notify';
import { sseBroker } from '@/lib/sse-broker';

export type SettleResult =
  | { ok: true; payout: typeof payouts.$inferSelect; receipt: Receipt }
  | { ok: false; status: number; code: string; error: string };

export interface Receipt {
  receiptId: string;
  groupCode: string | null;
  groupName: string;
  cycleNumber: number;
  winnerId: string;
  winnerCode: string | null;
  winnerName: string;
  payoutAmount: number;
  chitValue: number;
  dividendPerMember: number;
  escrowReleased: number;
  contributionsReleased: number;
  issuedAt: string;
}

const fail = (status: number, code: string, error: string): SettleResult => ({ ok: false, status, code, error });

/**
 * The payout "contract" (FR16, FR27-FR30). The only code path that releases escrow.
 * Everything happens in one transaction holding a row lock on the cycle, so two simultaneous
 * settle calls cannot both pay out; the unique(cycle_id) on payouts is the backstop.
 */
export async function settleCycle(cycleId: string, actor: { id: string; role: string }): Promise<SettleResult> {
  const result = await db.transaction(async (tx): Promise<SettleResult & { notifyWinner?: string; groupId?: string }> => {
    const [cycle] = await tx.select().from(cycles).where(eq(cycles.id, cycleId)).for('update').limit(1);
    if (!cycle) return fail(404, 'NOT_FOUND', 'Cycle not found');

    // FR30 / FT-44
    const [existing] = await tx.select({ id: payouts.id }).from(payouts).where(eq(payouts.cycleId, cycleId)).limit(1);
    if (existing || cycle.status === 'SETTLED' || cycle.escrowStatus === 'RELEASED') {
      return fail(409, 'ALREADY_SETTLED', 'Cycle already settled');
    }
    if (!cycle.winningBidId || !cycle.winnerMemberId || cycle.payoutAmount == null) {
      return fail(400, 'NO_WINNER', 'Cannot settle cycle before a valid winner has been determined');
    }
    if (cycle.status !== 'BIDDING_CLOSED') {
      return fail(409, 'CYCLE_NOT_CLOSED', `Cycle is ${cycle.status}; bidding must be closed before settlement`);
    }

    // FR27 / FT-40: the winning bid must have cleared every fraud check.
    const [winningBid] = await tx.select().from(bids).where(eq(bids.id, cycle.winningBidId)).limit(1);
    if (!winningBid || winningBid.status === 'FLAGGED_SUSPICIOUS' || winningBid.status === 'REJECTED') {
      return fail(403, 'PAYOUT_BLOCKED_FRAUD', 'Payout blocked: winning bid is flagged as suspicious. Requires foreman review and clearance.');
    }
    const open = await tx.select({ id: fraudAlerts.id }).from(fraudAlerts)
      .where(and(eq(fraudAlerts.cycleId, cycleId), eq(fraudAlerts.resolved, false)));
    if (open.length > 0) {
      return fail(403, 'PAYOUT_BLOCKED_UNRESOLVED_ALERT', 'Payout blocked: resolve the open fraud alerts for this cycle first.');
    }
    if (cycle.escrowStatus === 'HELD_FOR_REVIEW') {
      return fail(403, 'PAYOUT_BLOCKED_HELD', 'Payout blocked: escrow is held for review.');
    }

    const [group] = await tx.select().from(chitGroups).where(eq(chitGroups.id, cycle.groupId)).limit(1);
    const [winner] = await tx.select().from(users).where(eq(users.id, cycle.winnerMemberId)).limit(1);

    // The escrow must actually hold the money being paid out.
    const locked = await tx.select().from(contributions)
      .where(and(eq(contributions.cycleId, cycleId), eq(contributions.status, 'CONFIRMED'), eq(contributions.escrowStatus, 'LOCKED')));
    const escrowTotal = locked.reduce((a, c) => a + c.amount, 0);
    if (escrowTotal + 0.005 < cycle.payoutAmount) {
      return fail(409, 'INSUFFICIENT_ESCROW', `Escrow holds ₹${escrowTotal.toLocaleString('en-IN')} but the payout is ₹${cycle.payoutAmount.toLocaleString('en-IN')}. Collect outstanding contributions first.`);
    }

    // Open the payout gate for this transaction only (see lib/db/triggers.sql).
    await tx.execute(sql`select set_config('chainchit.payout', 'on', true)`);
    await tx.update(contributions).set({ escrowStatus: 'RELEASED' })
      .where(and(eq(contributions.cycleId, cycleId), eq(contributions.escrowStatus, 'LOCKED')));

    const issuedAt = new Date();
    const split = settlementSplit(group.chitValue, cycle.payoutAmount, group.numberOfMembers);
    const receiptId = `RCP-${group.code ?? 'G'}-C${cycle.cycleNumber}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const receipt: Receipt = {
      receiptId,
      groupCode: group.code,
      groupName: group.name,
      cycleNumber: cycle.cycleNumber,
      winnerId: winner.id,
      winnerCode: winner.memberCode,
      winnerName: winner.name,
      payoutAmount: cycle.payoutAmount,
      chitValue: group.chitValue,
      dividendPerMember: split.dividendPerMember,
      escrowReleased: escrowTotal,
      contributionsReleased: locked.length,
      issuedAt: issuedAt.toISOString(),
    };
    const receiptJson = canonicalJson(receipt);

    const [payout] = await tx.insert(payouts).values({
      cycleId,
      winnerId: winner.id,
      amount: cycle.payoutAmount,
      dividendPerMember: split.dividendPerMember,
      receiptId,
      receiptJson,
      signature: signMessage(receiptJson),
      signerKeyId: signerKeyId(),
      payoutDate: issuedAt,
    }).returning();

    await tx.update(cycles).set({ status: 'SETTLED', escrowStatus: 'RELEASED', settledAt: issuedAt }).where(eq(cycles.id, cycleId));

    // FR29: the cycle ledger gets its entry in the same transaction as the payout.
    await logAuditEvent({
      actorId: actor.id,
      actorRole: actor.role,
      action: 'PAYOUT_RELEASED',
      entityType: 'PAYOUT',
      entityId: payout.id,
      groupId: group.id,
      payload: { cycleId, cycleNumber: cycle.cycleNumber, winnerMemberId: winner.id, payoutAmount: cycle.payoutAmount, receiptId, escrowReleased: escrowTotal, dividendPerMember: split.dividendPerMember },
    }, tx);

    // Group completes once every scheduled cycle has settled.
    const remaining = await tx.select({ id: cycles.id }).from(cycles)
      .where(and(eq(cycles.groupId, group.id), sql`${cycles.status} <> 'SETTLED'`));
    if (remaining.length === 0) {
      await tx.update(chitGroups).set({ status: 'COMPLETED' }).where(eq(chitGroups.id, group.id));
      await logAuditEvent({ actorId: actor.id, actorRole: actor.role, action: 'GROUP_COMPLETED', entityType: 'CHIT_GROUP', entityId: group.id, groupId: group.id, payload: { code: group.code } }, tx);
    }

    return { ok: true, payout, receipt, notifyWinner: winner.id, groupId: group.id };
  });

  if (result.ok) {
    await updateTrustScores(cycleId); // FR25: end of cycle
    await notify({
      userId: result.receipt.winnerId,
      type: 'PAYOUT_RELEASED',
      message: `Payout of ₹${result.receipt.payoutAmount.toLocaleString('en-IN')} for ${result.receipt.groupCode} cycle ${result.receipt.cycleNumber} has been released. Receipt ${result.receipt.receiptId}.`,
      entityType: 'PAYOUT',
      entityId: result.payout.id,
      dedupeKey: `payout:${result.payout.id}`,
    });
    sseBroker.broadcast(`cycle:${cycleId}`, 'CYCLE_SETTLED', {
      cycleId, winnerMemberId: result.receipt.winnerId, payoutAmount: result.receipt.payoutAmount, receiptId: result.receipt.receiptId, settledAt: result.receipt.issuedAt,
    });
  }
  return result;
}

/** FR28: re-verify a stored receipt against the ledger key. */
export function verifyReceipt(p: { receiptJson: string; signature: string }) {
  return { valid: verifySignature(p.receiptJson, p.signature), publicKeyPem: publicKeyPem(), algorithm: 'Ed25519' };
}
