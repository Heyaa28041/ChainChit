// Shapes returned by the ChainChit API routes. Dates arrive as ISO strings over JSON.

export type Role = 'MEMBER' | 'FOREMAN' | 'OVERSIGHT_VIEWER';
export type KycStatus = 'PENDING' | 'UNDER_REVIEW' | 'VERIFIED' | 'REJECTED';
export type CycleStatus = 'SCHEDULED' | 'BIDDING_OPEN' | 'BIDDING_CLOSED' | 'SETTLED' | 'DISPUTED';
export type BidStatus = 'ACCEPTED' | 'FLAGGED_SUSPICIOUS' | 'REJECTED' | 'WINNING_BID';
export type EscrowStatus = 'LOCKED' | 'RELEASED' | 'HELD_FOR_REVIEW';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  kycStatus: KycStatus | string;
  trustScore: number;
  memberCode?: string | null;
}

/** One row of GET /api/cycles */
export interface CycleSummary {
  id: string;
  cycleNumber: number;
  status: CycleStatus;
  biddingStartTime: string | null;
  biddingEndTime: string | null;
  biddingDurationSeconds: number;
  payoutAmount: number | null;
  escrowStatus: EscrowStatus;
  winnerMemberId: string | null;
  winnerName: string | null;
  groupName: string;
  chitValue: number;
  groupId: string;
  createdAt: string;
}

export interface CyclesResponse {
  cycles: CycleSummary[];
  activeCycles: CycleSummary[];
  activeCycleId: string | null;
}

export interface ChitGroup {
  id: string;
  name: string;
  chitValue: number;
  numberOfMembers: number;
  cycleDurationDays: number;
  foremanId: string;
  historicalMeanBid: number;
  historicalSdBid: number;
  fraudThresholdZ: number;
  createdAt: string;
  enrolledCount?: number;
}

export interface Cycle {
  id: string;
  groupId: string;
  cycleNumber: number;
  status: CycleStatus;
  biddingStartTime: string | null;
  biddingEndTime: string | null;
  biddingDurationSeconds: number;
  winningBidId: string | null;
  winnerMemberId: string | null;
  payoutAmount: number | null;
  escrowStatus: EscrowStatus;
  settledAt: string | null;
  createdAt: string;
  secondsRemaining: number;
}

export interface Bid {
  id: string;
  memberId: string;
  memberName: string;
  bidAmount: number;
  timestamp: string;
  status: BidStatus;
  zScore: number;
  isAnomaly: boolean;
  fraudReason: string | null;
}

export interface FraudAlert {
  id: string;
  bidId: string;
  memberId: string;
  memberName: string;
  ruleViolated: string;
  severity: string;
  details: string;
  resolved: boolean;
  resolutionAction: string | null;
  createdAt: string;
}

export interface RosterMember {
  id: string;
  name: string;
  email: string;
  kycStatus: string;
  trustScore: number;
  role: Role;
}

export interface FraudStats {
  mean: number;
  stdDev: number;
  thresholdZ: number;
  sampleSize: number;
  source: 'baseline' | 'history';
}

/** GET /api/cycles/[id] */
export interface CycleDetail {
  cycle: Cycle;
  group: ChitGroup;
  winner: { id: string; name: string; email: string } | null;
  enrolledMembers: RosterMember[];
  bids: Bid[];
  alerts: FraudAlert[];
  lowestValidBid: Bid | null;
  stats: FraudStats;
}

export interface MemberRecord {
  memberCode?: string | null;
  kycRejectionReason?: string | null;
  documents?: { id: string; docType: string; fileName: string; mimeType: string; sizeBytes: number; uploadedAt: string }[];
  id: string;
  name: string;
  email: string;
  mobile: string;
  govtId: string;
  kycStatus: KycStatus | string;
  trustScore: number;
  createdAt: string;
}

export interface AuditEntry {
  id: string;
  actorId: string | null;
  actorName: string | null;
  actorRole: string;
  action: string;
  entityType: string;
  entityId: string;
  payloadJson: string;
  previousHash: string | null;
  entryHash: string;
  timestamp: string;
}

export interface AuditIntegrity {
  valid: boolean;
  totalEntries: number;
  corruptedEntryId?: string;
  message: string;
}

export interface KycDoc { id: string; docType: string; fileName: string; mimeType: string; sizeBytes: number; uploadedAt: string }

export interface GroupRow extends ChitGroup {
  code: string | null;
  status: 'ACTIVE' | 'COMPLETED';
  totalCycles: number;
  minMembers: number;
  settledCycles: number;
  contributionAmount: number;
  gracePeriodDays: number;
  reminderLeadDays: number;
  disputeWindowDays: number;
  biddingWindowSeconds: number;
  allowRepeatWinners: boolean;
  winFreqWindow: number;
  winFreqMinWins: number;
}

export interface NotificationRow { id: string; type: string; message: string; entityType: string | null; entityId: string | null; readAt: string | null; createdAt: string }

export interface DisputeRow {
  id: string; code: string; status: 'OPEN' | 'RESOLVED' | 'REJECTED' | 'ESCALATED'; description: string; comments: string | null;
  bidId: string | null; payoutId: string | null; cycleId: string; raisedByName: string; groupCode: string | null; cycleNumber: number; createdAt: string;
}
