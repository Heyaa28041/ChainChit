/** Input rules for registration (FR01) and KYC uploads (FR02, FR03). Each returns an error message or null. */

export function validateMobile(mobile: unknown): string | null {
  const m = typeof mobile === 'string' ? mobile.trim() : '';
  if (!m) return 'Mobile number is required';
  if (!/^\d+$/.test(m) || m.length !== 10) return 'Mobile number must be exactly 10 digits';
  if (!/^[6-9]/.test(m)) return 'Mobile number must start with 6, 7, 8 or 9';
  return null;
}

export function validateEmail(email: unknown): string | null {
  const e = typeof email === 'string' ? email.trim() : '';
  if (!e) return 'Email ID is required';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return 'Enter a valid email address';
  return null;
}

export function validateRegistration(b: any): string | null {
  if (!b || typeof b !== 'object') return 'Invalid request';
  if (!b.name?.toString().trim()) return 'Name is required';
  return (
    validateEmail(b.email) ||
    validateMobile(b.mobile) ||
    (!b.govtId?.toString().trim() ? 'Government ID is required' : null) ||
    (!b.password || b.password.length < 6 ? 'Password must be at least 6 characters' : null)
  );
}

export const KYC_DOC_TYPES = ['AADHAAR', 'PAN'] as const;
export const KYC_MAX_BYTES = Number(process.env.KYC_MAX_BYTES) || 5 * 1024 * 1024; // FT-09: limit = 5 MB

/** Detects the real type from the file's magic bytes, so a renamed .exe cannot pass as a PDF. */
export function sniffKycType(buf: Buffer): { mime: string; ext: string } | null {
  if (buf.length >= 5 && buf.subarray(0, 5).toString('latin1') === '%PDF-') return { mime: 'application/pdf', ext: 'pdf' };
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: 'image/png', ext: 'png' };
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: 'image/jpeg', ext: 'jpg' };
  return null;
}

export function validateKycFile(fileName: string, buf: Buffer): { error: string; code: string } | { mime: string } {
  if (buf.length === 0) return { error: 'The file is empty', code: 'EMPTY_FILE' };
  if (buf.length > KYC_MAX_BYTES) return { error: 'File exceeds permitted size', code: 'FILE_TOO_LARGE' };
  const ext = fileName.split('.').pop()?.toLowerCase() ?? '';
  if (!['pdf', 'png', 'jpg', 'jpeg'].includes(ext)) return { error: 'Invalid file format. Upload a PDF, JPG or PNG.', code: 'INVALID_FORMAT' };
  const sniffed = sniffKycType(buf);
  if (!sniffed) return { error: 'Invalid file format. The file content is not a PDF, JPG or PNG.', code: 'INVALID_FORMAT' };
  return { mime: sniffed.mime };
}
