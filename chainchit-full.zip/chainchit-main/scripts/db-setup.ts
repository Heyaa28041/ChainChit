/**
 * Creates (or with --reset, recreates) the schema and installs the ledger / escrow triggers.
 *   npm run db:setup           apply schema + triggers
 *   npm run db:setup -- --reset  drop everything first
 */
import { Pool } from 'pg';
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

async function main() {
  const url = process.env.DATABASE_URL || 'postgresql://localhost:5432/chainchit';
  const pool = new Pool({ connectionString: url });
  if (process.argv.includes('--reset')) {
    await pool.query('DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public;');
    await pool.query('DROP SCHEMA IF EXISTS drizzle CASCADE;');
    console.log('schema reset');
  }
  execSync('npx drizzle-kit push --force', { stdio: 'inherit', env: { ...process.env, DATABASE_URL: url } });
  await pool.query(fs.readFileSync(path.join(process.cwd(), 'lib/db/triggers.sql'), 'utf8'));
  console.log('triggers installed');
  await pool.end();
}
main().catch((e) => { console.error(e); process.exit(1); });
