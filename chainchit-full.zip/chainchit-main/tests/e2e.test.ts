/**
 * End-to-end tests against a running server + Postgres (see README "Testing").
 *   BASE_URL=http://localhost:3100 DATABASE_URL=... npm run test:e2e
 * Requires a freshly reset database (npm run db:reset). Test IDs match the lab report (FT-xx / NFT-xx).
 */
import { describe, it, before } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Pool } from 'pg';

const BASE = process.env.BASE_URL || 'http://localhost:3100';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

class Client {
  cookie = '';
  async req(method: string, path: string, body?: unknown, extra: RequestInit = {}) {
    const headers: Record<string, string> = { cookie: this.cookie };
    if (body !== undefined && !(body instanceof FormData)) headers['content-type'] = 'application/json';
    const res = await fetch(BASE + path, { method, headers, body: body instanceof FormData ? body : body !== undefined ? JSON.stringify(body) : undefined, ...extra });
    const set = res.headers.get('set-cookie');
    if (set) this.cookie = set.split(',').map((c) => c.split(';')[0]).filter((c) => c.startsWith('chainchit_session=')).pop() ?? this.cookie;
    const type = res.headers.get('content-type') || '';
    const data = type.includes('json') ? await res.json() : type.includes('pdf') ? Buffer.from(await res.arrayBuffer()) : await res.text();
    return { status: res.status, data, headers: res.headers } as { status: number; data: any; headers: Headers };
  }
  get = (p: string) => this.req('GET', p);
  post = (p: string, b?: unknown) => this.req('POST', p, b ?? {});
  patch = (p: string, b: unknown) => this.req('PATCH', p, b);
  del = (p: string) => this.req('DELETE', p);
  async login(email: string, password = 'Password@123') {
    const r = await this.post('/api/auth/login', { email, password });
    assert.equal(r.status, 200, `login ${email}: ${JSON.stringify(r.data)}`);
    return r.data.user;
  }
}

const PDF = Buffer.concat([Buffer.from('%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n'), Buffer.alloc(1000)]);
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(800)]);
const upload = (c: Client, name: string, buf: Buffer, docType = 'AADHAAR') => {
  const f = new FormData();
  f.set('docType', docType);
  f.set('file', new Blob([new Uint8Array(buf)]), name);
  return c.req('POST', '/api/kyc', f);
};
const stamp = Date.now().toString(36);
const reg = (n: number, over: Record<string, unknown> = {}) => ({ name: `Member ${n}`, email: `m${n}.${stamp}@mail.com`, password: 'Secret#123', mobile: `98765${String(40000 + n).slice(-5)}`, govtId: `AADHAAR-${n}`, ...over });

const foreman = new Client();
const oversight = new Client();
const anon = new Client();
const members: Client[] = [];
const ids: string[] = [];
let groupId = '', c1 = '', c2 = '', payoutId = '', receiptId = '', alertId = '', flaggedBidId = '';

async function mkMember(n: number, verify = true) {
  const c = new Client();
  const r = await c.post('/api/auth/register', reg(n));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  members.push(c);
  ids.push(r.data.user.id);
  if (verify) {
    assert.equal((await upload(c, 'aadhaar.pdf', PDF)).status, 201);
    const a = await foreman.post('/api/foreman/kyc', { memberId: r.data.user.id, action: 'APPROVE' });
    assert.equal(a.status, 200, JSON.stringify(a.data));
  }
  return r.data.user;
}

describe('A. Registration & KYC', () => {
  before(async () => { await foreman.login('foreman@chainchit.io'); await oversight.login('oversight@chainchit.io'); });

  it('FT-01 registers with valid data and gets a unique member ID', async () => {
    const r = await anon.post('/api/auth/register', reg(900));
    assert.equal(r.status, 201);
    assert.match(r.data.user.memberCode, /^M1\d{3,}$/);
    assert.equal(r.data.user.role, 'MEMBER');
  });
  it('FT-02 rejects an invalid mobile', async () => {
    const r = await new Client().post('/api/auth/register', reg(901, { mobile: '12345' }));
    assert.equal(r.status, 400); assert.match(r.data.error, /10 digits/);
  });
  it('FT-03 rejects a mobile starting with 5', async () => {
    const r = await new Client().post('/api/auth/register', reg(902, { mobile: '5876543210' }));
    assert.equal(r.status, 400); assert.equal(r.data.error, 'Mobile number must start with 6, 7, 8 or 9');
  });
  it('FT-04 accepts a mobile starting with 6', async () => {
    assert.equal((await new Client().post('/api/auth/register', reg(903, { mobile: '6123456789' }))).status, 201);
  });
  it('FT-05 requires email', async () => {
    const r = await new Client().post('/api/auth/register', reg(904, { email: '' }));
    assert.equal(r.status, 400); assert.equal(r.data.error, 'Email ID is required');
  });
  it('NFR02 stores the government ID encrypted', async () => {
    const { rows } = await pool.query(`select govt_id from users where email=$1`, [`m900.${stamp}@mail.com`]);
    assert.match(rows[0].govt_id, /^enc:v1:/);
  });
  it('FT-06/07 accepts PDF and image KYC documents -> Under Review', async () => {
    const c = new Client(); await c.post('/api/auth/register', reg(910));
    const a = await upload(c, 'Aadhaar.pdf', PDF);
    assert.equal(a.status, 201); assert.equal(a.data.kycStatus, 'UNDER_REVIEW');
    assert.equal((await upload(c, 'PAN.jpg', Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(500)]), 'PAN')).status, 201);
    assert.equal((await upload(c, 'pan.png', PNG, 'PAN')).status, 201);
  });
  it('FT-08 rejects an .exe, and a renamed exe whose bytes are not a PDF', async () => {
    const c = new Client(); await c.post('/api/auth/register', reg(911));
    assert.equal((await upload(c, 'virus.exe', Buffer.from('MZ' + 'x'.repeat(100)))).status, 400);
    const sneaky = await upload(c, 'virus.pdf', Buffer.from('MZ' + 'x'.repeat(100)));
    assert.equal(sneaky.status, 400); assert.equal(sneaky.data.code, 'INVALID_FORMAT');
  });
  it('FT-09 rejects a file over 5 MB', async () => {
    const c = new Client(); await c.post('/api/auth/register', reg(912));
    const r = await upload(c, 'Scan.pdf', Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(5 * 1024 * 1024 + 10)]));
    assert.equal(r.status, 413); assert.match(r.data.error, /size/);
  });
  it('NFT-04 KYC file is encrypted at rest and decrypts for the foreman', async () => {
    const files = fs.readdirSync('.data/kyc');
    const raw = fs.readFileSync('.data/kyc/' + files[0]);
    assert.ok(!raw.includes(Buffer.from('%PDF')), 'plaintext PDF header found on disk');
    const list = await foreman.get('/api/foreman/kyc');
    const withDoc = list.data.members.find((m: any) => m.documents.length);
    const d = await foreman.req('GET', `/api/foreman/kyc/${withDoc.id}/documents/${withDoc.documents[0].id}`);
    assert.equal(d.status, 200);
  });
  it('FT-10/11/12 approve; reject with reason; reject without reason is blocked', async () => {
    const m1 = await mkMember(1);
    assert.equal(m1.kycStatus, 'PENDING');
    const c = new Client(); const u = (await c.post('/api/auth/register', reg(913))).data.user;
    await upload(c, 'a.pdf', PDF);
    const noReason = await foreman.post('/api/foreman/kyc', { memberId: u.id, action: 'REJECT' });
    assert.equal(noReason.status, 400); assert.equal(noReason.data.error, 'Reason is mandatory');
    const rej = await foreman.post('/api/foreman/kyc', { memberId: u.id, action: 'REJECT', rejectionReason: 'Document unclear' });
    assert.equal(rej.data.member.kycStatus, 'REJECTED'); assert.equal(rej.data.member.kycRejectionReason, 'Document unclear');
    assert.equal((await upload(c, 'again.pdf', PDF)).data.kycStatus, 'UNDER_REVIEW'); // resubmission
  });
  it('FT-13 foreman onboards one role per user', async () => {
    for (const role of ['MEMBER', 'FOREMAN', 'OVERSIGHT_VIEWER']) {
      const r = await foreman.post('/api/foreman/users', { ...reg(920 + role.length), role });
      assert.equal(r.status, 201); assert.equal(r.data.user.role, role);
    }
  });
  it('NFT-09 SQL injection in login fails', async () => {
    assert.equal((await new Client().post('/api/auth/login', { email: "' OR '1'='1", password: "' OR '1'='1" })).status, 401);
  });
  it('forged session cookies are refused', async () => {
    const c = new Client(); c.cookie = `chainchit_session=${ids[0] ?? '00000000-0000-0000-0000-000000000000'}`;
    assert.equal((await c.get('/api/dashboard')).status, 401);
  });
});

describe('B. Groups & cycles', () => {
  before(async () => { for (let n = 2; n <= 4; n++) await mkMember(n); });

  it('FT-15 rejects a group with 0 members', async () => {
    const r = await foreman.post('/api/foreman/groups', { name: 'Bad', chitValue: 100000, numberOfMembers: 0, cycleDurationDays: 30 });
    assert.equal(r.status, 400);
  });
  it('NFT-07 a member cannot create groups or see foreman data', async () => {
    assert.equal((await members[0].post('/api/foreman/groups', { name: 'x', chitValue: 1, numberOfMembers: 2 })).status, 403);
    assert.equal((await members[0].get('/api/foreman/kyc')).status, 403);
  });
  it('FT-14 / FT-20 creates group with unique ID and a full schedule', async () => {
    const r = await foreman.post('/api/foreman/groups', { name: 'Alpha Chit', chitValue: 100000, numberOfMembers: 4, minMembers: 3, cycleDurationDays: 30, totalCycles: 4 });
    assert.equal(r.status, 201); assert.match(r.data.group.code, /^G\d{3}$/);
    groupId = r.data.group.id;
    const d = await foreman.get(`/api/foreman/groups/${groupId}`);
    assert.equal(d.data.schedule.length, 4);
    assert.ok(d.data.schedule.every((c: any) => c.startDate && c.endDate && c.status === 'SCHEDULED'));
    const gen = new Date(d.data.schedule[1].startDate).getTime() - new Date(d.data.schedule[0].startDate).getTime();
    assert.equal(gen, 30 * 86400000);
    const led = await foreman.get(`/api/audit?groupId=${groupId}&action=GROUP_CREATED`);
    assert.equal(led.data.logs.length, 1); // FR08: on the ledger
  });
  it('FT-16 enrols a verified member; unverified member is refused', async () => {
    assert.equal((await foreman.post(`/api/foreman/groups/${groupId}/members`, { memberId: ids[0] })).status, 201);
    const pending = (await new Client().post('/api/auth/register', reg(930))).data.user;
    const r = await foreman.post(`/api/foreman/groups/${groupId}/members`, { memberId: pending.id });
    assert.equal(r.status, 400); assert.equal(r.data.code, 'KYC_NOT_VERIFIED');
  });
  it('FT-17 removes a member before the first cycle, and NFT-18 logs it with actor + timestamp', async () => {
    await foreman.post(`/api/foreman/groups/${groupId}/members`, { memberId: ids[1] });
    assert.equal((await foreman.del(`/api/foreman/groups/${groupId}/members?memberId=${ids[1]}`)).status, 200);
    const log = (await foreman.get(`/api/audit?groupId=${groupId}&action=MEMBER_REMOVED`)).data.logs[0];
    assert.ok(log.actorId && log.timestamp);
  });
  it('FT-19 cannot start the cycle below the minimum enrolment', async () => {
    await foreman.post(`/api/foreman/groups/${groupId}/members`, { memberId: ids[1] });
    const r = await foreman.post('/api/foreman/cycles', { groupId });
    assert.equal(r.status, 409); assert.equal(r.data.code, 'MIN_MEMBERS_NOT_MET');
  });
  it('FT-21 all roles can list active groups', async () => {
    for (const c of [members[0], foreman, oversight]) {
      const r = await c.get('/api/foreman/groups?status=ACTIVE');
      assert.ok(r.data.groups.some((g: any) => g.id === groupId));
    }
  });
  it('FR07 enrolment closes once the first cycle begins (FT-18)', async () => {
    await foreman.post(`/api/foreman/groups/${groupId}/members`, { memberId: ids[2] });
    await foreman.post(`/api/foreman/groups/${groupId}/members`, { memberId: ids[3] });
    // fraud rule set: baseline mean 85k, sd 4k, z 2.5
    const open = await foreman.post('/api/foreman/cycles', { groupId, durationSeconds: 600 });
    assert.equal(open.status, 201); c1 = open.data.cycle.id;
    assert.equal(new Date(open.data.cycle.biddingEndTime).getTime() - new Date(open.data.cycle.biddingStartTime).getTime(), 600000); // FT-27
    const late = await foreman.post(`/api/foreman/groups/${groupId}/members`, { memberId: ids[0] });
    assert.equal(late.status, 409); assert.equal(late.data.code, 'ENROLMENT_CLOSED');
    assert.equal((await foreman.del(`/api/foreman/groups/${groupId}/members?memberId=${ids[0]}`)).status, 409);
  });
});

describe('C. Contributions & escrow', () => {
  it('FT-23 declined payment: no escrow lock and no ledger entry', async () => {
    const before = (await pool.query(`select count(*)::int n from audit_logs`)).rows[0].n;
    const r = await members[0].post('/api/contributions', { cycleId: c1, amount: 25000, mode: 'UPI', simulateDecline: true });
    assert.equal(r.status, 402); assert.match(r.data.error, /Payment failed/);
    assert.equal((await pool.query(`select count(*)::int n from audit_logs`)).rows[0].n, before);
    assert.equal((await pool.query(`select count(*)::int n from contributions where escrow_status='LOCKED'`)).rows[0].n, 0);
  });
  it('FT-22 payment confirms, contribution recorded, funds locked in escrow', async () => {
    for (const m of members) {
      const r = await m.post('/api/contributions', { cycleId: c1, amount: 25000, mode: 'UPI' });
      assert.equal(r.status, 201, JSON.stringify(r.data)); assert.equal(r.data.escrowStatus, 'LOCKED');
    }
    const dup = await members[0].post('/api/contributions', { cycleId: c1 });
    assert.equal(dup.status, 409);
    const wrong = await members[1].post('/api/contributions', { cycleId: c1, amount: 1 });
    assert.equal(wrong.status, 409); // already paid takes precedence
  });
  it('FT-26 every withdrawal route is refused; the database refuses a raw UPDATE', async () => {
    const r = await foreman.post('/api/escrow/withdraw', { groupId });
    assert.equal(r.status, 403); assert.equal(r.data.code, 'ESCROW_WITHDRAWAL_FORBIDDEN');
    await assert.rejects(pool.query(`update contributions set escrow_status='RELEASED'`), /payout contract/);
    await assert.rejects(pool.query(`delete from contributions`), /cannot be deleted/);
  });
});

describe('D. Bidding & fraud detection', () => {
  it('FT-29 a verified but not-enrolled member cannot bid', async () => {
    const outsider = new Client();
    const u = (await outsider.post('/api/auth/register', reg(940))).data.user;
    await upload(outsider, 'a.pdf', PDF); await foreman.post('/api/foreman/kyc', { memberId: u.id, action: 'APPROVE' });
    const r = await outsider.post(`/api/cycles/${c1}/bid`, { bidAmount: 80000 });
    assert.equal(r.status, 403); assert.match(r.data.error, /not enrolled/);
  });
  it('FT-28 a member whose KYC is no longer verified cannot bid', async () => {
    await foreman.post('/api/foreman/kyc', { memberId: ids[3], action: 'REJECT', rejectionReason: 'Re-check required' });
    const r = await members[3].post(`/api/cycles/${c1}/bid`, { bidAmount: 80000 });
    assert.equal(r.status, 403); assert.equal(r.data.error, 'KYC not verified');
  });
  it('NFT-08 oversight cannot bid or mutate', async () => {
    assert.equal((await oversight.post(`/api/cycles/${c1}/bid`, { bidAmount: 80000 })).status, 403);
    assert.equal((await oversight.post('/api/foreman/cycles', { groupId })).status, 403);
    assert.equal((await oversight.post(`/api/cycles/${c1}/settle`)).status, 403);
  });
  it('FT-30/37 valid and within-threshold bids are recorded, not flagged', async () => {
    const a = await members[0].post(`/api/cycles/${c1}/bid`, { bidAmount: 82000 });
    assert.equal(a.status, 200); assert.equal(a.data.bid.status, 'ACCEPTED');
    const b = await members[1].post(`/api/cycles/${c1}/bid`, { bidAmount: 78000 });
    assert.equal(b.data.bid.zScore, 1.75); assert.equal(b.data.bid.isAnomaly, false);
  });
  it('FT-36 an abnormal underbid is flagged; FT-38 foreman and oversight are notified', async () => {
    const f = await members[2].post(`/api/cycles/${c1}/bid`, { bidAmount: 60000 });
    assert.equal(f.data.bid.status, 'FLAGGED_SUSPICIOUS'); assert.equal(f.data.bid.zScore, 6.25);
    flaggedBidId = f.data.bid.id; alertId = f.data.alert.id;
    for (const c of [foreman, oversight]) {
      const n = await c.get('/api/notifications');
      assert.ok(n.data.notifications.some((x: any) => x.type === 'FRAUD_FLAG' && x.entityId === flaggedBidId));
    }
  });
  it('FT-31 live bid board lists every bid', async () => {
    const d = await members[0].get(`/api/cycles/${c1}`);
    assert.equal(d.data.bids.length, 3);
  });
  it('FT-34 winner = lowest valid bid; flagged lower bid holds escrow', async () => {
    const close = await foreman.patch(`/api/foreman/cycles/${c1}`, { action: 'stop_cycle' });
    assert.equal(close.status, 200);
    const d = (await foreman.get(`/api/cycles/${c1}`)).data;
    assert.equal(d.cycle.payoutAmount, 78000); assert.equal(d.cycle.escrowStatus, 'HELD_FOR_REVIEW'); assert.equal(d.cycle.winnerMemberId, ids[1]);
    const late = await members[0].post(`/api/cycles/${c1}/bid`, { bidAmount: 70000 });
    assert.equal(late.status, 400); assert.equal(late.data.error, 'Bidding window closed'); // FT-32
  });
});

describe('E. Payout & settlement', () => {
  it('FT-40 payout is blocked while a flagged bid is unresolved', async () => {
    const r = await foreman.post(`/api/cycles/${c1}/settle`);
    assert.equal(r.status, 403); assert.match(r.data.code, /^PAYOUT_BLOCKED/);
  });
  it('FT-41 releases escrow after clearance; FT-42 receipt is signed and verifies', async () => {
    const o = await foreman.post('/api/fraud/override', { alertId, action: 'DISQUALIFIED', reason: 'Implausible underbid' });
    assert.equal(o.status, 200);
    const s = await foreman.post(`/api/cycles/${c1}/settle`);
    assert.equal(s.status, 200, JSON.stringify(s.data));
    receiptId = s.data.receiptId; payoutId = s.data.payoutId;
    assert.equal(s.data.receipt.payoutAmount, 78000); assert.equal(s.data.receipt.dividendPerMember, 5500);
    const rc = await members[1].get(`/api/receipts/${receiptId}`);
    assert.equal(rc.data.signatureValid, true);
    assert.equal((await members[2].get(`/api/receipts/${receiptId}`)).status, 403); // not the winner
    const { rows } = await pool.query(`select escrow_status, count(*)::int n from contributions where cycle_id=$1 and status='CONFIRMED' group by 1`, [c1]);
    assert.deepEqual(rows, [{ escrow_status: 'RELEASED', n: 4 }]);
  });
  it('FT-42 a modified receipt no longer verifies (independent check with the public key)', async () => {
    const rc = (await members[1].get(`/api/receipts/${receiptId}`)).data;
    const { createPublicKey, verify } = await import('node:crypto');
    const key = createPublicKey(rc.publicKeyPem);
    assert.equal(verify(null, Buffer.from(rc.signed), key, Buffer.from(rc.signature, 'base64')), true);
    assert.equal(verify(null, Buffer.from(rc.signed.replace('78000', '98000')), key, Buffer.from(rc.signature, 'base64')), false);
  });
  it('FT-43 ledger updated immediately with the payout', async () => {
    const l = await members[0].get(`/api/groups/${groupId}/ledger`);
    assert.ok(l.data.entries.some((e: any) => e.action === 'PAYOUT_RELEASED'));
    assert.equal(l.data.integrity.valid, true);
  });
  it('FT-44 a second payout for the same cycle is refused, even concurrently', async () => {
    const r = await foreman.post(`/api/cycles/${c1}/settle`);
    assert.equal(r.status, 409); assert.equal(r.data.error, 'Cycle already settled');
    await assert.rejects(pool.query(`update payouts set amount=1`), /immutable/);
  });
  it('FT-39 trust scores recalculated at cycle end (members and foreman)', async () => {
    const t = async (id: string) => (await pool.query(`select trust_score from users where id=$1`, [id])).rows[0].trust_score;
    assert.equal(await t(ids[2]), 75); // flagged bid: -25
    assert.equal(await t(ids[1]), 100);
  });
  it('FT-35 win-frequency review flags a repeat winner (FR22)', async () => {
    await foreman.patch(`/api/foreman/groups/${groupId}`, { allowRepeatWinners: true, winFreqMinWins: 1, winFreqWindow: 5 });
    const open = await foreman.post('/api/foreman/cycles', { groupId, durationSeconds: 10 });
    assert.equal(open.status, 201); c2 = open.data.cycle.id;
    const r = await members[1].post(`/api/cycles/${c2}/bid`, { bidAmount: 80000 });
    assert.equal(r.data.bid.status, 'FLAGGED_SUSPICIOUS'); assert.equal(r.data.alert.ruleViolated, 'COLLUSION_WIN_FREQUENCY');
    const dash = await oversight.get('/api/dashboard');
    assert.ok(dash.data.collusionReview.some((x: any) => x.memberId === ids[1] && x.wins === 1));
  });
  it('NFT-19 threshold change applies immediately, no redeploy', async () => {
    const before = await members[2].post(`/api/cycles/${c2}/bid`, { bidAmount: 60000 });
    assert.equal(before.data.bid.status, 'FLAGGED_SUSPICIOUS');
    await foreman.patch(`/api/foreman/groups/${groupId}`, { fraudThresholdZ: 7 });
    const after = await members[0].post(`/api/cycles/${c2}/bid`, { bidAmount: 59000 });
    assert.equal(after.data.bid.status, 'ACCEPTED', JSON.stringify(after.data));
  });
  it('NFT-12 maintenance overlapping an active bidding session is blocked', async () => {
    const now = Date.now();
    const r = await foreman.post('/api/maintenance', { startsAt: new Date(now).toISOString(), endsAt: new Date(now + 3600000).toISOString(), reason: 'Patch' });
    assert.equal(r.status, 409); assert.equal(r.data.code, 'MAINTENANCE_OVERLAPS_BIDDING');
    const fine = await foreman.post('/api/maintenance', { startsAt: new Date(now + 7200000).toISOString(), endsAt: new Date(now + 9000000).toISOString(), reason: 'Patch' });
    assert.equal(fine.status, 201);
  });
  it('FR20 the window closes by itself once the time elapses (anyone can trigger the close)', async () => {
    await new Promise((r) => setTimeout(r, 11000));
    const early = await members[0].post(`/api/cycles/${c2}/close`);
    assert.equal(early.status, 200);
    const d = (await foreman.get(`/api/cycles/${c2}`)).data;
    assert.equal(d.cycle.status, 'BIDDING_CLOSED'); assert.equal(d.cycle.payoutAmount, 59000);
  });
});

describe('F. Reminders & delinquency', () => {
  it('FT-24 reminder before the due date, de-duplicated', async () => {
    const sched = (await foreman.get(`/api/foreman/groups/${groupId}`)).data.schedule;
    const due = new Date(sched[2].dueDate); // cycle 3 is SCHEDULED, nobody has paid
    const t = new Date(due.getTime() - 2 * 86400000).toISOString();
    const a = await foreman.post('/api/maintenance/sweep', { asOf: t });
    assert.equal(a.data.report.reminders, 4);
    assert.equal((await foreman.post('/api/maintenance/sweep', { asOf: t })).data.report.reminders, 0);
    const n = await members[0].get('/api/notifications');
    assert.ok(n.data.notifications.some((x: any) => x.type === 'CONTRIBUTION_REMINDER'));
  });
  it('FT-25 member is flagged past the grace period (5 days), foreman notified', async () => {
    const sched = (await foreman.get(`/api/foreman/groups/${groupId}`)).data.schedule;
    const t = new Date(new Date(sched[2].dueDate).getTime() + 7 * 86400000).toISOString();
    const r = await foreman.post('/api/maintenance/sweep', { asOf: t });
    const roster = (await foreman.get(`/api/foreman/groups/${groupId}`)).data.roster;
    assert.ok(roster.every((m: any) => m.delinquent));
    assert.ok((await foreman.get('/api/notifications')).data.notifications.some((x: any) => x.type === 'MEMBER_DELINQUENT'));
    assert.equal((await members[0].post('/api/maintenance/sweep', {})).status, 403);
  });
});

describe('G. Disputes', () => {
  it('FT-45 raises a dispute on a payout with evidence auto-attached', async () => {
    const r = await members[0].post('/api/disputes', { payoutId, description: 'Payout seems low' });
    assert.equal(r.status, 201); assert.match(r.data.dispute.code, /^D\d{3}$/);
    const d = (await members[0].get(`/api/disputes/${r.data.dispute.id}`)).data.dispute;
    assert.ok(d.evidence.transactionHistory.bids.length >= 3);
    assert.ok(d.evidence.fraudCheckLogs.alerts.length >= 1);
    assert.ok(d.evidence.ledgerEntries.some((e: any) => e.action === 'PAYOUT_RELEASED'));
    assert.equal((await members[3].get(`/api/disputes/${r.data.dispute.id}`)).status, 403);
  });
  it('FT-47 foreman resolves with comments; comments are mandatory', async () => {
    const id = (await foreman.get('/api/disputes')).data.disputes[0].id;
    assert.equal((await foreman.patch(`/api/disputes/${id}`, { status: 'RESOLVED' })).status, 400);
    const r = await foreman.patch(`/api/disputes/${id}`, { status: 'RESOLVED', comments: 'Checked, payout correct' });
    assert.equal(r.data.dispute.status, 'RESOLVED');
    assert.equal((await foreman.patch(`/api/disputes/${id}`, { status: 'REJECTED', comments: 'x' })).status, 409);
  });
  it('FT-48 oversight escalates a dispute', async () => {
    const d = await members[2].post('/api/disputes', { bidId: flaggedBidId, description: 'My bid was wrongly flagged' });
    assert.equal(d.status, 201);
    const r = await oversight.patch(`/api/disputes/${d.data.dispute.id}`, { status: 'ESCALATED', comments: 'Needs a second look' });
    assert.equal(r.data.dispute.status, 'ESCALATED');
  });
  it('FT-46 refuses a dispute after the window closes', async () => {
    await foreman.patch(`/api/foreman/groups/${groupId}`, { disputeWindowDays: 0 });
    const r = await members[2].post('/api/disputes', { payoutId, description: 'Late' });
    assert.equal(r.status, 409); assert.equal(r.data.error, 'Dispute window has closed');
    await foreman.patch(`/api/foreman/groups/${groupId}`, { disputeWindowDays: 7 });
  });
});

describe('H. Audit, exports & dashboards', () => {
  let csv = '';
  it('FT-49 signed CSV export verifies; tampering is detected', async () => {
    const r = await oversight.req('GET', `/api/groups/${groupId}/export?format=csv`);
    assert.equal(r.status, 200); csv = r.data;
    const ok = await anon.post('/api/exports/verify', { csv });
    assert.equal(ok.data.valid, true);
    const bad = await anon.post('/api/exports/verify', { csv: csv.replace('GROUP_CREATED', 'GROUP_DELETED') });
    assert.equal(bad.data.valid, false);
    assert.equal((await members[0].req('GET', `/api/groups/${groupId}/export?format=csv`)).status, 403);
  });
  it('FT-50 signed PDF export is a valid PDF', async () => {
    const r = await oversight.req('GET', `/api/groups/${groupId}/export?format=pdf`);
    assert.equal(r.status, 200);
    assert.equal(r.data.subarray(0, 5).toString(), '%PDF-');
    fs.writeFileSync('/tmp/export-test.pdf', r.data);
    fs.writeFileSync('/tmp/export-test.csv', csv);
    assert.ok(r.headers.get('x-export-signature'));
  });
  it('FT-51 dashboards are role-specific', async () => {
    const m = (await members[0].get('/api/dashboard')).data;
    assert.equal(m.role, 'MEMBER'); assert.ok(m.contributionHistory.length && m.bidHistory.length); assert.equal(m.pendingKycCount, undefined);
    const f = (await foreman.get('/api/dashboard')).data;
    assert.equal(f.role, 'FOREMAN'); assert.equal(f.groups[0].cycles[0].collected, 4);
    const o = (await oversight.get('/api/dashboard')).data;
    assert.equal(o.role, 'OVERSIGHT_VIEWER'); assert.equal(o.integrity.valid, true); assert.equal(o.profile, undefined);
  });
  it('NFT-18 foreman admin actions are logged with actor and timestamp', async () => {
    for (const action of ['GROUP_EDITED', 'MEMBER_REMOVED', 'CYCLE_OPENED']) {
      const l = (await oversight.get(`/api/audit?action=${action}`)).data.logs;
      assert.ok(l.length && l.every((x: any) => x.actorId && x.timestamp), action);
    }
  });
  it('NFT-17 the ledger refuses UPDATE, DELETE and TRUNCATE', async () => {
    await assert.rejects(pool.query(`update audit_logs set action='X'`), /append-only/);
    await assert.rejects(pool.query(`delete from audit_logs`), /append-only/);
    await assert.rejects(pool.query(`truncate audit_logs`), /append-only/);
  });
  it('NFT-16 tampering with a stored hash is detected and pinpointed', async () => {
    const before = (await oversight.get('/api/audit?limit=1')).data.integrity;
    assert.equal(before.valid, true);
    const { rows: [victim] } = await pool.query(`select id, sequence, payload_json from audit_logs where action='GROUP_CREATED' limit 1`);
    const client = await pool.connect();
    try {
      await client.query(`alter table audit_logs disable trigger user`); // simulate an attacker with raw DB access
      await client.query(`update audit_logs set payload_json = replace(payload_json, '100000', '900000') where id=$1`, [victim.id]);
      const t = (await oversight.get('/api/audit?limit=1')).data.integrity;
      assert.equal(t.valid, false); assert.equal(t.corruptedSequence, victim.sequence); assert.equal(t.reason, 'HASH_MISMATCH');
      const exp = await oversight.req('GET', `/api/groups/${groupId}/export?format=csv`);
      assert.match(exp.data, /ledger_chain_valid=false/);
    } finally {
      await client.query(`update audit_logs set payload_json=$2 where id=$1`, [victim.id, victim.payload_json]);
      await client.query(`alter table audit_logs enable trigger user`);
      client.release();
    }
    assert.equal((await oversight.get('/api/audit?limit=1')).data.integrity.valid, true);
  });
  it('NFT-15 ledger is queryable by the oversight viewer at any time', async () => {
    const all = await oversight.get('/api/audit?limit=1000');
    assert.ok(all.data.logs.length > 40);
    assert.ok((await members[0].get('/api/audit')).status === 403);
  });
});

describe('Z. Performance', () => {
  it('NFT-01 bid + fraud check responds in <= 3 s under concurrent load (50 bidders)', async () => {
    const t = Date.now();
    const rs = await Promise.all(Array.from({ length: 50 }, () => members[0].get(`/api/cycles/${c2}`)));
    assert.ok(rs.every((r) => r.status === 200));
    assert.ok(Date.now() - t < 3000, `took ${Date.now() - t}ms`);
  });
  it('NFT-02 dashboard under 200 parallel requests in <= 2 s each (avg)', async () => {
    const times: number[] = [];
    await Promise.all(Array.from({ length: 200 }, async (_, i) => { const s = Date.now(); const r = await [members[0], foreman, oversight][i % 3].get('/api/dashboard'); assert.equal(r.status, 200); times.push(Date.now() - s); }));
    const avg = times.reduce((a, b) => a + b, 0) / times.length;
    console.log(`dashboard avg ${avg.toFixed(0)}ms max ${Math.max(...times)}ms`);
    assert.ok(avg < (process.env.PERF_AVG_MS ? Number(process.env.PERF_AVG_MS) : 2000), `avg ${avg}`); // dev server is slower than 'next start'
  });
  it('after all tests the ledger chain is intact', async () => {
    assert.equal((await oversight.get('/api/audit?limit=1')).data.integrity.valid, true);
    await pool.end();
  });
});
